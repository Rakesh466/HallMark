(function($) {
	printHuid=function () {	
		var i=1;

	    var trtags;
	    var totalWeight=0;
	    var totalQty=0;
	    var totalAmt=0;
	    $("table > tbody > tr").each(function () {
	       // alert($(this).find('td:eq(0)').find('input').val() + " " + $(this).find('td:eq(0)').find('input:eq(1)').val() );
if(i==1)	{	   
trtags="<tr style=''>"
	     +"<td style='font-size: 12px;'>"+i+"</td>"
	        +"<td style='word-wrap: break-word;min-width: 60px;max-width: 60px;font-size: 12px;'>"+$(this).find('td:eq(0)').find('input:eq(2)').val()+"</td>"
	        +"<td style='font-size: 12px;'>"+$(this).find('td:eq(2)').find('input').val()+"</td>"
	        +"<td style='font-size: 12px;'>"+$(this).find('td:eq(3)').find('input').val()+"</td>"
	        +"<td style='font-size: 12px;'>"+$(this).find('td:eq(1)').find('input').val()+"</td>"
	        +"<td style='font-size: 12px;'>"+$(this).find('td:eq(4)').find('input').val()+"</td>"
	        +"<td style='font-size: 12px;'>"+$(this).find('td:eq(5)').find('input').val()+"</td>"
	        //+"<td style='font-size: 12px;'></td>"
	        //+"<td style='font-size: 12px;'></td>"
	       +"</tr>";
}else{
trtags=trtags+ "<tr style=''>"
 +"<td style=''>"+i+"</td>"
    +"<td style='word-wrap: break-word;min-width: 60px;max-width: 60px;font-size: 12px;'>"+$(this).find('td:eq(0)').find('input:eq(2)').val()+"</td>"
    +"<td style='font-size: 12px;'>"+$(this).find('td:eq(2)').find('input').val()+"</td>"
    +"<td style='font-size: 12px;'>"+$(this).find('td:eq(3)').find('input').val()+"</td>"
    +"<td style='font-size: 12px;'>"+$(this).find('td:eq(1)').find('input').val()+"</td>"
    +"<td style='font-size: 12px;'>"+$(this).find('td:eq(4)').find('input').val()+"</td>"
    +"<td style='font-size: 12px;'>"+$(this).find('td:eq(5)').find('input').val()+"</td>"
    //+"<td style='font-size: 12px;'></td>"
    //+"<td style='font-size: 12px;'></td>"
   +"</tr>"
}
	       i++;
totalWeight=totalWeight+ parseFloat("0"+($(this).find('td:eq(2)').find('input').val()));
totalQty=totalQty+ parseFloat("0"+($(this).find('td:eq(1)').find('input').val()));
totalAmt=totalAmt+ parseFloat("0"+($(this).find('td:eq(5)').find('input').val()));
	    });
//alert(trtags);

 //var print_window = window.open();
var print_document='<html><head>'
+'<style>@media print {  @page '
	+'{'
	+'    size:  auto;   '
	+'    margin: 0mm; '
	+' }'
	+'body{'
+' width: 80mm;'
//+' height: 297mm;'
//+'margin: 10mm 15mm 10mm 15mm;'
+'font-family: Arial;'
+'}' 
+'}' 
+'table, th{'
+'border: 1px solid black;'
+'border-collapse: collapse;'
+'}'
+'</style>'
+'<meta charset="UTF-8">'
+'<meta name="viewport" content="width=device-width, initial-scale=1.0">'
+'<meta http-equiv="X-UA-Compatible" content="ie=edge">'
+'</head>';
print_document  = print_document+"<html><head><style>@media print { @page{size:  auto;margin:0px auto;}}</style></head><body class='media' style='font-family: Arial;line-height: 1.5;font-size: 14px;width: 80mm;'><div class='container' id='myPrint' style='margin: auto;border: 1px solid black;border-collapse: collapse;'><div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
				+"<div class='col' style='line-height: 1.5;position: relative;display: inline-block;'></div>"
				//+"<div class='col' style='line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;'><img src='project/images/invoice.png' max-width: 100%; height: auto; th:src='@{project/images/invoice.png}'></div>"
				+"<div class='col' style='line-height: 1.5;position: relative;width: 90%;padding-right: 13px;display: inline-block;text-align: right;'><h1 class='preview' data-content='CodePen' style='box-sizing: border-box;font-family: Arial, sans-serif;font-size: 1em;font-weight: bold;position: relative;z-index: 1;display: inline-block;-webkit-font-smoothing: antialiased;-moz-osx-font-smoothing: grayscale;color: black;width: 20%;height: 55%;margin-top: 5px;text-align: center;'>Estimate</h1></div>"
				+"</div>"

		+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
		+"<div class='col' style='font-size: 14px;width: 50%;line-height: 1.5;position: relative;padding-right: 15px;padding-left: 15px;display: inline-block;overflow-wrap: break-word;'>Party Name:"+$('#partyName').val()+"</div>"
		+"<div class='col' style='font-size: 14px;width: 23%;line-height: 1.5;position: relative;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'>Bill No. : "+$('#invoiceNo').val()+"</div>"
		+"</div>"
		+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
		+"<div class='col' style='font-size: 14px;width: 40%;line-height: 1.5;float:right;position: relative;padding-right: 15px;padding-left: 15px;display: inline-block;'>Request No. "+$('#requestNo').val()+"</div>"
		+"<div class='col' style='font-size: 14px;line-height: 1.5;position: relative;width: 40%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'>Date : "+formatDate($('#billDate').val())+"</div>"
		+"</div>"
		+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
		+"<div class='col' style='font-size: 14px;width: 40%;line-height: 1.5;float:right;position: relative;padding-right: 15px;padding-left: 15px;display: inline-block;'>License No. "+$('#license').val()+"</div>"
		+"<div class='col' style='font-size: 14px;text-align: right;float:right;position: relative;width: 39%;padding-right: 15px;padding-left: 15px;display: inline-block;'>Bill Type : HUID</div>"
		+"</div>"
		+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
		+"<div class='col' style='font-size: 14px;line-height: 1.5;float:right;position: relative;width: 90%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: center;'>HUID Details<br></div>"
		+"<br></div>"
		+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"

		+"<div class='col' style='width: 100%;line-height: 1.5;float:right;position: relative;padding-right: 15px;padding-left: 15px;display: inline-block;'>"
		+"<table class='table' style='width: 100%;'>"
	    +"<thead>"
	      +"<tr>"
	      +"<th scope='col' style='font-size: 14px;'>#</th>"
	        +"<th scope='col' style='font-size: 14px;text-align: left;width: 20%;'>Items</th>"
	        +"<th scope='col' style='font-size: 14px;text-align: left;'>Weight</th>"
	        +"<th scope='col' style='font-size: 14px;text-align: left;'>Purity</th>"
	        +"<th scope='col' style='font-size: 14px;text-align: left;'>Qty</th>"
	        +"<th scope='col' style='font-size: 14px;text-align: left;'>Rate</th>"
	        +"<th scope='col' style='font-size: 14px;text-align: left;'>Amount</th>"
	        //+"<th scope='col' style='font-size: 12px;text-align: left;width: 15%;'></th>"
	        //+"<th scope='col' style='font-size: 12px;text-align: left;width: 15%;'></th>"
	        +"</tr>"
	    +"</thead> "
	    +"<tbody>";
	    
	  
	    print_document=  print_document+ trtags +"</tbody>"
	    +"<tfoot><tr><td style='font-size: 14px;'></td><td style='font-size: 12px;'>Total:</td>"
	    +"<td style='font-size: 14px;'>"+totalWeight+"</td>"
	    +"<td style='font-size: 14px;'></td>"
	    +"<td style='font-size: 14px;'>"+totalQty+"</td>"
	    +"<td style='font-size: 14px;'></td>"
	    +"<td style='font-size: 14px;'>"+totalAmt+"</td>"
	    //+"<td style='font-size: 12px;'> </td>"
	    //+"<td style='font-size: 12px;'> </td>"
	    +"</tr></tfoot>"
	    +"</table></div>"
			+"</div>"
		+"<div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
		+"<div class='col' style='float:right;position: relative;width: 75%;padding-right: 15px;padding-left: 15px;display: inline-block;'>"

		+"<table class='table2' style='width:60%;margin-left: 40%;margin-top: 2%;'>"
	    +"<tbody>"
		 	+"<tr style='font-size: 14px;'>"
	     	+"<td style='font-size: 14px;'>Total Qty:</td>"
	        +"<td style='font-size: 14px;'>"+$('#totalQty').val()+"</td>"
	        +"</tr>"
	        +"<tr style='font-size: 14px;'>"
	        +"<td style='font-size: 14px;'>Total Amt:</td>"
	        +"<td style='font-size: 14px;'>"+$('#subtotal').val()+"</td>"
	        +"</tr>"
	        +"<tr style='font-size: 14px;'>"
	        +"<td style='font-size: 14px;'>Received Amt:</td>"
	        +"<td style='font-size: 14px;'>"+$('#receivedAmt').val()+"</td>"
	        +"</tr>"
	        +"<tr style='font-size: 14px;'>"
	        +"<td style='font-size: 14px;'>Balance:</td>"
	        +"<td style='font-size: 14px;'>"+$('#balanceAmt').val()+"</td>"
	        +"</tr>"
	        
	    +"</tbody></table>"
	    +"</div>"
		+"</div>"
		+"<div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
		+"<div class='col' style='font-size: 14px;position: relative;padding-right: 15px;padding-left: 15px;display: inline-block;'><br>RECEIVED RS. "+convertNumberToWords($('#receivedAmt').val())+" ONLY"
		
		+"</div>"
		+"</div>"
		+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'></div>"
		+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
		+"<div class='col' style='font-size: 14px;line-height: 1.5;text-align: end;float:right;position: relative;width: 90%;padding-right: 15px;padding-left: 15px;display: inline-block;'><br/><br/>Authorized Signature <br/>"
		
		+"</div>"
		+"</div>"
			+"</div></body>";
 //print_window.document.open();
 //print_window.document.write(print_document);
/*  print_window.document.close();
print_window.print();
print_window.close(); */ 
	    $("#myPrint").printThis({
	        debug: true,               // show the iframe for debugging
	        importCSS: false,            // import parent page css
	        importStyle: true,         // import style tags
	        printContainer: true,       // print outer container/$.selector
	        loadCSS: "/mahalaxmihallmarking/css/printThis.css",                // path to additional css file - use an array [] for multiple
	        pageTitle: "HUID Bill",              // add title to print page
	        removeInline: false,        // remove inline styles from print elements
	        removeInlineSelector: "*",  // custom selectors to filter inline styles. removeInline must be true
	        printDelay: 333,            // variable print delay
	        header: print_document,               // prefix to html
	        footer: null,               // postfix to html
	        base: false,                // preserve the BASE tag or accept a string for the URL
	        formValues: true,           // preserve input/form values
	        canvas: true,              // copy canvas content
	        doctypeString: '',       // enter a different doctype for older markup
	        removeScripts: false,       // remove script tags from print content
	        copyTagClasses: true,      // copy classes from the html & body tag
	        beforePrintEvent: null,     // function for printEvent in iframe
	        beforePrint: null,          // function called before iframe is filled
	        afterPrint: reloadPage            // function called before iframe is removed
	    });
   
};

/*** Tunch****/
	
printTunch=function () {	
		var i=1;
		
		 var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
		 
		var userNAME = options;//"[[${session.sessionUserName}]]";
	    					    var trtags;
	    					    var totalWeight=0;
	    					    var totalQty=0;
	    					    var totalAmt=0;
	    					    $("table > tbody > tr").each(function () {
	    					       // alert($(this).find('td:eq(0)').find('input').val() + " " + $(this).find('td:eq(0)').find('input:eq(1)').val() );
	    			if(i==1)	{	   
	    			trtags="<tr style=''>"
	    					     +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+i+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;overflow-wrap: break-word;word-break: break-word;'>"+$(this).find('td:eq(0)').find('input:eq(1)').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(2)').find('input').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(1)').find('input').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(3)').find('input').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(4)').find('input').val()+"</td>"
	    					       +"</tr>";
	    			}else{
	    				trtags=trtags+ "<tr style='border: 1px solid black;border-collapse: collapse;'>"
					     +"<td style='border: 1px solid black;border-collapse: collapse;'>"+i+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;overflow-wrap: break-word;word-break: break-word;'>"+$(this).find('td:eq(0)').find('input:eq(1)').val()+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(2)').find('input').val()+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(1)').find('input').val()+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(3)').find('input').val()+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(4)').find('input').val()+"</td>"
					       +"</tr>"
	    			}
	    					       i++;
	    				totalWeight=totalWeight+ parseFloat("0"+($(this).find('td:eq(2)').find('input').val()));
	    				totalQty=totalQty+ parseFloat("0"+($(this).find('td:eq(1)').find('input').val()));
	    				totalAmt=totalAmt+ parseFloat("0"+($(this).find('td:eq(4)').find('input').val()));
	    					    });
	    			//alert(trtags);
	    			
	    //var print_window = window.open();
	    var print_document='<html><head>'
	        '<style>@media print {  @page { size:3in; margin: 2cm; }'
	    	+'body{'
	       +' width: 3in;'
	        +'height: 29.7cm;'
	        +'margin: 30mm 45mm 30mm 45mm;' 
		   +'}' 
			+'}' 
	        +'table, th, td {'
	        +'border: 1px solid black;'
	        +'border-collapse: collapse;'
	        +'}'
	        +'.row{flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;}</style></head>';
	    print_document  = print_document+"<html><head><style>@media print { @page{size:  auto;margin:0px auto;}}</style></head><body style='font-size: 12px;line-height: 1.5;width: 3in;'><div class='container' id='myPrint' style='margin: auto;width: 3in;border: 1px solid black;border-collapse: collapse;'><div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
										+"<div class='col' style='line-height: 1.5;position: relative;width: 30%;padding-right: 15px;padding-left: 15px;display: inline-block;'></div>"
			    						+"<div class='col' style='margin-top: 5px;line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'><img src='/mahalaxmihallmarking/project/images/invoice.png' max-width: 100%; height: auto; th:src='@{/mahalaxmihallmarking/project/images/invoice.png}'></div>"
			    						//+"<div class='col' style='line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'><h1 class='preview' data-content='CodePen' style='box-sizing: border-box;font-family: Arial, sans-serif;font-size: 1em;font-weight: bold;position: relative;z-index: 1;display: inline-block;-webkit-font-smoothing: antialiased;-moz-osx-font-smoothing: grayscale;color: white;background-color: peru;width: 20%;height: 55%;margin-top: 5px;text-align: center;'>Invoice</h1></div>"
			    						+"</div>"

	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;position: relative;width: 45%;padding-right: 15px;padding-left: 15px;display: inline-block;overflow-wrap: break-word;'>Party Name:"+$('#partyName').val()+"</div>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;position: relative;width: 22%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'>Bill No. : "+$('#invoiceNo').val()+"</div>"
	    						+"</div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;float:right;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;'></div>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;position: relative;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'>Date : "+formatDate($('#billDate').val())+"</div>"
	    						+"</div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;float:right;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;'></div>"
	    						+"<div class='col' style='font-size: 12px;text-align: right;float:right;position: relative;padding-right: 15px;padding-left: 15px;display: inline-block;'>Bill Type : TUNCH</div>"
	    						+"</div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;float:right;position: relative;width: 85%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: center;'>Tunch Details<br></div>"
								+"<br></div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"

	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;float:right;position: relative;width: 100%;padding-right: 15px;padding-left: 15px;display: inline-block;'>"
	    						+"<table class='table' style='width:100%;border: 1px solid black;border-collapse: collapse;'>"
	    					    +"<thead>"
	    					      +"<tr style='border: 1px solid black;border-collapse: collapse;'>"
	    					      +"<th scope='col' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;width:5%;'>Sr.No.</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 20%;'>Particulars</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 10%;'>Item Weight</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 10%;'>Qty</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 10%;'>Rate</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 10%;'>Amount</th>"
	    					        +"</tr>"
	    					    +"</thead> "
	    					    +"<tbody>";
	    					    
	    					   
	    					    print_document=  print_document+ trtags +"</tbody>"
	    					    +"<tfoot><tr><td colspan='2' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align:right;'>Total:</td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+totalWeight+"</td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+totalQty+"</td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+totalAmt+"</td>"
	    					    +"</tr></tfoot>"
	    					    +"</table></div>"
	   							+"</div>"
	    						+"<div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    						+"<div class='col' style='float:right;position: relative;width: 100%;padding-right: 15px;padding-left: 15px;display: inline-block;'>"

	    						+"<table class='table2' style='width:40%;margin-left: 60%;margin-top: 2%;border: 1px solid black;border-collapse: collapse;'>"
	    					    +"<tbody>"
	    	    				 	+"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					     	+"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Total Qty:</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$('#totalQty').val()+"</td>"
	    					        +"</tr>"
	    					        +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Total Amt:</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$('#subtotal').val()+"</td>"
	    					        +"</tr>"
	    					        +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Received Amt:</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$('#receivedAmt').val()+"</td>"
	    					        +"</tr>"
	    					        +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Balance:</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$('#balanceAmt').val()+"</td>"
	    					        +"</tr>"
	    					        
	    					    +"</tbody></table>"
	    					    +"</div>"
	    						+"</div>"
	    						+"<div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    						+"<div class='col' style='font-size: 12px;position: relative;width: 70%;padding-right: 15px;padding-left: 15px;display: inline-block;'>RECEIVED RS. "+convertNumberToWords($('#receivedAmt').val())+" ONLY"
	    						
	    						+"</div>"
	    						+"</div>"
	    						
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'></div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;text-align: end;float:right;position: relative;width: 90%;padding-right: 15px;padding-left: 15px;display: inline-block;'><br/><br/>Authorized Signature <br/>"
	    						
	    						+"</div>"
	    						+"</div>"
	   							+"</div></body>";
	   //print_window.document.open();
	    //print_window.document.write(print_document);
	   //print_window.document.close();
	   //print_window.print();
	   //print_window.close();
	    $("#myPrint").printThis({
	        debug: true,               // show the iframe for debugging
	        importCSS: false,            // import parent page css
	        importStyle: true,         // import style tags
	        printContainer: true,       // print outer container/$.selector
	        loadCSS: "",                // path to additional css file - use an array [] for multiple
	        pageTitle: "Tunch Bill",              // add title to print page
	        removeInline: false,        // remove inline styles from print elements
	        removeInlineSelector: "*",  // custom selectors to filter inline styles. removeInline must be true
	        printDelay: 333,            // variable print delay
	        header: print_document,               // prefix to html
	        footer: null,               // postfix to html
	        base: false,                // preserve the BASE tag or accept a string for the URL
	        formValues: true,           // preserve input/form values
	        canvas: false,              // copy canvas content
	        doctypeString: '',       // enter a different doctype for older markup
	        removeScripts: false,       // remove script tags from print content
	        copyTagClasses: false,      // copy classes from the html & body tag
	        beforePrintEvent: null,     // function for printEvent in iframe
	        beforePrint: null,          // function called before iframe is filled
	        afterPrint: reloadPage            // function called before iframe is removed
	    });
	   
	};
/*** End  ***/

/*** Lesser Marking****/

	printLesser=function () {
		var i=1;
		
		 var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
		 
		var userNAME = options;//"[[${session.sessionUserName}]]";
	    					    var trtags;
	    					    var totalWeight=0;
	    					    var totalQty=0;
	    					    var totalAmt=0;
	    					    $("table > tbody > tr").each(function () {
	    					       // alert($(this).find('td:eq(0)').find('input').val() + " " + $(this).find('td:eq(0)').find('input:eq(1)').val() );
	    			if(i==1)	{	   
	    			trtags="<tr style='border: 1px solid black;border-collapse: collapse;'>"
	    					     +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+i+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;overflow-wrap: break-word;word-break: break-word;'>"+$(this).find('td:eq(0)').find('input:eq(1)').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(2)').find('input').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(1)').find('input').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(3)').find('input').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(4)').find('input').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(5)').find('input').val()+"</td>"
	    					       +"</tr>";
	    			}else{
	    				trtags=trtags+ "<tr style='border: 1px solid black;border-collapse: collapse;'>"
					     +"<td style='border: 1px solid black;border-collapse: collapse;'>"+i+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;overflow-wrap: break-word;word-break: break-word;'>"+$(this).find('td:eq(0)').find('input:eq(1)').val()+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(2)').find('input').val()+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(1)').find('input').val()+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(3)').find('input').val()+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(4)').find('input').val()+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(5)').find('input').val()+"</td>"
					       +"</tr>"
	    			}
	    					       i++;
	    				totalWeight=totalWeight+ parseFloat("0"+($(this).find('td:eq(2)').find('input').val()));
	    				totalQty=totalQty+ parseFloat("0"+($(this).find('td:eq(1)').find('input').val()));
	    				totalAmt=totalAmt+ parseFloat("0"+($(this).find('td:eq(4)').find('input').val()));
	    					    });
	    			//alert(trtags);
	    			
	    //var print_window = window.open();
	    var print_document='<html><head>'
	        '<style>@media print { @page { size:3in; margin: 2cm; } '
	    	+'body{'
	       +' width: 3in;'
	        +'height: 29.7cm;'
	        +'margin: 30mm 45mm 30mm 45mm;' 
		   +'}' 
			+'}' 
	        +'table, th, td {'
	        +'border: 1px solid black;'
	        +'border-collapse: collapse;'
	        +'}'
	        +'.row{flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;}</style></head>';
	    print_document  = print_document+"<body style='font-size: 12px;line-height: 1.5;width: 3in;'><div class='container' id='myPrint' style='margin: auto;width: 3in;border: 1px solid black;border-collapse: collapse;'><div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
										+"<div class='col' style='line-height: 1.5;position: relative;width: 30%;padding-right: 15px;padding-left: 15px;display: inline-block;'></div>"
			    						+"<div class='col' style='margin-top: 5px;line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'><img src='/mahalaxmihallmarking/project/images/invoice.png' max-width: 100%; height: auto; th:src='@{/mahalaxmihallmarking/project/images/invoice.png}'></div>"

			    						//+"<div class='col' style='line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'><h1 class='preview' data-content='CodePen' style='box-sizing: border-box;font-family: Arial, sans-serif;font-size: 1em;font-weight: bold;position: relative;z-index: 1;display: inline-block;-webkit-font-smoothing: antialiased;-moz-osx-font-smoothing: grayscale;color: white;background-color: peru;width: 20%;height: 55%;margin-top: 5px;text-align: center;'>Invoice</h1></div>"
			    						+"</div>"

	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;position: relative;width: 45%;padding-right: 15px;padding-left: 15px;display: inline-block;overflow-wrap: break-word;'>Party Name:"+$('#partyName').val()+"</div>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;position: relative;width: 22%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'>Bill No. : "+$('#invoiceNo').val()+"</div>"
	    						+"</div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;float:right;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;'></div>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;position: relative;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'>Date : "+formatDate($('#billDate').val())+"</div>"
	    						+"</div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;float:right;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;'></div>"
	    						+"<div class='col' style='font-size: 12px;text-align: right;float:right;position: relative;padding-right: 15px;padding-left: 15px;display: inline-block;'>Bill Type : L.M </div>"
	    						+"</div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;float:right;position: relative;width: 80%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: center;'>Lesser Marking<br></div>"
								+"<br></div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"

	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;float:right;position: relative;width: 100%;padding-right: 15px;padding-left: 15px;display: inline-block;'>"
	    						+"<table class='table' style='width:100%;border: 1px solid black;border-collapse: collapse;'>"
	    					    +"<thead>"
	    					      +"<tr style='border: 1px solid black;border-collapse: collapse;'>"
	    					      +"<th scope='col' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;width:5%;'>Sr.No.</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 20%;'>Particulars</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 10%;'>Item Weight</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 10%;'>Qty</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 10%;'>Rate</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 10%;'>Amount</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 10%;'>L.M. Name</th>"
	    					        +"</tr>"
	    					    +"</thead> "
	    					    +"<tbody>";
	    					    
	    					   
	    					    print_document=  print_document+ trtags +"</tbody>"
	    					    +"<tfoot><tr><td colspan='2' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align:right;'>Total:</td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+totalWeight+"</td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+totalQty+"</td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+totalAmt+"</td>"
	    					    +"<td></td></tr></tfoot>"
	    					    +"</table></div>"
	   							+"</div>"
	    						+"<div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    						+"<div class='col' style='float:right;position: relative;width: 100%;padding-right: 15px;padding-left: 15px;display: inline-block;'>"

	    						+"<table class='table2' style='width:40%;margin-left: 60%;margin-top: 2%;border: 1px solid black;border-collapse: collapse;'>"
	    					    +"<tbody>"
	    	    				 	+"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					     	+"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Total Qty:</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$('#totalQty').val()+"</td>"
	    					        +"</tr>"
	    					        +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Total Amt:</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$('#subtotal').val()+"</td>"
	    					        +"</tr>"
	    					        +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Received Amt:</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$('#receivedAmt').val()+"</td>"
	    					        +"</tr>"
	    					        +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Balance:</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$('#balanceAmt').val()+"</td>"
	    					        +"</tr>"
	    					        
	    					    +"</tbody></table>"
	    					    +"</div>"
	    						+"</div>"
	    						+"<div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    						+"<div class='col' style='font-size: 12px;position: relative;width: 70%;padding-right: 15px;padding-left: 15px;display: inline-block;'>RECEIVED RS. "+convertNumberToWords($('#receivedAmt').val())+" ONLY"
	    						
	    						+"</div>"
	    						+"</div>"
	    						
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'></div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;text-align: end;float:right;position: relative;width: 90%;padding-right: 15px;padding-left: 15px;display: inline-block;'><br/><br/>Authorized Signature <br/>"
	    						
	    						+"</div>"
	    						+"</div>"
	   							+"</div></body>";
	   // print_window.document.open();
	    //print_window.document.write(print_document);
	   //print_window.document.close();
	   //print_window.print();
	   //print_window.close();
	    $("#myPrint").printThis({
	        debug: true,               // show the iframe for debugging
	        importCSS: false,            // import parent page css
	        importStyle: true,         // import style tags
	        printContainer: true,       // print outer container/$.selector
	        loadCSS: "",                // path to additional css file - use an array [] for multiple
	        pageTitle: "Lesser Marking",              // add title to print page
	        removeInline: false,        // remove inline styles from print elements
	        removeInlineSelector: "*",  // custom selectors to filter inline styles. removeInline must be true
	        printDelay: 333,            // variable print delay
	        header: print_document,               // prefix to html
	        footer: null,               // postfix to html
	        base: false,                // preserve the BASE tag or accept a string for the URL
	        formValues: true,           // preserve input/form values
	        canvas: false,              // copy canvas content
	        doctypeString: '',       // enter a different doctype for older markup
	        removeScripts: false,       // remove script tags from print content
	        copyTagClasses: false,      // copy classes from the html & body tag
	        beforePrintEvent: null,     // function for printEvent in iframe
	        beforePrint: null,          // function called before iframe is filled
	        afterPrint: reloadPage            // function called before iframe is removed
	    });
	}
/****** End *******/
	
	printMutltiBill=function () {	
		var i=1;
		
		 var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
		 
		var userNAME = options;//"[[${session.sessionUserName}]]";
	    					    var trtags;
	    					    var totalWeight=0;
	    					    var totalQty=0;
	    					    var totalAmt=0;
	    	if($("#hallmarking").prop('checked')){  
	    					$("#hallMarkTbl > tbody > tr").each(function () {
	    					    if(i==1)	
	    					    {	   
	    					    		trtags="<tr style='border: 1px solid black;border-collapse: collapse;'>"
	    					     +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+i+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;word-break: break-word;'>"+$(this).find('td:eq(0)').find('input:eq(1)').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(2)').find('input').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(3)').find('input').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(1)').find('input').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(4)').find('input').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(5)').find('input').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"
	    					       +"</tr>";
	    					    }else{
	    					     trtags=trtags+ "<tr style='border: 1px solid black;border-collapse: collapse;'>"
		    					+"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+i+"</td>"
						        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;word-break: break-word;'>"+$(this).find('td:eq(0)').find('input:eq(1)').val()+"</td>"
						        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(2)').find('input').val()+"</td>"
						        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(3)').find('input').val()+"</td>"
						        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(1)').find('input').val()+"</td>"
						        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(4)').find('input').val()+"</td>"
						        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(5)').find('input').val()+"</td>"
						        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"
						        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"
						       +"</tr>"
	    					    }
	    					  i++;
	    				totalWeight=totalWeight+ parseFloat("0"+($(this).find('td:eq(2)').find('input').val()));
	    				totalQty=totalQty+ parseFloat("0"+($(this).find('td:eq(1)').find('input').val()));
	    				totalAmt=totalAmt+ parseFloat("0"+($(this).find('td:eq(5)').find('input').val()));
	    		});
	    }
	    
	    	if($("#card").prop('checked')){  
				$("#cardTbl > tbody > tr").each(function () {
				    if(i==1)	
				    {	   
				    		trtags="<tr style='border: 1px solid black;border-collapse: collapse;'>"
				     +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+i+"</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;word-break: break-word;'>"+$(this).find('td:eq(0)').find('input:eq(1)').val()+"</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(3)').find('input').val()+"</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(4)').find('input').val()+"</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>0</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>0</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(6)').find('input').val()+"</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"
				       +"</tr>";
				    }else{
				     trtags=trtags+ "<tr style='border: 1px solid black;border-collapse: collapse;'>"
					+"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+i+"</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;word-break: break-word;'>"+$(this).find('td:eq(0)').find('input:eq(1)').val()+"</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(3)').find('input').val()+"</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(4)').find('input').val()+"</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>0</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>0</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(6)').find('input').val()+"</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"
			       +"</tr>"
				    }
				  i++;
			totalWeight=totalWeight+ parseFloat("0"+($(this).find('td:eq(3)').find('input').val()));
			//totalQty=totalQty+ parseFloat("0"+($(this).find('td:eq(1)').find('input').val()));
			totalAmt=totalAmt+ parseFloat("0"+($(this).find('td:eq(6)').find('input').val()));
	});
}

	    	if($("#tunch").prop('checked')){  
				$("#tunchTbl > tbody > tr").each(function () {
				    if(i==1)	
				    {	   
				    		trtags="<tr style='border: 1px solid black;border-collapse: collapse;'>"
				     +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+i+"</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;word-break: break-word;'>"+$(this).find('td:eq(0)').find('input:eq(1)').val()+"</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(2)').find('input').val()+"</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>0</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(1)').find('input').val()+"</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(3)').find('input').val()+"</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(4)').find('input').val()+"</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"
				       +"</tr>";
				    }else{
				     trtags=trtags+ "<tr style='border: 1px solid black;border-collapse: collapse;'>"
					+"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+i+"</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;word-break: break-word;'>"+$(this).find('td:eq(0)').find('input:eq(1)').val()+"</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(2)').find('input').val()+"</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>0</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(1)').find('input').val()+"</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(3)').find('input').val()+"</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(4)').find('input').val()+"</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"
			       +"</tr>"
				    }
				  i++;
			totalWeight=totalWeight+ parseFloat("0"+($(this).find('td:eq(2)').find('input').val()));
			totalQty=totalQty+ parseFloat("0"+($(this).find('td:eq(1)').find('input').val()));
			totalAmt=totalAmt+ parseFloat("0"+($(this).find('td:eq(4)').find('input').val()));
	});
}

	    	if($("#lesser").prop('checked')){  
				$("#lesserTbl > tbody > tr").each(function () {
				    if(i==1)	
				    {	   
				    		trtags="<tr style='border: 1px solid black;border-collapse: collapse;'>"
				     +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+i+"</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;word-break: break-word;'>"+$(this).find('td:eq(0)').find('input:eq(1)').val()+"</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(2)').find('input').val()+"</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>0</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(1)').find('input').val()+"</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(3)').find('input').val()+"</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(4)').find('input').val()+"</td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"
				        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"
				       +"</tr>";
				    }else{
				     trtags=trtags+ "<tr style='border: 1px solid black;border-collapse: collapse;'>"
					+"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+i+"</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;word-break: break-word;'>"+$(this).find('td:eq(0)').find('input:eq(1)').val()+"</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(2)').find('input').val()+"</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>0</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(1)').find('input').val()+"</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(3)').find('input').val()+"</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(4)').find('input').val()+"</td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"
			        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"
			       +"</tr>"
				    }
				  i++;
			totalWeight=totalWeight+ parseFloat("0"+($(this).find('td:eq(2)').find('input').val()));
			totalQty=totalQty+ parseFloat("0"+($(this).find('td:eq(1)').find('input').val()));
			totalAmt=totalAmt+ parseFloat("0"+($(this).find('td:eq(4)').find('input').val()));
	});
}	
	    //var print_window = window.open();
	    var print_document='<html><head>'
	        '<style>@media print { print { @page { size:3in; margin: 2cm; }' 
	    	+'body{'
	       +' width: 3in;'
	        //+'height: 29.7cm;'
	        +'margin: 30mm 45mm 30mm 45mm;' 
		   +'}' 
			+'}' 
	        +'table, th, td {'
	        +'border: 1px solid black;'
	        +'border-collapse: collapse;'
	        +'}'
	        +'.row{flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;}</style></head>';
	    print_document  = print_document+"<body style='line-height: 1.5;width: 3in;font-size: 12px;'><div class='container' id='myPrint' style='margin: auto;width: 3in;border: 1px solid black;border-collapse: collapse;'><div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
										+"<div class='col' style='line-height: 1.5;position: relative;width: 30%;padding-right: 15px;padding-left: 15px;display: inline-block;'></div>"
										+"<div class='col' style='margin-top: 5px;line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'><img src='/mahalaxmihallmarking/project/images/invoice.png' max-width: 100%; height: auto; th:src='@{/mahalaxmihallmarking/project/images/invoice.png}'></div>"
										//+"<div class='col' style='line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'><h1 class='preview' data-content='CodePen' style='box-sizing: border-box;font-family: Arial, sans-serif;font-size: 1em;font-weight: bold;position: relative;z-index: 1;display: inline-block;-webkit-font-smoothing: antialiased;-moz-osx-font-smoothing: grayscale;color: white;background-color: peru;width: 20%;height: 55%;margin-top: 5px;text-align: center;'>Invoice</h1></div>"
			    						+"</div>"

	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;position: relative;width: 45%;padding-right: 15px;padding-left: 15px;display: inline-block;overflow-wrap: break-word;'>Party Name:"+$('#partyName').val()+"</div>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;position: relative;width: 22%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'>Bill No. : "+$('#invoiceNo').val()+"</div>"
	    						+"</div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;float:right;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;'>Request No. "+$('#requestNo').val()+"</div>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;position: relative;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'>Date : "+formatDate($('#billDate').val())+"</div>"
	    						+"</div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;float:right;position: relative;width: 40%;padding-right: 15px;padding-left: 15px;display: inline-block;overflow-wrap: break-word;'>License No. "+$('#license').val()+"</div>"
	    						+"<div class='col' style='font-size: 12px;text-align: right;float:right;position: relative;padding-right: 15px;padding-left: 15px;display: inline-block;'>Bill Type : Multi Bill</div>"
	    						+"</div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;float:right;position: relative;width: 80%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: center;'>Multi Bill Details<br></div>"
								+"<br></div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"

	    						+"<div class='col' style='line-height: 1.5;float:right;position: relative;width: 100%;padding-right: 15px;padding-left: 15px;display: inline-block;'>"
	    						+"<table class='table' style='width:100%;border: 1px solid black;border-collapse: collapse;'>"
	    					    +"<thead>"
	    					      +"<tr style='border: 1px solid black;border-collapse: collapse;'>"
	    					      +"<th scope='col' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Sr.No.</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 20%;'>Items</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;'>Weight</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;'>Purity</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;'>Qty</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;'>Rate</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;'>Amount</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 15%;'></th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 15%;'></th>"
	    					        +"</tr>"
	    					    +"</thead> "
	    					    +"<tbody>";
	    					    
	    					   
	    					    print_document=  print_document+ trtags +"</tbody>"
	    					    +"<tfoot><tr><td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td><td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Total:</td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+totalWeight+"</td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+totalQty+"</td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+totalAmt+"</td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'> </td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'> </td>"
	    					    +"</tr></tfoot>"
	    					    +"</table></div>"
	   							+"</div>"
	    						+"<div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    						+"<div class='col' style='float:right;position: relative;width: 70%;padding-right: 15px;padding-left: 15px;display: inline-block;'>"

	    						+"<table class='table2' style='width:40%;margin-left: 70%;margin-top: 2%;border: 1px solid black;border-collapse: collapse;'>"
	    					    +"<tbody>"
	    	    				 	+"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					     	+"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Total Qty:</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$('#totalQty').val()+"</td>"
	    					        +"</tr>"
	    					        +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Total Amt:</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$('#subtotal').val()+"</td>"
	    					        +"</tr>"
	    					        +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Received Amt:</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$('#receivedAmt').val()+"</td>"
	    					        +"</tr>"
	    					        +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Balance:</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$('#balanceAmt').val()+"</td>"
	    					        +"</tr>"
	    					        
	    					    +"</tbody></table>"
	    					    +"</div>"
	    						+"</div>"
	    						+"<div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    						+"<div class='col' style='font-size: 12px;position: relative;width: 70%;padding-right: 15px;padding-left: 15px;display: inline-block;'>RECEIVED RS. "+convertNumberToWords($('#receivedAmt').val())+" ONLY"
	    						
	    						+"</div>"
	    						+"</div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'><br/></div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;text-align: end;float:right;position: relative;width: 90%;padding-right: 15px;padding-left: 15px;display: inline-block;'><br/><br/>Authorized Signature <br/>"
	    						
	    						+"</div>"
	    						+"</div>"
	   							+"</div></body>";
	    //print_window.document.open();
	   // print_window.document.write(print_document);
	    //print_window.document.close();
	    //print_window.print();
	   //print_window.close();
	    $("#myPrint").printThis({
	        debug: true,               // show the iframe for debugging
	        importCSS: false,            // import parent page css
	        importStyle: true,         // import style tags
	        printContainer: true,       // print outer container/$.selector
	        loadCSS: "",                // path to additional css file - use an array [] for multiple
	        pageTitle: "Mutil Bill",              // add title to print page
	        removeInline: false,        // remove inline styles from print elements
	        removeInlineSelector: "*",  // custom selectors to filter inline styles. removeInline must be true
	        printDelay: 333,            // variable print delay
	        header: print_document,               // prefix to html
	        footer: null,               // postfix to html
	        base: false,                // preserve the BASE tag or accept a string for the URL
	        formValues: true,           // preserve input/form values
	        canvas: false,              // copy canvas content
	        doctypeString: '',       // enter a different doctype for older markup
	        removeScripts: false,       // remove script tags from print content
	        copyTagClasses: false,      // copy classes from the html & body tag
	        beforePrintEvent: null,     // function for printEvent in iframe
	        beforePrint: null,          // function called before iframe is filled
	        afterPrint: reloadPage            // function called before iframe is removed
	    });
	   
	};

	/*** Card****/

	printCard=function () {
		var i=1;
		
		 var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
		 
		var userNAME = options;//"[[${session.sessionUserName}]]";
	    					    var trtags;
	    					    var totalWeight=0;
	    					    var totalQty=0;
	    					    var totalAmt=0;
	    					    $("table > tbody > tr").each(function () {
	    					       // alert($(this).find('td:eq(0)').find('input').val() + " " + $(this).find('td:eq(0)').find('input:eq(1)').val() );
	    			if(i==1)	{	   
	    			trtags="<tr style='border: 1px solid black;border-collapse: collapse;'>"
	    					     +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+i+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(0)').find('input:eq(1)').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(1)').find('input').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(3)').find('input').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(6)').find('input').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(5)').find('input').val()+"</td>"
	    					       +"</tr>";
	    			}else{
	    				trtags=trtags+ "<tr style='border: 1px solid black;border-collapse: collapse;'>"
					     +"<td style='border: 1px solid black;border-collapse: collapse;'>"+i+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(0)').find('input:eq(1)').val()+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(1)').find('input').val()+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(3)').find('input').val()+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(6)').find('input').val()+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(5)').find('input').val()+"</td>"
					       +"</tr>"
	    			}
	    					       i++;
	    				totalWeight=totalWeight+ parseFloat("0"+($(this).find('td:eq(3)').find('input').val()));
	    				//totalQty=totalQty+ parseFloat("0"+($(this).find('td:eq(1)').find('input').val()));
	    				totalAmt=totalAmt+ parseFloat("0"+($(this).find('td:eq(6)').find('input').val()));
	    					    });
	    			//alert(trtags);
	    			
	    //var print_window = window.open();
	    var print_document='<html><head>'
	        '<style>@media print {  body{'
	       +' width: 21cm;'
	        +'height: 29.7cm;'
	        +'margin: 30mm 45mm 30mm 45mm;' 
		   +'}' 
			+'}' 
	        +'table, th, td {'
	        +'border: 1px solid black;'
	        +'border-collapse: collapse;'
	        +'}'
	        +'.row{flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;}</style></head>';
	    print_document  = print_document+"<body style='line-height: 1.5;'><div class='container' id='myPrint' style='margin: auto;width: 70%;border: 1px solid black;border-collapse: collapse;'><div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
										+"<div class='col' style='line-height: 1.5;position: relative;width: 30%;padding-right: 15px;padding-left: 15px;display: inline-block;'></div>"
			    						//+"<div class='col' style='line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;'><img src='project/images/invoice.png' max-width: 100%; height: auto; th:src='@{project/images/invoice.png}'></div>"
			    						+"<div class='col' style='line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'><h1 class='preview' data-content='CodePen' style='box-sizing: border-box;font-family: Arial, sans-serif;font-size: 1em;font-weight: bold;position: relative;z-index: 1;display: inline-block;-webkit-font-smoothing: antialiased;-moz-osx-font-smoothing: grayscale;color: white;background-color: peru;width: 20%;height: 55%;margin-top: 5px;text-align: center;'>Invoice</h1></div>"
			    						+"</div>"

	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
	    						+"<div class='col' style='line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;overflow-wrap: break-word;'>Party Name:"+$('#partyName').val()+"</div>"
	    						+"<div class='col' style='line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'>Bill No. : "+$('#invoiceNo').val()+"</div>"
	    						+"</div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
	    						+"<div class='col' style='line-height: 1.5;float:right;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;'></div>"
	    						+"<div class='col' style='line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'>Date : "+formatDate($('#billDate').val())+"</div>"
	    						+"</div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
	    						+"<div class='col' style='line-height: 1.5;float:right;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;'></div>"
	    						+"<div class='col' style='text-align: right;float:right;position: relative;width: 20%;padding-right: 15px;padding-left: 15px;display: inline-block;'>Bill Type : Card </div>"
	    						+"</div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -10px;'>"
	    						+"<div class='col' style='line-height: 1.5;float:right;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: center;'>Card Detail<br></div>"
								+"<br></div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"

	    						+"<div class='col' style='line-height: 1.5;float:right;position: relative;width: 100%;padding-right: 15px;padding-left: 15px;display: inline-block;'>"
	    						+"<table class='table' style='box-shadow: 0 0 2px black;width:100%;border: 1px solid black;border-collapse: collapse;'>"
	    					    +"<thead>"
	    					      +"<tr style='border: 1px solid black;border-collapse: collapse;'>"
	    					      +"<th scope='col' style='border: 1px solid black;border-collapse: collapse;width:5%;'>Sr.No.</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 20%;'>Particulars</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 20%;'>Custome Name</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 10%;'>Item Weight</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 10%;'>Amount</th>"
	    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 10%;'>Extra Mark</th>"
	    					        +"</tr>"
	    					    +"</thead> "
	    					    +"<tbody>";
	    					    
	    					   
	    					    print_document=  print_document+ trtags +"</tbody>"
	    					    +"<tfoot><tr><td colspan='3' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align:right;'>Total:</td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+totalWeight+"</td>"
	    					    //+"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+totalQty+"</td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+totalAmt+"</td>"
	    					    +"<td></td></tr></tfoot>"
	    					    +"</table></div>"
	   							+"</div>"
	    						+"<div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    						+"<div class='col' style='float:right;position: relative;width: 100%;padding-right: 15px;padding-left: 15px;display: inline-block;'>"

	    						+"<table class='table2' style='box-shadow: 0 0 2px black;width:40%;margin-left: 60%;margin-top: 2%;border: 1px solid black;border-collapse: collapse;'>"
	    					    +"<tbody>"
	    	    				 	+"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					     	+"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Total Weight:</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$('#totalWeight').val()+"</td>"
	    					        +"</tr>"
	    					        +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Total Amt:</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$('#subtotal').val()+"</td>"
	    					        +"</tr>"
	    					        +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Received Amt:</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$('#receivedAmt').val()+"</td>"
	    					        +"</tr>"
	    					        +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Balance:</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$('#balanceAmt').val()+"</td>"
	    					        +"</tr>"
	    					        
	    					    +"</tbody></table>"
	    					    +"</div>"
	    						+"</div>"
	    						+"<div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    						+"<div class='col' style='position: relative;width: 70%;padding-right: 15px;padding-left: 15px;display: inline-block;'>RECEIVED RS. "+convertNumberToWords($('#receivedAmt').val())+" ONLY"
	    						
	    						+"</div>"
	    						+"</div>"
	    						
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'></div>"
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    						+"<div class='col' style='line-height: 1.5;text-align: end;float:right;position: relative;width: 70%;padding-right: 15px;padding-left: 15px;display: inline-block;'><br/><br/>Authorized Signature <br/>"
	    						
	    						+"</div>"
	    						+"</div>"
	   							+"</div></body>";
	    //print_window.document.open();
	    //print_window.document.write(print_document);
	   //print_window.document.close();
	   //print_window.print();
	   //print_window.close();
	    $("#myPrint").printThis({
	        debug: true,               // show the iframe for debugging
	        importCSS: true,            // import parent page css
	        importStyle: false,         // import style tags
	        printContainer: true,       // print outer container/$.selector
	        loadCSS: "",                // path to additional css file - use an array [] for multiple
	        pageTitle: "Card",              // add title to print page
	        removeInline: false,        // remove inline styles from print elements
	        removeInlineSelector: "*",  // custom selectors to filter inline styles. removeInline must be true
	        printDelay: 333,            // variable print delay
	        header: print_document,               // prefix to html
	        footer: null,               // postfix to html
	        base: false,                // preserve the BASE tag or accept a string for the URL
	        formValues: true,           // preserve input/form values
	        canvas: false,              // copy canvas content
	        doctypeString: '',       // enter a different doctype for older markup
	        removeScripts: false,       // remove script tags from print content
	        copyTagClasses: false,      // copy classes from the html & body tag
	        beforePrintEvent: null,     // function for printEvent in iframe
	        beforePrint: null,          // function called before iframe is filled
	        afterPrint: reloadPage            // function called before iframe is removed
	    });
	}
	
/**HUID Admin**/
	printHuidAdmin=function () {	
		var i=1;
		
		var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
	    					    var trtags;
	    					    var totalWeight=0;
	    					    var totalQty=0;
	    					    var totalAmt=0;
	    					    
	    					    var cgst=0;
	    					   var gstamt= $('#gstRateId').val();
	    					   if(""!==gstamt){
	    						   cgst =parseFloat("0"+gstamt) / 2;
	    					   }else{
	    						   gstamt=0;
	    					   }
	    					   var subtotal=$('#subtotal').val();
	    					   var discountAmt=$("#discountAmt").val();
	    					   if(""!==discountAmt)
	    						 {
	    						    subtotal =parseFloat("0"+subtotal) - parseFloat("0"+discountAmt);
	    						    	
	    						 }else
	    							 {
	    							 discountAmt="0.0";
	    							 }
	    					   var grandTotal= Math.round(parseFloat("0"+subtotal) + parseFloat("0"+gstamt));
	    					    $("#hallMarkTbl > tbody > tr").each(function () {
	    					       // alert($(this).find('td:eq(0)').find('input').val() + " " + $(this).find('td:eq(0)').find('input:eq(1)').val() );
	    			if(i==1)	{	   
	    			trtags="<tr style='border: 1px solid black;border-collapse: collapse;'>"
	    					     +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+i+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(0)').find('input:eq(2)').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(3)').find('input').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(1)').find('input').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>0</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>0</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>0</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(4)').find('input').val()+"</td>"
	    					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(5)').find('input').val()+"</td>"
	    					       +"</tr>";
	    			}else{
	    				trtags=trtags+ "<tr style='border: 1px solid black;border-collapse: collapse;'>"
					     +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+i+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(0)').find('input:eq(2)').val()+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(3)').find('input').val()+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(1)').find('input').val()+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>0</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>0</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>0</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(4)').find('input').val()+"</td>"
					        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+$(this).find('td:eq(5)').find('input').val()+"</td>"
					       +"</tr>";
	    			}
	    					       i++;
	    				totalWeight=totalWeight+ parseFloat("0"+($(this).find('td:eq(2)').find('input').val()));
	    				totalQty=totalQty+ parseFloat("0"+($(this).find('td:eq(1)').find('input').val()));
	    				totalAmt=totalAmt+ parseFloat("0"+($(this).find('td:eq(5)').find('input').val()));
	    					    });
	    			//alert(trtags);
	    			
	   //var print_window = window.open();
	    var print_document='<html><head>'
	        +'<style>@media print { @page{size:  auto;margin: 150px 0px 0px 0px;}'
	        +'body{'
	    	+'width: 480px;'
	    	+'font-family: Arial;'
	    	+'}}' 
	        +'table, th, td {'
	        +'border: 1px solid black;'
	        +'border-collapse: collapse;'
	        +'}'
	        +'.row{flex-wrap: wrap;display: flex;}</style></head>';
	    print_document  = print_document+"<body style='line-height: 1.5;font-size: 12px;margin-top: 150px;width: 480px;'><div class='container' id='myPrint' style='margin-left: 10px;margin-right: 10px;width: 100%;border: 1px solid black;border-collapse: collapse;'><div class='row' style='flex-wrap: wrap;display: flex;'>"
										+"<div class='col' style='font-size: 12px;line-height: 1.5;position: relative;width: 30%;padding-right: 15px;padding-left: 15px;display: inline-block;'>Rec. No.:"+$('#invoiceNo').val()+"</div>"
			    						//+"<div class='col' style='line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;'><img src='project/images/invoice.png' max-width: 100%; height: auto; th:src='@{project/images/invoice.png}'></div>"
			    						+"<div class='col' style='font-size: 12px;line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'>Date: "+formatDate($('#billDate').val())+"</div>"
			    						+"<br/></div>"
			    						+"<div class='row' style='text-align:center;'><div class='col' style='font-size: 12px;text-align:center;line-height: 1.5;position: relative;width: 100%;'>TAX INVOICE CUM DELIVERY CHALLAN</div></div> "
			    						
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex;'>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;position: relative;padding-right: 15px;padding-left: 1px;'>GSTIN NO : 27AAZFM7452P1Z2</div>"
	    						+"<div class='col' style='font-size: 12px;line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;text-align: right;'>(Original for Recipient/Duplicate for Supplier)</div>"
	    						+"</div>"
	    						
	    						+"<div class='row'>"
	    						+"<table class='table' style='width:100%;border: 1px solid black;border-collapse: collapse;'>"
	    					    +"<tbody>"
	    					      +"<tr style='border: 1px solid black;border-collapse: collapse;'>"
	    					      +"<td style='border: 1px solid black;border-collapse: collapse;'>"
	    					      +"<div class='row' style='font-size: 12px;line-height: 1.5;flex-wrap: wrap;display: flex;margin-left: 1px;'>Name:"+$('#partyName').val()+"</div>"
	    					      +"<div class='row' style='font-size: 12px;line-height: 1.5;flex-wrap: wrap;display: flex;margin-left: 1px;'>Address:"+options+"</div>"
	    					      +"</td>"
	    					      +"<td style='border: 1px solid black;border-collapse: collapse;width: 40%;'>"
	    					      +"<div class='row' style='font-size: 12px;line-height: 1.5;flex-wrap: wrap;display: flex;text-align: right;margin-left: 1px;'>Invoice No. : "+$('#invoiceNo').val()+"</div>"
	    					      +"<div class='row' style='font-size: 12px;line-height: 1.5;flex-wrap: wrap;display: flex;text-align: right;margin-left: 1px;'>Date : "+formatDate($('#billDate').val())+"</div>"
	    					      +"</td>"
	    					      +"</tr>"
	    					      
	    					      +"<tr style='border: 1px solid black;border-collapse: collapse;'>"
	    					      +"<td style='border: 1px solid black;border-collapse: collapse;'>"
	    					      +"<div class='row' style='font-size: 12px;line-height: 1.5;flex-wrap: wrap;display: flex;margin-left: 1px;'>Place of Supply : MAHARASHTRA      State Code:  27</div>"
	    					      +"</td>"
	    					      +"<td style='border: 1px solid black;border-collapse: collapse;width: 20%;'>"
	    					      +"<div class='row' style='font-size: 12px;line-height: 1.5;flex-wrap: wrap;display: flex;text-align: right;margin-left: 1px;'>SAC : 998346 </div>"
	    					      +"<div class='row' style='font-size: 12px;line-height: 1.5;flex-wrap: wrap;display: flex;text-align: right;margin-left: 1px;'>Your D.C.No :  </div>"
	    					      +"<div class='row' style='font-size: 12px;line-height: 1.5;flex-wrap: wrap;display: flex;margin-left: 1px;'>D.C. Date : "+formatDate($('#billDate').val())+"</div>"
	    					      +"</td>"
	    					      +"</tr>"
	    					      +"</tbody>"
	    					      +"</table>"
								/*+"</div>"
	    						+"<div class='row' style='flex-wrap: wrap;display: flex;'>"*/
	    						+"<table class='table' style='width:100%;border: 1px solid black;border-collapse: collapse;'>"
	    					    +"<thead>"
	    					      +"<tr style='border: 1px solid black;border-collapse: collapse;'>"
	    					      +"<th scope='col' rowspan='2' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Sr No.</th>"
	    					        +"<th scope='col' rowspan='2' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 20%;'>Description</th>"
	    					        +"<th scope='col' rowspan='2' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;'>Purity</th>"
	    					        +"<th scope='col' colspan='4' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;text-align: center;'>No of Pcs</th>"
	    					        +"<th scope='col' rowspan='2' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;'>Rate</th>"
	    					        +"<th scope='col' rowspan='2' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;'>Amount</th>"
	    					        +"</tr>"
	    					        
	    					        +"<tr style='border: 1px solid black;border-collapse: collapse;'>"
		    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;'>H/M</th>"
		    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;'>Rej</th>"
		    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;'>Melt</th>"
		    					        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;'>Rtn</th>"
		    					     +"</tr>"
	    					    +"</thead> "
	    					    +"<tbody>";
	    					    
	    					   
	    					    print_document=  print_document+ trtags +"</tbody>"
	    					    +"<tfoot><tr><td colspan='3' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'><b>Weight Received:</b> "+totalWeight+"</td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>"+totalQty+"</td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>0</td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>0</td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>0</td>"
	    					    +"<td colspan='2' style='text-align: right;font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>"+totalAmt+"</td>"
	    					    +"</tr>"
	    					    
		    					    +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    	    				 	+"<td rowspan='4' colspan='3'></td>"
	    					     	+"<td colspan='5' style='text-align: right;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Discount</td>"
	    					        +"<td colspan='2' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>"+discountAmt+"</td>"
	    					        +"</tr>"
	    	    				 	+"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					     	+"<td colspan='5' style='text-align: right;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>CGST @ 9.00%</td>"
	    					        +"<td colspan='2' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>"+cgst+"</td>"
	    					        +"</tr>"
	    					        +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					        +"<td colspan='5' style='text-align: right;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>SGST @ 9.00%</td>"
	    					        +"<td colspan='2' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>"+cgst+"</td>"
	    					        +"</tr>"
	    					        +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					        +"<td colspan='5' style='text-align: right;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>IGST @ 0.00%</td>"
	    					        +"<td colspan='2' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>0.0</td>"
	    					        +"</tr>"
	    					    +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					    +"<td colspan='8' style='text-align: right;border: 1px solid black;border-collapse: collapse;'><b>Amount Payable (In Rupees)</b></td>"
	    					    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>"+grandTotal+"</td>"
	    					    +"</tr>"
	    					    
	    					    +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					    +"<td colspan='9' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'><b>Amount in Words.</b> "+convertNumberToWords(grandTotal)+" ONLY</td>"
	    					    +"</tr>"
	    					    
	    					    +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					    +"<td colspan='4' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Recd. The precious metal/ jewellery in satisfactory condition"
	    					    	+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    					    	+"<div class='col' style='line-height: 1.5;position: relative;width: 70%;padding-right: 15px;padding-left: 15px;display: inline-block;'><br/><br/>Customer Signature <br/>"
	    						+"</div>"
	    						+"</div>"
	    					    +"</td>"
	    					    +"<td rowspan ='2' colspan='5' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>For MAHALAXMI HALLMARK CENTER"
	    					    +"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    						+"<div class='col' style='line-height: 1.5;text-align: end;position: relative;width: 70%;padding-right: 15px;padding-left: 15px;display: inline-block;'><br/><br/>Authorized Signature <br/>"
	    						+"</div>"
	    						+"</div>"
	    						+"</td>"
	    					    +"</tr>"
	    					    +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    					    +"<td colspan='4' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>By Courier/ By Hand"
	    					    +"</td>"
	    					    +"</tr>"
	    					    +"</tfoot>"
		    					+"</table></div>"
	    						
	    						+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex;'></div>"
	    						
	    						
	   							+"</div></body>";
	    //print_window.document.open();
	   // print_window.document.write(print_document);
	    //print_window.document.close();
	    //print_window.print();
	   //print_window.close();
	    $("#myPrint").printThis({
	        debug: true,               // show the iframe for debugging
	        importCSS: false,            // import parent page css
	        importStyle: true,         // import style tags
	        printContainer: true,       // print outer container/$.selector
	        loadCSS: "",                // path to additional css file - use an array [] for multiple
	        pageTitle: "HUID Bill",              // add title to print page
	        removeInline: false,        // remove inline styles from print elements
	        removeInlineSelector: "*",  // custom selectors to filter inline styles. removeInline must be true
	        printDelay: 333,            // variable print delay
	        header: print_document,               // prefix to html
	        footer: null,               // postfix to html
	        base: false,                // preserve the BASE tag or accept a string for the URL
	        formValues: true,           // preserve input/form values
	        canvas: false,              // copy canvas content
	        doctypeString: '',       // enter a different doctype for older markup
	        removeScripts: false,       // remove script tags from print content
	        copyTagClasses: false,      // copy classes from the html & body tag
	        beforePrintEvent: null,     // function for printEvent in iframe
	        beforePrint: null,          // function called before iframe is filled
	        afterPrint: reloadPage            // function called before iframe is removed
	    });
	     /*var doc = document.getElementById('frame').contentWindow.document;
	     doc.open();
	     doc.write("<style>@media print {'@page{size: 3in;}'</style>");
	     doc.write(print_document);
	     doc.close();*/
	     //document.getElementById('frame').contentWindow.focus();
	    // document.getElementById('frame').contentWindow.print();
	};
	
function convertNumberToWords(amount) {
		
	    var words = new Array();
	    words[0] = '';
	    words[1] = 'One';
	    words[2] = 'Two';
	    words[3] = 'Three';
	    words[4] = 'Four';
	    words[5] = 'Five';
	    words[6] = 'Six';
	    words[7] = 'Seven';
	    words[8] = 'Eight';
	    words[9] = 'Nine';
	    words[10] = 'Ten';
	    words[11] = 'Eleven';
	    words[12] = 'Twelve';
	    words[13] = 'Thirteen';
	    words[14] = 'Fourteen';
	    words[15] = 'Fifteen';
	    words[16] = 'Sixteen';
	    words[17] = 'Seventeen';
	    words[18] = 'Eighteen';
	    words[19] = 'Nineteen';
	    words[20] = 'Twenty';
	    words[30] = 'Thirty';
	    words[40] = 'Forty';
	    words[50] = 'Fifty';
	    words[60] = 'Sixty';
	    words[70] = 'Seventy';
	    words[80] = 'Eighty';
	    words[90] = 'Ninety';
	    amount = amount.toString();
	    var atemp = amount.split(".");
	    var number = atemp[0].split(",").join("");
	    var n_length = number.length;
	    var words_string = "";
	    if (n_length <= 9) {
	        var n_array = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0);
	        var received_n_array = new Array();
	        for (var i = 0; i < n_length; i++) {
	            received_n_array[i] = number.substr(i, 1);
	        }
	        for (var i = 9 - n_length, j = 0; i < 9; i++, j++) {
	            n_array[i] = received_n_array[j];
	        }
	        for (var i = 0, j = 1; i < 9; i++, j++) {
	            if (i == 0 || i == 2 || i == 4 || i == 7) {
	                if (n_array[i] == 1) {
	                    n_array[j] = 10 + parseInt(n_array[j]);
	                    n_array[i] = 0;
	                }
	            }
	        }
	        value = "";
	        for (var i = 0; i < 9; i++) {
	            if (i == 0 || i == 2 || i == 4 || i == 7) {
	                value = n_array[i] * 10;
	            } else {
	                value = n_array[i];
	            }
	            if (value != 0) {
	                words_string += words[value] + " ";
	            }
	            if ((i == 1 && value != 0) || (i == 0 && value != 0 && n_array[i + 1] == 0)) {
	                words_string += "Crores ";
	            }
	            if ((i == 3 && value != 0) || (i == 2 && value != 0 && n_array[i + 1] == 0)) {
	                words_string += "Lakhs ";
	            }
	            if ((i == 5 && value != 0) || (i == 4 && value != 0 && n_array[i + 1] == 0)) {
	                words_string += "Thousand ";
	            }
	            if (i == 6 && value != 0 && (n_array[i + 1] != 0 && n_array[i + 2] != 0)) {
	                words_string += "Hundred and ";
	            } else if (i == 6 && value != 0) {
	                words_string += "Hundred ";
	            }
	        }
	        words_string = words_string.split("  ").join(" ");
	    }
	    return words_string.toUpperCase();
	}
	
	function formatDate(userDate) {
		
		var date    = new Date(userDate),
	    yr      = date.getFullYear(),
	    month   = (date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : (date.getMonth() + 1),
	    day     = date.getDate()  < 10 ? '0' + date.getDate()  : date.getDate(),
	    newDate = day  + '-' + month + '-' + yr;
	    
	     return newDate;
	 }
})(jQuery);