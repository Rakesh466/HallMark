insert into roles (role_id, role) values (1 , 'ADMIN');
insert into roles (role_id, role) values (2 , 'USER');

insert into users (user_id, active, last_name, name, password, user_name) values
(1, 1, 'hallmark', 'mahalaxmi-admin', 'admin123', 'admin');
insert into users (user_id, active, last_name, name, password, user_name) values
(2, 1, 'hallmark', 'mahalaxmi-user', 'user123', 'user');

insert into user_role (user_id, role_id) values (1,1);
insert into user_role (user_id, role_id) values (2,2);
