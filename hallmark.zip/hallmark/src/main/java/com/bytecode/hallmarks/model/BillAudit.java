package com.bytecode.hallmarks.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "BILL_AUDIT")
public class BillAudit {

		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		@Column(name = "id")
		private Long billAuditId;
		
		 @Column(name = "INVOICE_NO")
		 private Integer invoiceNo;
		 	
	 	@Column(name = "RECEIVED_AMT")
	    private Double receivedAmount;
	    
	    @Column(name = "BALANCE_AMT")
	    private Double balanceAmount;
	    
	    @Column(name = "OLD_RECEIVED_AMT")
	    private Double oldReceivedAmount;
	    
	    @Column(name = "OLD_BALANCE_AMT")
	    private Double oldBalanceAmount;
	    
	    @Column(name = "SUB_TOTAL")
	    private Double subTotal;
	    
	    @Column(name = "CREATED_BY")
	    private String createdBy;
	    
	    @Column(name = "CREATED_DATE")
	    private Timestamp createdDate;

		public Long getBillAuditId() {
			return billAuditId;
		}

		public void setBillAuditId(Long billAuditId) {
			this.billAuditId = billAuditId;
		}

		public Integer getInvoiceNo() {
			return invoiceNo;
		}

		public void setInvoiceNo(Integer invoiceNo) {
			this.invoiceNo = invoiceNo;
		}

		public Double getReceivedAmount() {
			return receivedAmount;
		}

		public void setReceivedAmount(Double receivedAmount) {
			this.receivedAmount = receivedAmount;
		}

		public Double getBalanceAmount() {
			return balanceAmount;
		}

		public void setBalanceAmount(Double balanceAmount) {
			this.balanceAmount = balanceAmount;
		}

		public Double getOldReceivedAmount() {
			return oldReceivedAmount;
		}

		public void setOldReceivedAmount(Double oldReceivedAmount) {
			this.oldReceivedAmount = oldReceivedAmount;
		}

		public Double getOldBalanceAmount() {
			return oldBalanceAmount;
		}

		public void setOldBalanceAmount(Double oldBalanceAmount) {
			this.oldBalanceAmount = oldBalanceAmount;
		}

		public Double getSubTotal() {
			return subTotal;
		}

		public void setSubTotal(Double subTotal) {
			this.subTotal = subTotal;
		}

		public String getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}

		public Timestamp getCreatedDate() {
			return createdDate;
		}

		public void setCreatedDate(Timestamp createdDate) {
			this.createdDate = createdDate;
		}
	    
}
