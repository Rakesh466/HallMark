package com.bytecode.hallmarks.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "BILL_ENTRY_DETAIL")
public class BillEntryDetail {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "INVOICE_DTL_NO")
    private Integer invoiceDtlNo;
	
	/*
	 * @ManyToOne(fetch = FetchType.LAZY)
	 * 
	 * @JoinColumn(foreignKey = @ForeignKey(name = "INVOICE_NO"), name =
	 * "INVOICE_NO") private BillEntryHeader billEntryHeader;
	 */
	
    @Column(name = "INVOICE_NO")
	//@Transient
    private Integer invoiceNo;
    
    @Column(name = "BILL_TYPE")
    private String billType;
    
    @Column(name = "ITEM_NAME")
    private String itemName;
    
    @Column(name = "QUANTITY")
    private Integer quantity;
    
    @Column(name = "ITEM_WEIGHT")
    private Float itemWeight;
    
    @Column(name = "PURITY")
    private String purity;
    
    @Column(name = "RATE")
    private Double rate;
    
    @Column(name = "AMOUNT")
    private Double amount;
    
    @Column(name = "CUSTOMER_NAME")
    private String customerName;
    
    @Column(name = "GROSS_WEIGHT")
    private Float grossWeight;
    
    @Column(name = "NET_WEIGHT")
    private Float netWeight;
    
    @Column(name = "EXTRA_MARK")
    private String extraMark;
    
    @Column(name = "LASER_MARK")
    private String laserMark;
    
    @Column(name = "CREATED_BY")
    private String createdBy;
    
    @Column(name = "UPDATED_BY")
    private String updatedBy;
    
    @Column(name = "CREATED_DATE")
    private Timestamp createdDate;
    
    @Column(name = "UPDATED_DATE")
    private Timestamp updatedDate;
    @Transient
    private String isdeleted;
    
	public Integer getInvoiceDtlNo() {
		return invoiceDtlNo;
	}

	public void setInvoiceDtlNo(Integer invoiceDtlNo) {
		this.invoiceDtlNo = invoiceDtlNo;
	}

	public Integer getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(Integer invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getBillType() {
		return billType;
	}

	public void setBillType(String billType) {
		this.billType = billType;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Float getItemWeight() {
		return itemWeight;
	}

	public void setItemWeight(Float itemWeight) {
		this.itemWeight = itemWeight;
	}

	public String getPurity() {
		return purity;
	}

	public void setPurity(String purity) {
		this.purity = purity;
	}

	public Double getRate() {
		return rate;
	}

	public void setRate(Double rate) {
		this.rate = rate;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Float getGrossWeight() {
		return grossWeight;
	}

	public void setGrossWeight(Float grossWeight) {
		this.grossWeight = grossWeight;
	}

	public Float getNetWeight() {
		return netWeight;
	}

	public void setNetWeight(Float netWeight) {
		this.netWeight = netWeight;
	}

	public String getExtraMark() {
		return extraMark;
	}

	public void setExtraMark(String extraMark) {
		this.extraMark = extraMark;
	}

	public String getLaserMark() {
		return laserMark;
	}

	public void setLaserMark(String laserMark) {
		this.laserMark = laserMark;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public Timestamp getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getIsdeleted() {
		return isdeleted;
	}

	public void setIsdeleted(String isdeleted) {
		this.isdeleted = isdeleted;
	}
}
