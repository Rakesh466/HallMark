package com.bytecode.hallmarks.service;

import java.text.ParseException;
import java.time.Instant;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bytecode.hallmarks.controller.BillEntryController;
import com.bytecode.hallmarks.model.DayToDayExpenses;
import com.bytecode.hallmarks.model.PartyMaster;
import com.bytecode.hallmarks.repository.DayToDayExpensesRepository;
import com.bytecode.hallmarks.repository.PartyMasterRepository;
import com.bytecode.hallmarks.util.HallMarkUtil;

@Service
@Transactional
public class DayToDayExpensesService {
	public static final Logger logger = LoggerFactory.getLogger(DayToDayExpensesService.class);

	@Autowired
	private DayToDayExpensesRepository repo;

	public List<DayToDayExpenses> listAll() {
		return repo.findAll();
	}

	public void save(DayToDayExpenses dayToDayExpenses) {
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (dayToDayExpenses.getDayToDayExpCode() == 0) {
			dayToDayExpenses.setActive(true);
			dayToDayExpenses.setCreatedBy(userDetails.getUsername());
			dayToDayExpenses.setCreatedDate(Instant.now());
		} else {
			dayToDayExpenses.setActive(true);
			dayToDayExpenses.setModifiedBy(userDetails.getUsername());
			dayToDayExpenses.setModifiedDate(Instant.now());
		}
		dayToDayExpenses.setActive(true);
		repo.save(dayToDayExpenses);
	}

	public DayToDayExpenses get(Integer id) {
		return repo.findById(id).get();
	}

	public void delete(Integer id) {
		repo.deleteById(id);
	}
	
	public Paged<DailyReport> cashDayBook(java.sql.Date fromDate, java.sql.Date toDate, int pageNumber, int size) {
		PageRequest request=PageRequest.of(pageNumber - 1, size,Sort.by("payment_date").descending());
		logger.info("==========="+fromDate);
		logger.info("==========="+toDate);
        Page<DailyReport> postPage = repo.findAllcashDayBookByTransationDateBetween(fromDate, toDate, request);
        logger.info("==========="+postPage.get().count());
        return new Paged<>(postPage, Paging.of(postPage.getTotalPages(), pageNumber, size));
	}
	
	public List<DailyReport> findAllCashDayBook(java.sql.Date fromDate, java.sql.Date toDate) {
		return repo.findAllCashDayBook(fromDate, toDate);
	}
	
	public List<Double> fetchSummary(java.sql.Date fromDate, java.sql.Date toDate) {
		return repo.fetchSummary(fromDate, toDate);
	}

}
