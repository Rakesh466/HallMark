package com.bytecode.hallmarks.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.bytecode.hallmarks.model.RateMaster;

public interface RateMasterRepository extends JpaRepository<RateMaster, Integer> {

	@Query("from RateMaster where active=true ")
	public List<RateMaster> rateMasterList();
	
	
	@Query(value = "select * from ratemaster where active='1'",countQuery = "select count(1) from ratemaster where active='1'", nativeQuery = true)
	public Page<RateMaster> fetchRateDtl(Pageable aInPageable);

}
