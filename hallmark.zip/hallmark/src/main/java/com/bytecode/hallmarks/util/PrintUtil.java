package com.bytecode.hallmarks.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bytecode.hallmarks.model.BillEntryDetail;
import com.bytecode.hallmarks.model.BillEntryHeader;
import com.bytecode.hallmarks.service.BillEntryConstant;
import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.html2pdf.resolver.font.DefaultFontProvider;
import com.itextpdf.io.font.otf.GlyphLine;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfString;
import com.itextpdf.kernel.pdf.PdfViewerPreferences;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.WriterProperties;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.font.FontProvider;
import com.itextpdf.layout.property.Property;
import com.itextpdf.layout.splitting.DefaultSplitCharacters;
@Service
public class PrintUtil {
	
	@Value("${gstin.no}")
	private String gstinNo;
	
	@Value("${place.Of.supply}")
	private String placeOfSupply;
	
	@Value("${state.code}")
	private String stateCode;
	
	@Value("${sac}")
	private String sac;
	
	public byte[] generatePDF(String print_document,String fileName,String pageSize) throws IOException, ParseException {

		
	    ByteArrayOutputStream target = new ByteArrayOutputStream();
        FileOutputStream fileOutputStream = new FileOutputStream(new File(fileName));

		ConverterProperties converterProperties = new ConverterProperties();
		    					  
		WriterProperties writerProperties = new WriterProperties();
		    			            
		writerProperties.addXmpMetadata();
		
		PdfViewerPreferences pdfViewerPreferences = new PdfViewerPreferences();
		pdfViewerPreferences.setDisplayDocTitle(true);
		
		FontProvider dfp = new DefaultFontProvider(true, true, false);

		/* Temporary fix for display issue with blocks (in current html2pdf version (2.0.1) */
		converterProperties.setFontProvider(dfp);
		converterProperties.setTagWorkerFactory(new LabelBlockCssApplierFactory());
		//Document document =HtmlConverter.convertToDocument(print_document, pdfDoc, converterProperties);
		    			           // pdfDoc.close();
		PdfWriter pdfWriterSave = new PdfWriter(fileOutputStream, writerProperties);
		    			           
		PdfDocument pdfDocumentSave = new PdfDocument(pdfWriterSave);
	        
	//For setting the PAGE SIZE
		if(BillEntryConstant.PAGE_SIZE_A4.equals(pageSize)) {
			//pdfDocumentSave.setDefaultPageSize(new PageSize(PageSize.A4));
			pdfDocumentSave.setDefaultPageSize(new PageSize(new Rectangle(375, 792)));
		}else {
			pdfDocumentSave.setDefaultPageSize(new PageSize(new Rectangle(216, 792)));
		}
		pdfDocumentSave.getCatalog().setLang(new PdfString("en-US"));
		    			            //Set the document to be tagged
		pdfDocumentSave.setTagged(); 
		pdfDocumentSave.getCatalog().setViewerPreferences(pdfViewerPreferences);
		    			            
		Document documentHtml= HtmlConverter.convertToDocument(print_document, pdfDocumentSave, converterProperties);
		  			            
		documentHtml.setProperty(Property.SPLIT_CHARACTERS,new DefaultSplitCharacters(){
		@Override
		public boolean isSplitCharacter(GlyphLine text, int glyphPos) {
		    		  return true;
		    }
		});
	   documentHtml.close();
	   // HtmlConverter.convertToPdf(print_document, target,converterProperties); 
	    byte[] bytes = target.toByteArray();
	  return  bytes; 
}

	public String createTunchHtml(BillEntryHeader billEntryH,String billType) throws ParseException {
		List<BillEntryDetail> billEntryDetailList = null;
	    double totalWeight=0;
	    double totalQty=0;
	    double totalAmt=0;
		String billDetails="";
		int i=1;
		if(BillEntryConstant.TUNCH.equals(billType)) {
			billEntryDetailList=billEntryH.getTunchList();
		}else if(BillEntryConstant.LESSER.equals(billType)){
			billEntryDetailList=billEntryH.getLesserList();
		}
		System.out.println("billEntryDetailList::"+billEntryDetailList.size());
		for(BillEntryDetail billEntryDetail:billEntryDetailList) {
			
			billDetails+="<tr>"
		     +"<td style='font-size: 12px;'>"+i+"</td>"
		        +"<td style='word-wrap: break-word;min-width: 60px;max-width: 60px;font-size: 12px;'>"+billEntryDetail.getItemName()+"</td>"
		        +"<td style='font-size: 12px;'>"+billEntryDetail.getItemWeight()+"</td>"
		        +"<td style='font-size: 12px;'>"+billEntryDetail.getQuantity()+"</td>"
		        +"<td style='font-size: 12px;'>"+(null!=billEntryDetail.getRate() ? Math.round(billEntryDetail.getRate()) : 0)+"</td>"
		        +"<td style='font-size: 12px;'>"+(null!=billEntryDetail.getAmount() ? Math.round(billEntryDetail.getAmount()) :0)+"</td>";
		        
			if(BillEntryConstant.LESSER.equals(billType)) {
		        	billDetails+= "<td style='font-size: 12px;'>"+(null!=billEntryDetail.getLaserMark() ? billEntryDetail.getLaserMark() : "")+"</td>";
		        }
		        
			billDetails+="</tr>";
			i++;
			totalWeight=totalWeight+ (null!=billEntryDetail.getItemWeight() ? billEntryDetail.getItemWeight():0);
			totalQty=totalQty+ (null!=billEntryDetail.getQuantity() ? Math.round(billEntryDetail.getQuantity()):0);
			totalAmt=totalAmt+ (null!=billEntryDetail.getAmount() ? Math.round(billEntryDetail.getAmount()) :0);
		}

	    String print_document="<html><head>"
	    		+"<style>@media print {  @page "
	    		+"{"
	    		+"    size:  auto; "
	    		+"    margin: 0mm; "
	    		+" }"
	    		+"body{"
	    	+" width: 80mm;"
	    	+"font-family: Arial;"
	    	+"}" 
	    	+"}" 
	    	+"th{border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;}"
	    	+"}"
	    	+"</style>"
	    	+"</head>";
	    	print_document  = print_document+"<html><head><style>@media print { @page{size:  auto;margin:0px auto;}}</style></head><body class='media' style='font-family: Arial;line-height: 1.5;font-size: 12;width: 80mm;'><div class='container' id='myPrint' style='margin-left: 5px;margin-right: 10px;'><div class='row' style='flex-wrap: wrap;display: flex;'>"
	    					+"<div class='col' style='line-height: 1.5;position: relative;display: inline-block;'></div>"
	    					//+"<div class='col' style='line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;'><img src='project/images/invoice.png' max-width: 100%; height: auto; th:src='@{project/images/invoice.png}'></div>"
	    					+"<div class='col' style='line-height: 1.5;position: relative;width: 100%;padding-right: 13px;display: inline-block;text-align: right;'><h1 class='preview' data-content='CodePen' style='box-sizing: border-box;font-family: Arial, sans-serif;font-size: 1em;font-weight: bold;position: relative;z-index: 1;display: inline-block;-webkit-font-smoothing: antialiased;-moz-osx-font-smoothing: grayscale;color: black;width: 30%;height: 55%;margin-top: 5px;text-align: center;'>Invoice</h1></div>"
	    					//+"<div class='col' style='margin-top: 5px;line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'><img src='/mahalaxmihallmarking/project/images/invoice.png' max-width: 100%; height: auto; th:src='@{/mahalaxmihallmarking/project/images/invoice.png}'></div>"
	    					+"</div>"

	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex;'>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;width: 60%;line-height: 1.5;position: relative;display: inline-block;overflow-wrap: break-word;'>Party Name:"+billEntryH.getPartyName()+"</div>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;width: 40%;line-height: 1.5;position: relative;display: inline-block;'> Bill No.:"+billEntryH.getInvoiceNo()+"</div>"
	    			+"</div>"
	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex;'>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;width: 60%;line-height: 1.5;position: relative;display: inline-block;'></div>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;line-height: 1.5;position: relative;width: 40%;display: inline-block;'>Date : "+HallMarkUtil.convertDateToString(billEntryH.getBillDate(),"dd-MM-yyyy")+"</div>"
	    			+"</div>"
	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; '>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;width: 60%;line-height: 1.5;position: relative;display: inline-block;'></div>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;position: relative;width: 40%;display: inline-block;'>Bill Type : "+billType+"</div>"
	    			+"</div>"
	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -5px;'>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;line-height: 1.5;position: relative;width: 90%;padding-right: 15px;padding-left: 10px;display: inline-block;text-align: center;'>"+billType+ " Details<br></div>"
	    			+"<br></div>"
	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"

	    			+"<div class='col' style='width: 100%;line-height: 1.5;float:right;position: relative;padding-right: 15px;padding-left: 15px;display: inline-block;'>"
	    			+"<table class='table' style='width: 95%;'>"
	    		    +"<thead>"
	    		      +"<tr>"
	    		      +"<th scope='col' style='font-size: 12;'>#</th>"
	    		        +"<th scope='col' style='font-size: 12;text-align: left;width: 20%;'>Particulars</th>"
	    		        +"<th scope='col' style='font-size: 12;text-align: left;'>Weight</th>"
	    		        +"<th scope='col' style='font-size: 12;text-align: left;'>Qty</th>"
	    		        +"<th scope='col' style='font-size: 12;text-align: left;'>Rate</th>"
	    		        +"<th scope='col' style='font-size: 12;text-align: left;'>Amt</th>";
	    		        
			if(BillEntryConstant.LESSER.equals(billType)) {
				print_document  = print_document+"<th scope='col' style='font-size: 12;text-align: left;'>L.M.</th>";
				}
			print_document  = print_document+"</tr>"
	    		    +"</thead> "
	    		    +"<tbody>";
	    		    
	    print_document=  print_document+ billDetails +"</tbody>"
	    		    +"<tfoot><tr><td style='font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'></td><td style='font-family: Arial;font-size: 12px;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'>Total:</td>"
	    		    +"<td style='font-family: Arial;font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'>"+totalWeight+"</td>"
	    		    +"<td style='font-family: Arial;font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'>"+Math.round(totalQty)+"</td>"
	    		    +"<td style='font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'></td>"
	    		    +"<td style='font-family: Arial;font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'>"+Math.round(totalAmt)+"</td>";
	    		   if(BillEntryConstant.LESSER.equals(billType)) {
				print_document  = print_document+"<td style='font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'></td>";
				}
	    		   print_document  = print_document +"</tr></tfoot>"
	    		    +"</table></div>"
	    				+"</div>"
	    			+"<div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    			+"<div class='col' style='float:right;position: relative;width: 75%;padding-right: 15px;padding-left: 15px;display: inline-block;'>"

	    			+"<table class='table2' style='width:95%;margin-left: 50px;margin-top: 5px;'>"
	    		    +"<tbody>"
	    			 	
	    		        
	    		        +"<tr style='font-size: 12;'>"
	    		        +"<td style='font-family: Arial;font-size: 12;'>Received Amt:</td>"
	    		        +"<td style='font-family: Arial;font-size: 12;'>"+(null!=billEntryH.getReceivedAmount() ? Math.round(billEntryH.getReceivedAmount()) : 0)+"</td>"
	    		        +"</tr>"
	    		        +"<tr style='font-size: 12;'>"
	    		        +"<td style='font-family: Arial;font-size: 12;'>Balance:</td>"
	    		        +"<td style='font-family: Arial;font-size: 12;'>"+(null!=billEntryH.getBalanceAmount() ? Math.round(billEntryH.getBalanceAmount()) : 0)+"</td>";
	    		      
	    if(BillEntryConstant.LESSER.equals(billType)) {
	    					print_document  = print_document+"<td style='font-family: Arial;font-size: 12;'></td>";
	    					}
	    		        print_document  = print_document+"</tr>"
	    		        
	    		    +"</tbody></table>"
	    		    +"</div>"
	    			+"</div>"
	    			+"<div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;position: relative;padding-right: 15px;padding-left: 15px;display: inline-block;'><br>RECEIVED RS. "+NumberToWords.convert(Math.round((null!=billEntryH.getReceivedAmount() ? billEntryH.getReceivedAmount() : 0)))+" ONLY"
	    			
	    			+"</div>"
	    			+"</div>"
	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'></div>"
	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    			//+"<div class='col' style='font-family: Arial;font-size: 12;line-height: 1.5;text-align: end;float:right;position: relative;width: 90%;padding-right: 15px;padding-left: 15px;display: inline-block;'><br/><br/><span style='text-align: right;float:right;'>Authorized Sign</span><br/>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;line-height: 1.5;text-align: right;float:right;position: relative;width: 80%;padding-right: 15px;padding-left: 15px;display: inline-block;'><br/><br/><span style='text-align: right;margin-right: 10px;'>Authorized Sign</span><br/>"

	    			+"</div>"
	    			+"</div>"
	    				+"</div></body>";
	    
	    return print_document;
	}
	public String createMultiBilHtml(BillEntryHeader billEntryH,String billType) throws ParseException {
	    double totalWeight=0;
	    double totalQty=0;
	    double totalAmt=0;
		String billDetails="";
		int i=1;
		
		if(null!=billEntryH.getHallmarkingChk())  {
			if(billEntryH.getHallmarkingChk())  {
				List<BillEntryDetail> hallMarkBillDtl=billEntryH.getHallMarkList();
				if(null!=hallMarkBillDtl || !hallMarkBillDtl.isEmpty())
				{
					for( BillEntryDetail billEntryDetail:hallMarkBillDtl)
					{
						if(!"Y".equals(billEntryDetail.getIsdeleted())){
			
						billDetails+="<tr>"
							+"<td style='font-size: 12px;'>"+i+"</td>"
					        +"<td style='word-wrap: break-word;min-width: 40px;max-width: 40px;font-size: 12px;'>"+billEntryDetail.getItemName()+"</td>"
					        +"<td style='font-size: 12px; text-align: right;'>"+billEntryDetail.getItemWeight()+"</td>"
					        +"<td style='font-size: 12px; text-align: right;'>"+billEntryDetail.getPurity()+"</td>"
					        +"<td style='font-size: 12px; text-align: right;'>"+billEntryDetail.getQuantity()+"</td>"
					        +"<td style='font-size: 12px; text-align: right;'>"+(null!=billEntryDetail.getRate() ? Math.round(billEntryDetail.getRate()) : 0)+"</td>"
					        +"<td style='font-size: 12px; text-align: right;'>"+(null!=billEntryDetail.getAmount() ? Math.round(billEntryDetail.getAmount()) :0)+"</td>"
					        +"<td style='font-size: 10px;width: 115px;'>Huid</td>"
					     +"</tr>";
							i++;
							totalWeight=totalWeight+ (null!=billEntryDetail.getItemWeight() ? billEntryDetail.getItemWeight():0);
							totalQty=totalQty+ (null!=billEntryDetail.getQuantity() ? Math.round(billEntryDetail.getQuantity()):0);
							totalAmt=totalAmt+ (null!=billEntryDetail.getAmount() ? Math.round(billEntryDetail.getAmount()) :0);
						}
					}
				}
			}
		}
		
		if(null!=billEntryH.getCardChk())  {
			if(billEntryH.getCardChk()) {
				List<BillEntryDetail> cardBillDtl=billEntryH.getCardList();
				if(null!=cardBillDtl || !cardBillDtl.isEmpty())
				{
					for( BillEntryDetail billEntryCardDetail:cardBillDtl)
					{
						if(!HallMarkUtil.isEmpty(billEntryCardDetail.getItemName())) {
							billDetails+="<tr>"
									+"<td style='font-size: 12px;'>"+i+"</td>"
							        +"<td style='word-wrap: break-word;min-width: 40px;max-width: 40px;font-size: 12px;'>"+billEntryCardDetail.getItemName()+"</td>"
							        +"<td style='font-size: 12px; text-align: right;'>"+billEntryCardDetail.getNetWeight()+"</td>"
							        +"<td style='font-size: 12px; text-align: right;'>"+billEntryCardDetail.getPurity()+"</td>"
							        +"<td style='font-size: 12px; text-align: right;'>"+(null!=billEntryCardDetail.getQuantity()? Math.round(billEntryCardDetail.getQuantity()):0)+"</td>"
							        +"<td style='font-size: 12px; text-align: right;'>"+(null!=billEntryCardDetail.getRate() ? Math.round(billEntryCardDetail.getRate()) : 0)+"</td>"
							        +"<td style='font-size: 12px; text-align: right;'>"+(null!=billEntryCardDetail.getAmount() ? Math.round(billEntryCardDetail.getAmount()) :0)+"</td>"
							        +"<td style='font-size: 10px;width: 115px;'>Card</td>"
							     +"</tr>";
									i++;
									totalWeight=totalWeight+ (null!=billEntryCardDetail.getNetWeight() ? billEntryCardDetail.getNetWeight():0);
									totalQty=totalQty+ (null!=billEntryCardDetail.getQuantity() ? Math.round(billEntryCardDetail.getQuantity()):0);
									totalAmt=totalAmt+ (null!=billEntryCardDetail.getAmount() ? Math.round(billEntryCardDetail.getAmount()) :0);
						}
					}
		
				}
			}
		}
		

		if(null!=billEntryH.getTunchChk())  {
			if(billEntryH.getTunchChk()) {
				List<BillEntryDetail> tunchBillDtl=billEntryH.getTunchList();
				if(null!=tunchBillDtl || !tunchBillDtl.isEmpty())
				{
					for( BillEntryDetail billEntryTunchDetail:tunchBillDtl)
					{
						if(!HallMarkUtil.isEmpty(billEntryTunchDetail.getItemName())) {
							billDetails+="<tr>"
									+"<td style='font-size: 12px;'>"+i+"</td>"
							        +"<td style='word-wrap: break-word;min-width: 40px;max-width: 40px;font-size: 12px;'>"+billEntryTunchDetail.getItemName()+"</td>"
							        +"<td style='font-size: 12px; text-align: right;'>"+billEntryTunchDetail.getItemWeight()+"</td>"
							        +"<td style='font-size: 12px; text-align: right;'>0</td>"
							        +"<td style='font-size: 12px; text-align: right;'>"+billEntryTunchDetail.getQuantity()+"</td>"
							        +"<td style='font-size: 12px; text-align: right;'>"+(null!=billEntryTunchDetail.getRate() ? Math.round(billEntryTunchDetail.getRate()) : 0)+"</td>"
							        +"<td style='font-size: 12px; text-align: right;'>"+(null!=billEntryTunchDetail.getAmount() ? Math.round(billEntryTunchDetail.getAmount()) :0)+"</td>"
							        +"<td style='font-size: 10px;width: 115px;'>Tunch</td>"
							     +"</tr>";
									i++;
									totalWeight=totalWeight+ (null!=billEntryTunchDetail.getItemWeight() ? billEntryTunchDetail.getItemWeight():0);
									totalQty=totalQty+ (null!=billEntryTunchDetail.getQuantity() ? Math.round(billEntryTunchDetail.getQuantity()):0);
									totalAmt=totalAmt+ (null!=billEntryTunchDetail.getAmount() ? Math.round(billEntryTunchDetail.getAmount()) :0);
						}
					}
		
				}
			}
		}
		
		if(null!=billEntryH.getLesserChk())  {
			if(billEntryH.getLesserChk()) {
				List<BillEntryDetail> lesserBillDtl=billEntryH.getLesserList();
				if(null!=lesserBillDtl || !lesserBillDtl.isEmpty())
				{
					for( BillEntryDetail billEntrylesserDetail:lesserBillDtl)
					{
						
						if(!HallMarkUtil.isEmpty(billEntrylesserDetail.getItemName())) {
							billDetails+="<tr>"
									+"<td style='font-size: 12px;'>"+i+"</td>"
							        +"<td style='word-wrap: break-word;min-width: 40px;max-width: 40px;font-size: 12px;'>"+billEntrylesserDetail.getItemName()+"</td>"
							        +"<td style='font-size: 12px; text-align: right;'>"+billEntrylesserDetail.getItemWeight()+"</td>"
							        +"<td style='font-size: 12px; text-align: right;'>0</td>"
							        +"<td style='font-size: 12px; text-align: right;'>"+billEntrylesserDetail.getQuantity()+"</td>"
							        +"<td style='font-size: 12px; text-align: right;'>"+(null!=billEntrylesserDetail.getRate() ? Math.round(billEntrylesserDetail.getRate()) : 0)+"</td>"
							        +"<td style='font-size: 12px; text-align: right;'>"+(null!=billEntrylesserDetail.getAmount() ? Math.round(billEntrylesserDetail.getAmount()) :0)+"</td>"
							        +"<td style='font-size: 10px;width: 115px;'>Lesser</td>"
							     +"</tr>";
									i++;
									totalWeight=totalWeight+ (null!=billEntrylesserDetail.getItemWeight() ? billEntrylesserDetail.getItemWeight():0);
									totalQty=totalQty+ (null!=billEntrylesserDetail.getQuantity() ? Math.round(billEntrylesserDetail.getQuantity()):0);
									totalAmt=totalAmt+ (null!=billEntrylesserDetail.getAmount() ? Math.round(billEntrylesserDetail.getAmount()) :0);
						}
					}
		
				}
			}
		}
		
	    String print_document="<html><head>"
	    		+"<style>@media print {  @page "
	    		+"{"
	    		+"    size:  auto; "
	    		+"    margin: 0mm; "
	    		+" }"
	    		+"body{"
	    	+" width: 80mm;"
	    	+"font-family: Arial;"
	    	+"}" 
	    	+"}" 
	    	+"th{border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;}"
	    	+"}"
	    	+"</style>"
	    	+"</head>";
	    	print_document  = print_document+"<html><head><style>@media print { @page{size:  auto;margin:0px auto;}}</style></head><body class='media' style='font-family: Arial;line-height: 1.5;font-size: 12;width: 80mm;'><div class='container' id='myPrint' style='margin-left: 5px;margin-right: 10px;'><div class='row' style='flex-wrap: wrap;display: flex;'>"
	    					+"<div class='col' style='line-height: 1.5;position: relative;display: inline-block;'></div>"
	    					//+"<div class='col' style='line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;'><img src='project/images/invoice.png' max-width: 100%; height: auto; th:src='@{project/images/invoice.png}'></div>"
	    					+"<div class='col' style='line-height: 1.5;position: relative;width: 100%;padding-right: 13px;display: inline-block;text-align: right;'><h1 class='preview' data-content='CodePen' style='box-sizing: border-box;font-family: Arial, sans-serif;font-size: 1em;font-weight: bold;position: relative;z-index: 1;display: inline-block;-webkit-font-smoothing: antialiased;-moz-osx-font-smoothing: grayscale;color: black;width: 30%;height: 55%;margin-top: 5px;text-align: center;'>Invoice</h1></div>"
	    					//+"<div class='col' style='margin-top: 5px;line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'><img src='/mahalaxmihallmarking/project/images/invoice.png' max-width: 100%; height: auto; th:src='@{/mahalaxmihallmarking/project/images/invoice.png}'></div>"
	    					+"</div>"

	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex;'>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;width: 60%;line-height: 1.5;position: relative;display: inline-block;overflow-wrap: break-word;'>Party Name:"+billEntryH.getPartyName()+"</div>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;width: 40%;line-height: 1.5;position: relative;display: inline-block;'> Bill No.:"+billEntryH.getInvoiceNo()+"</div>"
	    			+"</div>"
	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex;'>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;width: 60%;line-height: 1.5;position: relative;display: inline-block;'></div>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;line-height: 1.5;position: relative;width: 40%;display: inline-block;'>Date : "+HallMarkUtil.convertDateToString(billEntryH.getBillDate(),"dd-MM-yyyy")+"</div>"
	    			+"</div>"
	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; '>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;width: 60%;line-height: 1.5;position: relative;display: inline-block;'></div>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;position: relative;width: 40%;display: inline-block;'>Bill Type : MULTI</div>"
	    			+"</div>"
	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -5px;'>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;line-height: 1.5;position: relative;width: 90%;padding-right: 15px;padding-left: 10px;display: inline-block;text-align: center;'> MULTI Details<br></div>"
	    			+"<br></div>"
	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"

	    			+"<div class='col' style='width: 100%;line-height: 1.5;float:right;position: relative;padding-right: 15px;padding-left: 15px;display: inline-block;'>"
	    			+"<table class='table' style='width: 95%;'>"
	    		    +"<thead>"
	    		      +"<tr>"
	    		      +"<th scope='col' style='font-size: 12px;'>#</th>"
				        +"<th scope='col' style='font-size: 12px;text-align: left;width: 10%;'>Items</th>"
				        +"<th scope='col' style='font-size: 12px;text-align: right;'>W.t</th>"
				        +"<th scope='col' style='font-size: 12px;text-align: right;'>Purity</th>"
				        +"<th scope='col' style='font-size: 12px;text-align: right;'>Qty</th>"
				        +"<th scope='col' style='font-size: 12px;text-align: right;'>R.t</th>"
				        +"<th scope='col' style='font-size: 12px;text-align: right;'>Amt</th>"
				        +"<th scope='col' style='font-size: 12px;text-align: left;width: 15%;'>Type</th>"
				        //+"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 15%;'></th>"
				       +"</tr>"
	    		    +"</thead> "
	    		    +"<tbody>";
	    		    
	    print_document=  print_document+ billDetails +"</tbody>"
	    		    +"<tfoot><tr><td style='font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'></td><td style='font-family: Arial;font-size: 12px;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'>Total:</td>"
	    		    +"<td style='font-family: Arial;font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse; text-align: right;'>"+totalWeight+"</td>"
	    		    +"<td style='font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'></td>"
	    		    +"<td style='font-family: Arial;font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse; text-align: right;'>"+Math.round(totalQty)+"</td>"
	    		    +"<td style='font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'></td>"
	    		    +"<td style='font-family: Arial;font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse; text-align: right;'>"+Math.round(totalAmt)+"</td>"
					+"<td style='font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'></td>";;
				
	    		   print_document  = print_document +"</tr></tfoot>"
	    		    +"</table></div>"
	    				+"</div>"
	    			+"<div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    			+"<div class='col' style='float:right;position: relative;width: 75%;padding-right: 15px;padding-left: 15px;display: inline-block;'>"

	    			+"<table class='table2' style='width:95%;margin-left: 50px;margin-top: 5px;'>"
	    		    +"<tbody>";
	    		   
	    		   if(null!=billEntryH.getHallmarkingChk())  {
	    				if(billEntryH.getHallmarkingChk())  {	 	
	    		   print_document  = print_document +"<tr style='font-size: 12;'>"
						+"<td style='font-family: Arial;font-size: 12;'>GST:</td>"
						+"<td style='font-family: Arial;font-size: 12;'>"+(null!=billEntryH.getGstRate() ? Math.round(billEntryH.getGstRate()) : 0)+"</td>"
						+"</tr>";
	    				}
	    		   }
	    		   
	    		  print_document  = print_document   +"<tr style='font-size: 12;'>"
	    		        +"<td style='font-family: Arial;font-size: 12;'>Received Amt:</td>"
	    		        +"<td style='font-family: Arial;font-size: 12;'>"+(null!=billEntryH.getReceivedAmount() ? Math.round(billEntryH.getReceivedAmount()) : 0)+"</td>"
	    		        +"</tr>"
	    		        +"<tr style='font-size: 12;'>"
	    		        +"<td style='font-family: Arial;font-size: 12;'>Balance:</td>"
	    		        +"<td style='font-family: Arial;font-size: 12;'>"+(null!=billEntryH.getBalanceAmount() ? Math.round(billEntryH.getBalanceAmount()) : 0)+"</td>"
	    		        +"<td style='font-family: Arial;font-size: 12;'></td>"
	    				+"</tr>"
	    		    +"</tbody></table>"
	    		    +"</div>"
	    			+"</div>"
	    			+"<div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;position: relative;padding-right: 15px;padding-left: 15px;display: inline-block;'><br>RECEIVED RS. "+NumberToWords.convert(Math.round((null!=billEntryH.getReceivedAmount() ? billEntryH.getReceivedAmount() : 0)))+" ONLY"
	    			
	    			+"</div>"
	    			+"</div>"
	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'></div>"
	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    			//+"<div class='col' style='font-family: Arial;font-size: 12;line-height: 1.5;text-align: end;float:right;position: relative;width: 90%;padding-right: 15px;padding-left: 15px;display: inline-block;'><br/><br/><span style='text-align: right;float:right;'>Authorized Sign</span><br/>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;line-height: 1.5;text-align: right;float:right;position: relative;width: 80%;padding-right: 15px;padding-left: 15px;display: inline-block;'><br/><br/><span style='text-align: right;margin-right: 10px;'>Authorized Sign</span><br/>"

	    			+"</div>"
	    			+"</div>"
	    				+"</div></body>";
	    
	    return print_document;
	}
	
	public String createCardBilHtml(BillEntryHeader billEntryH,String billType) throws ParseException {
	    double totalWeight=0;
	    double totalQty=0;
	    double totalAmt=0;
		String billDetails="";
		int i=1;
		
		if(null!=billEntryH.getCardChk())  {
			if(billEntryH.getCardChk()) {
				List<BillEntryDetail> cardBillDtl=billEntryH.getCardList();
				if(null!=cardBillDtl || !cardBillDtl.isEmpty())
				{
					for( BillEntryDetail billEntryCardDetail:cardBillDtl)
					{
						if(!HallMarkUtil.isEmpty(billEntryCardDetail.getItemName())) {
							billDetails+="<tr>"
									+"<td style='font-size: 12px;'>"+i+"</td>"
							        +"<td style='word-wrap: break-word;min-width: 60px;max-width: 60px;font-size: 12px;'>"+billEntryCardDetail.getItemName()+"</td>"
							        +"<td style='font-size: 12px;'>"+billEntryCardDetail.getNetWeight()+"</td>"
							        +"<td style='font-size: 12px;'>"+billEntryCardDetail.getPurity()+"</td>"
							        +"<td style='font-size: 12px;'>"+(null!=billEntryCardDetail.getQuantity()? Math.round(billEntryCardDetail.getQuantity()):0)+"</td>"
							        +"<td style='font-size: 12px;'>"+(null!=billEntryCardDetail.getRate() ? Math.round(billEntryCardDetail.getRate()) : 0)+"</td>"
							        +"<td style='font-size: 12px;'>"+(null!=billEntryCardDetail.getAmount() ? Math.round(billEntryCardDetail.getAmount()) :0)+"</td>"
							     +"</tr>";
									i++;
									totalWeight=totalWeight+ (null!=billEntryCardDetail.getItemWeight() ? billEntryCardDetail.getItemWeight():0);
									totalQty=totalQty+ (null!=billEntryCardDetail.getQuantity() ? Math.round(billEntryCardDetail.getQuantity()):0);
									totalAmt=totalAmt+ (null!=billEntryCardDetail.getAmount() ? Math.round(billEntryCardDetail.getAmount()) :0);
						}
					}
		
				}
			}
		}
		
		
	    String print_document="<html><head>"
	    		+"<style>@media print {  @page "
	    		+"{"
	    		+"    size:  auto; "
	    		+"    margin: 0mm; "
	    		+" }"
	    		+"body{"
	    	+" width: 80mm;"
	    	+"font-family: Arial;"
	    	+"}" 
	    	+"}" 
	    	+"th{border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;}"
	    	+"}"
	    	+"</style>"
	    	+"</head>";
	    	print_document  = print_document+"<html><head><style>@media print { @page{size:  auto;margin:0px auto;}}</style></head><body class='media' style='font-family: Arial;line-height: 1.5;font-size: 12;width: 80mm;'><div class='container' id='myPrint' style='margin-left: 5px;margin-right: 10px;'><div class='row' style='flex-wrap: wrap;display: flex;'>"
	    					+"<div class='col' style='line-height: 1.5;position: relative;display: inline-block;'></div>"
	    					//+"<div class='col' style='line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;'><img src='project/images/invoice.png' max-width: 100%; height: auto; th:src='@{project/images/invoice.png}'></div>"
	    					+"<div class='col' style='line-height: 1.5;position: relative;width: 100%;padding-right: 13px;display: inline-block;text-align: right;'><h1 class='preview' data-content='CodePen' style='box-sizing: border-box;font-family: Arial, sans-serif;font-size: 1em;font-weight: bold;position: relative;z-index: 1;display: inline-block;-webkit-font-smoothing: antialiased;-moz-osx-font-smoothing: grayscale;color: black;width: 30%;height: 55%;margin-top: 5px;text-align: center;'>Invoice</h1></div>"
	    					//+"<div class='col' style='margin-top: 5px;line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;text-align: right;'><img src='/mahalaxmihallmarking/project/images/invoice.png' max-width: 100%; height: auto; th:src='@{/mahalaxmihallmarking/project/images/invoice.png}'></div>"
	    					+"</div>"

	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex;'>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;width: 60%;line-height: 1.5;position: relative;display: inline-block;overflow-wrap: break-word;'>Party Name:"+billEntryH.getPartyName()+"</div>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;width: 40%;line-height: 1.5;position: relative;display: inline-block;'> Bill No.:"+billEntryH.getInvoiceNo()+"</div>"
	    			+"</div>"
	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex;'>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;width: 60%;line-height: 1.5;position: relative;display: inline-block;'></div>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;line-height: 1.5;position: relative;width: 40%;display: inline-block;'>Date : "+HallMarkUtil.convertDateToString(billEntryH.getBillDate(),"dd-MM-yyyy")+"</div>"
	    			+"</div>"
	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; '>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;width: 60%;line-height: 1.5;position: relative;display: inline-block;'></div>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;position: relative;width: 40%;display: inline-block;'>Bill Type : "+billType+"</div>"
	    			+"</div>"
	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -5px;'>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;line-height: 1.5;position: relative;width: 90%;padding-right: 15px;padding-left: 10px;display: inline-block;text-align: center;'>"+billType+ " Details<br></div>"
	    			+"<br></div>"
	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"

	    			+"<div class='col' style='width: 100%;line-height: 1.5;float:right;position: relative;padding-right: 15px;padding-left: 15px;display: inline-block;'>"
	    			+"<table class='table' style='width: 95%;'>"
	    		    +"<thead>"
	    		      +"<tr>"
	    		      +"<th scope='col' style='font-size: 12px;'>#</th>"
				        +"<th scope='col' style='font-size: 12px;text-align: left;width: 20%;'>Items</th>"
				        +"<th scope='col' style='font-size: 12px;text-align: left;'>Weight</th>"
				        +"<th scope='col' style='font-size: 12px;text-align: left;'>Purity</th>"
				        +"<th scope='col' style='font-size: 12px;text-align: left;'>Qty</th>"
				        +"<th scope='col' style='font-size: 12px;text-align: left;'>Rate</th>"
				        +"<th scope='col' style='font-size: 12px;text-align: left;'>Amount</th>"
				        //+"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 15%;'></th>"
				       +"</tr>"
	    		    +"</thead> "
	    		    +"<tbody>";
	    		    
	    print_document=  print_document+ billDetails +"</tbody>"
	    		    +"<tfoot><tr><td style='font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'></td><td style='font-family: Arial;font-size: 12px;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'>Total:</td>"
	    		    +"<td style='font-family: Arial;font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'>"+totalWeight+"</td>"
	    		    +"<td style='font-family: Arial;font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'>"+Math.round(totalQty)+"</td>"
	    		    +"<td style='font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'></td>"
	    		    +"<td style='font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'></td>"
	    		    +"<td style='font-family: Arial;font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'>"+Math.round(totalAmt)+"</td>"
					;
				
	    		   print_document  = print_document +"</tr></tfoot>"
	    		    +"</table></div>"
	    				+"</div>"
	    			+"<div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    			+"<div class='col' style='float:right;position: relative;width: 75%;padding-right: 15px;padding-left: 15px;display: inline-block;'>"

	    			+"<table class='table2' style='width:95%;margin-left: 50px;margin-top: 5px;'>"
	    		    +"<tbody>";
	    		   
	    		   if(null!=billEntryH.getHallmarkingChk())  {
	    				if(billEntryH.getHallmarkingChk())  {	 	
	    		   print_document  = print_document +"<tr style='font-size: 12;'>"
						+"<td style='font-family: Arial;font-size: 12;'>GST:</td>"
						+"<td style='font-family: Arial;font-size: 12;'>"+(null!=billEntryH.getGstRate() ? Math.round(billEntryH.getGstRate()) : 0)+"</td>"
						+"</tr>";
	    				}
	    		   }
	    		   
	    		  print_document  = print_document   +"<tr style='font-size: 12;'>"
	    		        +"<td style='font-family: Arial;font-size: 12;'>Received Amt:</td>"
	    		        +"<td style='font-family: Arial;font-size: 12;'>"+(null!=billEntryH.getReceivedAmount() ? Math.round(billEntryH.getReceivedAmount()) : 0)+"</td>"
	    		        +"</tr>"
	    		        +"<tr style='font-size: 12;'>"
	    		        +"<td style='font-family: Arial;font-size: 12;'>Balance:</td>"
	    		        +"<td style='font-family: Arial;font-size: 12;'>"+(null!=billEntryH.getBalanceAmount() ? Math.round(billEntryH.getBalanceAmount()) : 0)+"</td>"
	    		        +"<td style='font-family: Arial;font-size: 12;'></td>"
	    				+"</tr>"
	    		    +"</tbody></table>"
	    		    +"</div>"
	    			+"</div>"
	    			+"<div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;position: relative;padding-right: 15px;padding-left: 15px;display: inline-block;'><br>RECEIVED RS. "+NumberToWords.convert(Math.round((null!=billEntryH.getReceivedAmount() ? billEntryH.getReceivedAmount() : 0)))+" ONLY"
	    			
	    			+"</div>"
	    			+"</div>"
	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'></div>"
	    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    			//+"<div class='col' style='font-family: Arial;font-size: 12;line-height: 1.5;text-align: end;float:right;position: relative;width: 90%;padding-right: 15px;padding-left: 15px;display: inline-block;'><br/><br/><span style='text-align: right;float:right;'>Authorized Sign</span><br/>"
	    			+"<div class='col' style='font-family: Arial;font-size: 12;line-height: 1.5;text-align: right;float:right;position: relative;width: 80%;padding-right: 15px;padding-left: 15px;display: inline-block;'><br/><br/><span style='text-align: right;margin-right: 10px;'>Authorized Sign</span><br/>"

	    			+"</div>"
	    			+"</div>"
	    				+"</div></body>";
	    
	    return print_document;
	}
	public String createAdminHuidHtml(BillEntryHeader billEntryH,String billType) throws ParseException {
		List<BillEntryDetail> billEntryDetailList = billEntryH.getHallMarkList();
	    double totalWeight=0;
	    double totalQty=0;
	    double totalAmt=0;
		String billDetails="";
		int i=1;
	    
		double cgst=0;
	   if(null!= billEntryH.getGstRate()){
		   cgst = (billEntryH.getGstRate() / 2);
	   }
	   double payableAmt=0;
	   payableAmt=(null!=billEntryH.getSubTotal() ? billEntryH.getSubTotal() :0) + (null!=billEntryH.getGstRate() ? billEntryH.getGstRate():0);
		for(BillEntryDetail billEntryDetail:billEntryDetailList) {
			
			billDetails+="<tr>"
		        +"<td style='font-size: 12px;'>"+i+"</td>"
		        +"<td style='word-wrap: break-word;min-width: 60px;max-width: 60px;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billEntryDetail.getItemName()+"</td>"
		        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>"+billEntryDetail.getPurity()+"</td>"
		        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>"+billEntryDetail.getQuantity()+"</td>"
		        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>0</td>"
				+"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>0</td>"
				+"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>0</td>"
		        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>"+(null!=billEntryDetail.getRate() ? Math.round(billEntryDetail.getRate()) : 0)+"</td>"
		        +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>"+(null!=billEntryDetail.getAmount() ? Math.round(billEntryDetail.getAmount()) :0)+"</td>"
				+"</tr>";
			i++;
			totalWeight=totalWeight+ (null!=billEntryDetail.getItemWeight() ? billEntryDetail.getItemWeight():0);
			totalQty=totalQty+ (null!=billEntryDetail.getQuantity() ? Math.round(billEntryDetail.getQuantity()):0);
			totalAmt=totalAmt+ (null!=billEntryDetail.getAmount() ? Math.round(billEntryDetail.getAmount()) :0);
		}

	    String print_document="<html><head>"
	    		+"<style>@media print {  @page "
	    		+"{"
	    		+"    size:  auto; "
	    		+"    margin: 0mm; "
	    		+" }"
	    		+"body{"
	    	+" width: 80mm;"
	    	+"font-family: Arial;"
	    	+"}" 
	    	+"}" 
	    	+"th{border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;}"
	    	+"}"
	    	+"</style>"
	    	+"</head>";
	    print_document  = print_document+"<body style='line-height: 1.5;font-size: 12px;margin-top: 150px;'><div class='container' id='myPrint' style='margin-left: 10px;margin-right: 10px;width: 95%;border: 1px solid black;border-collapse: collapse;'><div class='row' style='flex-wrap: wrap;display: flex;'>"
				+"<div class='col' style='line-height: 1.5;position: relative;width: 50%;display: inline-block;'>Rec. No.:"+billEntryH.getInvoiceNo()+"</div>"
				//+"<div class='col' style='line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;'><img src='project/images/invoice.png' max-width: 100%; height: auto; th:src='@{project/images/invoice.png}'></div>"
				+"<div class='col' style='line-height: 1.5;position: relative;width: 50%;display: inline-block;text-align: right;'>Date: "+HallMarkUtil.convertDateToString(billEntryH.getBillDate(),"dd-MM-yyyy")+"</div>"
				+"<br/></div>"
				+"<div class='row' style='text-align:center;'><div class='col' style='text-align:center;line-height: 1.5;position: relative;'>TAX INVOICE CUM DELIVERY CHALLAN</div></div> "
				
		+"<div class='row' style='line-height: 1.5;'>"
		+"<div class='col' style='font-size: 10px;line-height: 1.5;width: 50%;position: relative;display: inline-block;'>GSTIN NO:"+gstinNo+"</div>"
		+"<div class='col' style='font-size: 10px;line-height: 1.5;width: 50%;position: relative;text-align: right;display: inline-block;'>(Original for Recipient/Duplicate for Supplier)</div>"
		+"</div>"
		
		+"<div class='row'>"
		+"<table class='table' style='width:100%;border: 1px solid black;border-collapse: collapse;'>"
	    +"<tbody>"
	      +"<tr style='border: 1px solid black;border-collapse: collapse;'>"
	      +"<td style='border: 1px solid black;border-collapse: collapse;'>"
	      +"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex;margin-left: 1px;'>Name:"+billEntryH.getPartyName()+"</div>"
	      +"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex;margin-left: 1px;'>Address:"+billEntryH.getPartyAddress()+"</div>"
	      +"</td>"
	      +"<td style='border: 1px solid black;border-collapse: collapse;width: 40%;'>"
	      +"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex;text-align: left;margin-left: 1px;'>Invoice No. : "+billEntryH.getInvoiceNo()+"</div>"
	      +"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex;text-align: left;margin-left: 1px;'>Date : "+HallMarkUtil.convertDateToString(billEntryH.getBillDate(),"dd-MM-yyyy")+"</div>"
	      +"</td>"
	      +"</tr>"
	      
	      +"<tr style='border: 1px solid black;border-collapse: collapse;'>"
	      +"<td style='border: 1px solid black;border-collapse: collapse;'>"
	      +"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex;margin-left: 1px;'>Place of Supply : "+placeOfSupply+"</div>"
	      +"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex;margin-left: 1px;'>State Code:  "+stateCode+"</div>"
	      +"</td>"
	      +"<td style='border: 1px solid black;border-collapse: collapse;width: 20%;'>"
	      +"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex;text-align: left;margin-left: 1px;'>SAC : "+ sac+" </div>"
	      +"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex;text-align: left;margin-left: 1px;'>Your D.C.No :  </div>"
	      +"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex;margin-left: 1px;text-align: left;'>D.C. Date : "+HallMarkUtil.convertDateToString(billEntryH.getBillDate(),"dd-MM-yyyy")+"</div>"
	      +"</td>"
	      +"</tr>"
	      +"</tbody>"
	      +"</table>"
		/*+"</div>"
		+"<div class='row' style='flex-wrap: wrap;display: flex;'>"*/
		+"<table class='table' style='width:100%;border: 1px solid black;border-collapse: collapse;'>"
	    +"<thead>"
	      +"<tr style='border: 1px solid black;border-collapse: collapse;'>"
	      +"<th scope='col' rowspan='2' style='border: 1px solid black;border-collapse: collapse;width: 5%;'>#</th>"
	        +"<th scope='col' rowspan='2' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;width: 30%;'>Description</th>"
	        +"<th scope='col' rowspan='2' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;'>Purity</th>"
	        +"<th scope='col' colspan='4' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;text-align: center;'>No of Pcs</th>"
	        +"<th scope='col' rowspan='2' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;'>Rate</th>"
	        +"<th scope='col' rowspan='2' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;'>Amount</th>"
	        +"</tr>"
	        
	        +"<tr style='border: 1px solid black;border-collapse: collapse;'>"
		        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;'>H/M</th>"
		        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;'>Rej</th>"
		        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;'>Melt</th>"
		        +"<th scope='col' style='font-size: 12px;text-align: left;border: 1px solid black;border-collapse: collapse;'>Rtn</th>"
		     +"</tr>"
	    +"</thead> "
	    +"<tbody>";
	    
	   
	    print_document=  print_document+ billDetails+ "</tbody>"
	    +"<tfoot><tr><td colspan='3' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'><b>Weight Received:</b> "+totalWeight+"</td>"
	    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>"+Math.round(totalQty)+"</td>"
	    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>0</td>"
	    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>0</td>"
	    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>0</td>"
	    +"<td colspan='2' style='text-align: right;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+Math.round(totalAmt)+"</td>"
	    +"</tr>"
	    
		    +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
		 	+"<td rowspan='4' colspan='3'></td>"
	     	+"<td colspan='5' style='text-align: right;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Discount</td>"
	        +"<td colspan='2' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>"+(null!=billEntryH.getDiscount() ? Math.round(billEntryH.getDiscount()):0)+"</td>"
	        +"</tr>"
		 	+"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	     	+"<td colspan='5' style='text-align: right;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>CGST @ 9.00%</td>"
	        +"<td colspan='2' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>"+cgst+"</td>"
	        +"</tr>"
	        +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	        +"<td colspan='5' style='text-align: right;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>SGST @ 9.00%</td>"
	        +"<td colspan='2' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>"+cgst+"</td>"
	        +"</tr>"
	        +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	        +"<td colspan='5' style='text-align: right;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>IGST @ 0.00%</td>"
	        +"<td colspan='2' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>0.0</td>"
	        +"</tr>"
	    +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    +"<td colspan='8' style='text-align: right;border: 1px solid black;border-collapse: collapse;'><b>Amount Payable (In Rupees)</b></td>"
	    +"<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;text-align: right;'>"+Math.round(payableAmt)+"</td>"
	    +"</tr>"
	    
	    +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    +"<td colspan='9' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'><b>Amount in Words.</b> "+NumberToWords.convert(Math.round(payableAmt)) +" ONLY</td>"
	    +"</tr>"
	    
	    +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    +"<td colspan='3' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Recd. The precious metal / jewellery in satisfactory &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;condition"
	    	+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
	    	+"<div class='col' style='line-height: 1.5;position: relative;width: 70%;padding-right: 15px;padding-left: 15px;display: inline-block;'><br/><br/>Customer Signature <br/>"
		+"</div>"
		+"</div>"
	    +"</td>"
	    +"<td rowspan ='2' colspan='6' style='font-size: 11px;border: 1px solid black;border-collapse: collapse;'>For MAHALAXMI HALLMARK CENTER"
	    +"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
		+"<div class='col' style='font-size: 12px;line-height: 1.5;text-align: end;position: relative;width: 100%;padding-right: 15px;padding-left: 15px;display: inline-block;'><br/><br/>Authorized Signature <br/>"
		+"</div>"
		+"</div>"
		+"</td>"
	    +"</tr>"
	    +"<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"
	    +"<td colspan='3' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>By Courier/ By Hand"
	    +"</td>"
	    +"</tr>"
	    +"</tfoot>"
		+"</table></div>"
		
		+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'></div>"
	+"</div></body>";
	    
	    return print_document;
	}
}
