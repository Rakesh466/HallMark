package com.bytecode.hallmarks.model;

import java.io.File;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;

public class BillEntryH {
		private Integer invoiceNo;
	 	
	    private String requestNo;
	    
	    private String billDate;
	    
	    private String partyName;
	   
	    private int partyCode;
	    
	    private String licenseNo;
	    
	    private String licenseType;
	    
	    private String IsCancelled;
	   
	    private Integer totalQty;
	    
	    private Float totalWeight;
	    
	    private Double subTotal;
	    
	    private Double discount;
	    
	    private Double receivedAmount;
	    
	    private Double balanceAmount;
	    
	    private String createdBy;
	    
	    private String updatedBy;
	    
	    private Timestamp createdDate;
	    
	    private Timestamp updatedDate;
	    
	    private Timestamp transationDate;
	    
	    private List<BillEntryDetail> hallMarkList;
	    
	    private List<BillEntryDetail> cardList;

	    private List<BillEntryDetail> tunchList;

	    private List<BillEntryDetail> lesserList;
	    
	    private Boolean hallmarkingChk;
	    private Boolean cardChk;
	    private Boolean tunchChk;
	    private Boolean lesserChk;
	    private Date fromDate;
	    private Date toDate;
	    private String gstNo;
	    
	    private Double pendingBillAmt;
	    
	    private String pendingBillDate;

	    private String pendingBillNo;
	    
	    private String  sampleWeight;
	    
	    private String karat;
	    
		private Boolean isPrinted;
		
		private File imagePath;
	    
		public Integer getInvoiceNo() {
			return invoiceNo;
		}

		public void setInvoiceNo(Integer invoiceNo) {
			this.invoiceNo = invoiceNo;
		}

		public String getRequestNo() {
			return requestNo;
		}

		public void setRequestNo(String requestNo) {
			this.requestNo = requestNo;
		}

		public String getPartyName() {
			return partyName;
		}

		public void setPartyName(String partyName) {
			this.partyName = partyName;
		}

		public String getLicenseNo() {
			return licenseNo;
		}

		public void setLicenseNo(String licenseNo) {
			this.licenseNo = licenseNo;
		}

		public String getLicenseType() {
			return licenseType;
		}

		public void setLicenseType(String licenseType) {
			this.licenseType = licenseType;
		}

		public String getIsCancelled() {
			return IsCancelled;
		}

		public void setIsCancelled(String isCancelled) {
			IsCancelled = isCancelled;
		}

		public Integer getTotalQty() {
			return totalQty;
		}

		public void setTotalQty(Integer totalQty) {
			this.totalQty = totalQty;
		}

		public Float getTotalWeight() {
			return totalWeight;
		}

		public void setTotalWeight(Float totalWeight) {
			this.totalWeight = totalWeight;
		}

		public Double getSubTotal() {
			return subTotal;
		}

		public void setSubTotal(Double subTotal) {
			this.subTotal = subTotal;
		}

		public Double getDiscount() {
			return discount;
		}

		public void setDiscount(Double discount) {
			this.discount = discount;
		}

		public Double getReceivedAmount() {
			return receivedAmount;
		}

		public void setReceivedAmount(Double receivedAmount) {
			this.receivedAmount = receivedAmount;
		}

		public String getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}

		public String getUpdatedBy() {
			return updatedBy;
		}

		public void setUpdatedBy(String updatedBy) {
			this.updatedBy = updatedBy;
		}

		public Timestamp getCreatedDate() {
			return createdDate;
		}

		public void setCreatedDate(Timestamp createdDate) {
			this.createdDate = createdDate;
		}

		public Timestamp getUpdatedDate() {
			return updatedDate;
		}

		public void setUpdatedDate(Timestamp updatedDate) {
			this.updatedDate = updatedDate;
		}

		public List<BillEntryDetail> getHallMarkList() {
			return hallMarkList;
		}

		public void setHallMarkList(List<BillEntryDetail> hallMarkList) {
			this.hallMarkList = hallMarkList;
		}

		public String getBillDate() {
			return billDate;
		}

		public void setBillDate(String billDate) {
			this.billDate = billDate;
		}

		public Boolean getHallmarkingChk() {
			return hallmarkingChk;
		}

		public void setHallmarkingChk(Boolean hallmarkingChk) {
			this.hallmarkingChk = hallmarkingChk;
		}

		public Boolean getCardChk() {
			return cardChk;
		}

		public void setCardChk(Boolean cardChk) {
			this.cardChk = cardChk;
		}

		public Boolean getTunchChk() {
			return tunchChk;
		}

		public void setTunchChk(Boolean tunchChk) {
			this.tunchChk = tunchChk;
		}

		public Boolean getLesserChk() {
			return lesserChk;
		}

		public void setLesserChk(Boolean lesserChk) {
			this.lesserChk = lesserChk;
		}

		public List<BillEntryDetail> getCardList() {
			return cardList;
		}

		public void setCardList(List<BillEntryDetail> cardList) {
			this.cardList = cardList;
		}

		public List<BillEntryDetail> getTunchList() {
			return tunchList;
		}

		public void setTunchList(List<BillEntryDetail> tunchList) {
			this.tunchList = tunchList;
		}

		public List<BillEntryDetail> getLesserList() {
			return lesserList;
		}

		public void setLesserList(List<BillEntryDetail> lesserList) {
			this.lesserList = lesserList;
		}

		public Double getBalanceAmount() {
			return balanceAmount;
		}

		public void setBalanceAmount(Double balanceAmount) {
			this.balanceAmount = balanceAmount;
		}

		public int getPartyCode() {
			return partyCode;
		}

		public void setPartyCode(int partyCode) {
			this.partyCode = partyCode;
		}

		public Date getFromDate() {
			return fromDate;
		}

		public void setFromDate(Date fromDate) {
			this.fromDate = fromDate;
		}

		public Date getToDate() {
			return toDate;
		}

		public void setToDate(Date toDate) {
			this.toDate = toDate;
		}

		public Timestamp getTransationDate() {
			return transationDate;
		}

		public void setTransationDate(Timestamp transationDate) {
			this.transationDate = transationDate;
		}

		public String getGstNo() {
			return gstNo;
		}

		public void setGstNo(String gstNo) {
			this.gstNo = gstNo;
		}

		public Double getPendingBillAmt() {
			return pendingBillAmt;
		}

		public void setPendingBillAmt(Double pendingBillAmt) {
			this.pendingBillAmt = pendingBillAmt;
		}

		public String getPendingBillDate() {
			return pendingBillDate;
		}

		public void setPendingBillDate(String pendingBillDate) {
			this.pendingBillDate = pendingBillDate;
		}

		public String getPendingBillNo() {
			return pendingBillNo;
		}

		public void setPendingBillNo(String pendingBillNo) {
			this.pendingBillNo = pendingBillNo;
		}

		public String getSampleWeight() {
			return sampleWeight;
		}

		public void setSampleWeight(String sampleWeight) {
			this.sampleWeight = sampleWeight;
		}

		public String getKarat() {
			return karat;
		}

		public void setKarat(String karat) {
			this.karat = karat;
		}

		public Boolean getIsPrinted() {
			return isPrinted;
		}

		public void setIsPrinted(Boolean isPrinted) {
			this.isPrinted = isPrinted;
		}

		public File getImagePath() {
			return imagePath;
		}

		public void setImagePath(File imagePath) {
			this.imagePath = imagePath;
		}

		

}
