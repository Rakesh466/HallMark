package com.bytecode.hallmarks.model;

import java.sql.Date;
import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name = "DAYTODAYEXPENSES")
public class DayToDayExpenses {

	@Id
	@Column(name = "DAYTODAYEXP_CODE")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "daytoday_seq")
	@SequenceGenerator(name = "daytoday_seq", allocationSize = 1)
	private int dayToDayExpCode;

	@Column(name = "PAYMENT_TYPE")
	@Length(min = 1, max = 20, message = "*Your Payment Type  name must have minimum 1 and Max 20 characters")
	private String paymentType;

	@Column(name = "PAYMENT_MODE")
	@Length(min = 1, max = 20, message = "*Your Payment Mode must have minimum 1 and Max 20  characters")
	private String paymentMode;

	@Column(name = "PAYMENT_DATE")
	private Date paymentDate;

	@Column(name = "NAME")
	@Length(min = 1, max = 20, message = "*Your Name must have at least 1 characters")
	private String name;

	@Column(name = "AMOUNT")
	private double amount;

	@Column(name = "CHEQUE_NO")
	@Length(min = 1, max = 20, message = "*Your Cheque No must have at least 1 characters")
	private String chequeNo;

	@Column(name = "BANK_NAME")
	@Length(min = 1, max = 20, message = "*Your Bank Name must have at least 1 characters")
	private String bankName;

	@Column(name = "NARRATION")
	@Length(min = 1, max = 20, message = "*Your Narration must have at least 1 characters")
	private String narration;

	@Column(name = "ACTIVE")
	private Boolean active;

	@Column(name = "CREATED_BY", updatable = false)
	@Length(max = 45, message = "*Created By must have Max 45 characters")
	private String createdBy;

	@Column(name = "CREATED_DATE", updatable = false)
	private Instant createdDate;

	@Column(name = "MODIFIED_BY")
	@Length(max = 45, message = "*Modified By must have Max 45 characters")
	private String modifiedBy;

	@Column(name = "MODIFIED_DATE")
	private Instant modifiedDate;

	public int getDayToDayExpCode() {
		return dayToDayExpCode;
	}

	public void setDayToDayExpCode(int dayToDayExpCode) {
		this.dayToDayExpCode = dayToDayExpCode;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getChequeNo() {
		return chequeNo;
	}

	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getNarration() {
		return narration;
	}

	public void setNarration(String narration) {
		this.narration = narration;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Instant getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Instant createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Instant getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Instant modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

}
