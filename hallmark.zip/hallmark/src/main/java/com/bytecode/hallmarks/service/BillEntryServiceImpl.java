package com.bytecode.hallmarks.service;

import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bytecode.hallmarks.model.BillAudit;
import com.bytecode.hallmarks.model.BillEntryDetail;
import com.bytecode.hallmarks.model.BillEntryH;
import com.bytecode.hallmarks.model.BillEntryHeader;
import com.bytecode.hallmarks.repository.BillAuditRepository;
import com.bytecode.hallmarks.repository.BillEntryDetailRepository;
import com.bytecode.hallmarks.repository.BillEntryHeaderRepository;
import com.bytecode.hallmarks.util.HallMarkUtil;



@Service
public class BillEntryServiceImpl implements BillEntryService{
public static final Logger logger=LoggerFactory.getLogger(BillEntryServiceImpl.class);

@Autowired
BillEntryHeaderRepository billEntryHeaderRepository;
@Autowired
BillEntryDetailRepository billEntryDetailRepository;
@Autowired
HttpSession session;
@Autowired
BillAuditRepository billAuditRepository;

	@Override
	public Integer getInvoiceNo() {
		System.out.println("billEntryHeaderRepository::"+billEntryHeaderRepository.getInvoiceNo());
		if(null!=billEntryHeaderRepository.getInvoiceNo()) {
		return (billEntryHeaderRepository.getInvoiceNo() + 1);
		}else
		{
			return 1;
		}
	}

	@Override
	public String savebillEntry(BillEntryHeader billEntryHeader) throws Exception {
		//BillEntryHeader billEntryHeader=new BillEntryHeader();
		
		
		//billEntryHeader.setBillDate(HallMarkUtil.convertStrintTOSqlDate(billEntryHeader.getBillDate()));
		/*
		 * billEntryHeader.setLicenseNo(billEntryH.getLicenseNo());
		 * billEntryHeader.setGstNo(billEntryH.getGstNo());
		 * billEntryHeader.setLicenseType(billEntryH.getLicenseType());
		 * billEntryHeader.setPartyName(billEntryH.getPartyName());
		 * billEntryHeader.setPartyCode(billEntryH.getPartyCode());
		 * billEntryHeader.setRequestNo(billEntryH.getRequestNo());
		 * billEntryHeader.setSubTotal(billEntryH.getSubTotal());
		 * billEntryHeader.setDiscount(billEntryH.getDiscount());
		 * billEntryHeader.setReceivedAmount(billEntryH.getReceivedAmount());
		 * billEntryHeader.setTotalQty(billEntryH.getTotalQty());
		 * billEntryHeader.setTotalWeight(billEntryH.getTotalWeight());
		 * billEntryHeader.setBalanceAmount(billEntryH.getBalanceAmount());
		 * billEntryHeader.setDiscount(billEntryH.getDiscount());
		 * 
		 * billEntryHeader.setPendingBillAmt(billEntryH.getPendingBillAmt());
		 * billEntryHeader.setPendingBillDate(billEntryH.getPendingBillDate());
		 * billEntryHeader.setPendingBillNo(billEntryH.getPendingBillNo());
		 * billEntryHeader.setSampleWeight(billEntryH.getSampleWeight());
		 */
		
		billEntryHeader.setCreatedDate(HallMarkUtil.currentSqlTimestamp());
		if(null!=session.getAttribute("sessionUserId")) {
		billEntryHeader.setCreatedBy((String)session.getAttribute("sessionUserId"));
		}
		billEntryHeader.setTransationDate(HallMarkUtil.currentSqlTimestamp());
		
		if(null==billEntryHeader.getInvoiceNo())
		{
			billEntryHeader.setInvoiceNo(getInvoiceNo());
		}
		billEntryHeaderRepository.save(billEntryHeader);
		
		billEntryDetailRepository.deleteByInvoiceNo(billEntryHeader.getInvoiceNo());
		if(null!=billEntryHeader.getHallmarkingChk())  {
			if(billEntryHeader.getHallmarkingChk())  {
				List<BillEntryDetail> hallMarkBillDtl=billEntryHeader.getHallMarkList();
				if(null!=hallMarkBillDtl || !hallMarkBillDtl.isEmpty())
				{
					for( BillEntryDetail billEntryDetail:hallMarkBillDtl)
					{
						if(!"Y".equals(billEntryDetail.getIsdeleted())){
							logger.info("billEntryHeader=="+billEntryDetail.getBillType());
							billEntryDetail.setInvoiceNo(billEntryHeader.getInvoiceNo());
							billEntryDetail.setCreatedDate(HallMarkUtil.currentSqlTimestamp());
							billEntryDetail.setCreatedBy((String)session.getAttribute("sessionUserId"));
							billEntryDetailRepository.save(billEntryDetail);
							}
					}
		
				}
			}
		}
		
		if(null!=billEntryHeader.getCardChk())  {
			if(billEntryHeader.getCardChk()) {
				List<BillEntryDetail> cardBillDtl=billEntryHeader.getCardList();
				if(null!=cardBillDtl || !cardBillDtl.isEmpty())
				{
					for( BillEntryDetail billEntryCardDetail:cardBillDtl)
					{
						if(!HallMarkUtil.isEmpty(billEntryCardDetail.getItemName())) {
							billEntryCardDetail.setInvoiceNo(billEntryHeader.getInvoiceNo());
							billEntryCardDetail.setCreatedDate(HallMarkUtil.currentSqlTimestamp());
							billEntryCardDetail.setCreatedBy((String)session.getAttribute("sessionUserId"));
							billEntryDetailRepository.save(billEntryCardDetail);
						}
					}
		
				}
			}
		}
		

		if(null!=billEntryHeader.getTunchChk())  {
			if(billEntryHeader.getTunchChk()) {
				List<BillEntryDetail> tunchBillDtl=billEntryHeader.getTunchList();
				if(null!=tunchBillDtl || !tunchBillDtl.isEmpty())
				{
					for( BillEntryDetail billEntryTunchDetail:tunchBillDtl)
					{
						if(!HallMarkUtil.isEmpty(billEntryTunchDetail.getItemName())) {
							logger.info("billEntryTunchDetail=="+billEntryTunchDetail.getBillType());
							billEntryTunchDetail.setInvoiceNo(billEntryHeader.getInvoiceNo());
							billEntryTunchDetail.setCreatedDate(HallMarkUtil.currentSqlTimestamp());
							billEntryTunchDetail.setCreatedBy((String)session.getAttribute("sessionUserId"));
							billEntryDetailRepository.save(billEntryTunchDetail);
						}
					}
		
				}
			}
		}
		
		if(null!=billEntryHeader.getLesserChk())  {
			if(billEntryHeader.getLesserChk()) {
				List<BillEntryDetail> lesserBillDtl=billEntryHeader.getLesserList();
				if(null!=lesserBillDtl || !lesserBillDtl.isEmpty())
				{
					for( BillEntryDetail billEntrylesserDetail:lesserBillDtl)
					{
						
						if(!HallMarkUtil.isEmpty(billEntrylesserDetail.getItemName())) {
							billEntrylesserDetail.setInvoiceNo(billEntryHeader.getInvoiceNo());
							billEntrylesserDetail.setCreatedDate(HallMarkUtil.currentSqlTimestamp());
							billEntrylesserDetail.setCreatedBy((String)session.getAttribute("sessionUserId"));
							billEntryDetailRepository.save(billEntrylesserDetail);
						}
					}
		
				}
			}
		}
		return "SUCCESS~"+billEntryHeader.getInvoiceNo();
	}

	@Override
	public String previouseBillDtl(Integer partyCode) {
		List<BillEntryHeader> billHeaderList=billEntryHeaderRepository.fetchPreviousBillDtl(partyCode);
		if(!billHeaderList.isEmpty()) {
		return billHeaderList.get(0).getBalanceAmount() +":"+billHeaderList.get(0).getBillDate() +":"+billHeaderList.get(0).getInvoiceNo();
		}
		return "";
	}

	@Override
	public List<BillEntryHeader> fetchPendingAmountBills() {
		return billEntryHeaderRepository.fetchPendingAmountBills();
	}

	public Paged<BillEntryHeader> getPage(int pageNumber, int size) {
		System.out.println("pageNumber="+pageNumber);
		System.out.println("size="+size);
		PageRequest request=PageRequest.of(pageNumber - 1, size,Sort.by("transationDate").descending());
		
        //PageRequest request = PageRequest.of(pageNumber - 1, size, new Sort(Sort.Direction.ASC));
        Page<BillEntryHeader> postPage = billEntryHeaderRepository.findAll(request);
        return new Paged<>(postPage, Paging.of(postPage.getTotalPages(), pageNumber, size));
    }

	public Paged<BillEntryHeader> searchBill(Date fromDate,Date toDate,Integer partyName,int pageNumber, int size) {
		System.out.println("partyName="+partyName);
		System.out.println("size="+size);
		PageRequest request=PageRequest.of(pageNumber - 1, size,Sort.by("TRANSATION_DATE").descending());
		
        //PageRequest request = PageRequest.of(pageNumber - 1, size, new Sort(Sort.Direction.ASC));
        Page<BillEntryHeader> postPage = billEntryHeaderRepository.findAllByTransationDateBetween(fromDate,toDate,partyName,request);
        return new Paged<>(postPage, Paging.of(postPage.getTotalPages(), pageNumber, size));
    }

	@Transactional
	@Override
	public String updateBill(String invoiceNo, Double balanceAmount, Double receivedAmount) throws Exception {
		logger.info("===InvoiceNo= {}, BalanceAmount= {},ReceivedAmount = {}",invoiceNo, balanceAmount, receivedAmount);
		String updatedBy="";
		if(null!=session.getAttribute("sessionUserId")) {
			updatedBy=(String)session.getAttribute("sessionUserId");
		}
		
			BillEntryHeader billEntryHeader=billEntryHeaderRepository.findAllByInvoiceNo(Integer.parseInt(invoiceNo));
			logger.info("oldr===BalanceAmount= {},ReceivedAmount = {}", billEntryHeader.getBalanceAmount(), billEntryHeader.getReceivedAmount());
			if(null!=billEntryHeader.getBalanceAmount()) {
				balanceAmount=billEntryHeader.getBalanceAmount() - receivedAmount;
			}
			if(null!=billEntryHeader.getReceivedAmount()) {
			receivedAmount=billEntryHeader.getReceivedAmount() + receivedAmount;
			}
			receivedAmount=HallMarkUtil.formtAmount(receivedAmount);
			balanceAmount=HallMarkUtil.formtAmount(balanceAmount);
			logger.info("after===BalanceAmount= {},ReceivedAmount = {}", balanceAmount, receivedAmount);
			billEntryHeader.setInvoiceNo(Integer.parseInt(invoiceNo));
			billEntryHeader.setBalanceAmount(balanceAmount);
			billEntryHeader.setReceivedAmount(receivedAmount);
			billEntryHeader.setTransationDate(HallMarkUtil.currentSqlTimestamp());
			billEntryHeader.setUpdatedBy(updatedBy);
			billEntryHeader.setUpdatedDate(HallMarkUtil.currentSqlTimestamp());
			billEntryHeaderRepository.save(billEntryHeader);
			//billEntryHeaderRepository.updateBillAmount(Integer.parseInt(invoiceNo), balanceAmount, receivedAmount,updatedBy,HallMarkUtil.currentSqlTimestamp(),HallMarkUtil.currentSqlTimestamp());
			auditBill(Integer.parseInt(invoiceNo),receivedAmount,balanceAmount,billEntryHeader.getBalanceAmount(),billEntryHeader.getReceivedAmount(),billEntryHeader.getSubTotal(),updatedBy);
		
			return null;
	}
	@Transactional
	public void auditBill(int invoiceNo, Double newReceivedAmount, Double newBalanceAmount, Double oldBalanceAmount,
			Double oldReceivedAmount, Double subTotal,String createdBy) {
		BillAudit billAudit=new BillAudit();
		billAudit.setInvoiceNo(invoiceNo);
		billAudit.setBalanceAmount(newBalanceAmount);
		billAudit.setReceivedAmount(newReceivedAmount);
		billAudit.setOldBalanceAmount(oldBalanceAmount);
		billAudit.setOldReceivedAmount(oldReceivedAmount);
		billAudit.setSubTotal(subTotal);
		
		billAudit.setCreatedBy(createdBy);
		billAudit.setCreatedDate(HallMarkUtil.currentSqlTimestamp());
		billAuditRepository.save(billAudit);
	}

	@Override
	public Paged<BillEntryHeader> searchBillForCancel(Date fromDate, Date toDate, int pageNumber, int size) {
		
		PageRequest request=PageRequest.of(pageNumber - 1, size,Sort.by("transation_date").descending());
		logger.info("==========="+fromDate);
		logger.info("==========="+toDate);
        Page<BillEntryHeader> postPage = billEntryHeaderRepository.findAllBillByTransationDateBetween(fromDate,toDate,request);
        
        logger.info("==========="+postPage.get().count());
        return new Paged<>(postPage, Paging.of(postPage.getTotalPages(), pageNumber, size));
	}

	@Override
	public String canceleBill(Integer invoiceNo) throws Exception {
		String updatedBy="";
		if(null!=session.getAttribute("sessionUserId")) {
			updatedBy=(String)session.getAttribute("sessionUserId");
		}
		billEntryHeaderRepository.canceleBill(invoiceNo,updatedBy,HallMarkUtil.currentSqlTimestamp());
		return null;
	}

	@Override
	public Paged<BillEntryHeader> searchBill(Date fromDate, Date toDate, int pageNumber, int size) {
		PageRequest request=PageRequest.of(pageNumber - 1, size,Sort.by("TRANSATION_DATE").descending());
		
        Page<BillEntryHeader> postPage = billEntryHeaderRepository.findAllByTransationDateBetween(fromDate,toDate,request);
        return new Paged<>(postPage, Paging.of(postPage.getTotalPages(), pageNumber, size));
	}

	@Override
	public BillEntryHeader fetchBillsHeader(Integer invoiceNo) {
		logger.info("invoiceNo:"+invoiceNo);
		BillEntryHeader billEntryHeader= billEntryHeaderRepository.findAllByInvoiceNo(invoiceNo);
		if(null==billEntryHeader) {
			return null;
		}
		/*
		 * BillEntryH billEntryHeader= new BillEntryH();
		 * billEntryHeader.setInvoiceNo(billEntryH.getInvoiceNo());
		 * billEntryHeader.setIsCancelled(billEntryH.getIsCancelled());
		 * billEntryHeader.setLicenseNo(billEntryH.getLicenseNo());
		 * billEntryHeader.setGstNo(billEntryH.getGstNo());
		 * billEntryHeader.setLicenseType(billEntryH.getLicenseType());
		 * billEntryHeader.setBillDate(billEntryH.getBillDate()+"");
		 * billEntryHeader.setPartyName(billEntryH.getPartyName());
		 * billEntryHeader.setPartyCode(billEntryH.getPartyCode());
		 * billEntryHeader.setRequestNo(billEntryH.getRequestNo());
		 * billEntryHeader.setSubTotal(billEntryH.getSubTotal());
		 * billEntryHeader.setDiscount(billEntryH.getDiscount());
		 * billEntryHeader.setReceivedAmount(billEntryH.getReceivedAmount());
		 * billEntryHeader.setTotalQty(billEntryH.getTotalQty());
		 * billEntryHeader.setTotalWeight(billEntryH.getTotalWeight());
		 * billEntryHeader.setBalanceAmount(billEntryH.getBalanceAmount());
		 * billEntryHeader.setDiscount(billEntryH.getDiscount());
		 * billEntryHeader.setCreatedDate(billEntryH.getCreatedDate());
		 * billEntryHeader.setCreatedBy(billEntryH.getCreatedBy());
		 * billEntryHeader.setTransationDate(billEntryH.getTransationDate());
		 * billEntryHeader.setSampleWeight(billEntryH.getSampleWeight());
		 */
		
		List<BillEntryHeader> billHeaderList=billEntryHeaderRepository.fetchPendingAmountBillsOther(billEntryHeader.getPartyCode(),invoiceNo);
		if(!billHeaderList.isEmpty()) {
			if(null!=billHeaderList.get(0).getBalanceAmount()) {
				billEntryHeader.setPendingBillAmt(billHeaderList.get(0).getBalanceAmount());
			}
			if(null!=billHeaderList.get(0).getBillDate()) {
			billEntryHeader.setPendingBillDate(billHeaderList.get(0).getBillDate().toString());
			}
			if(null!=billHeaderList.get(0).getInvoiceNo()) {
			billEntryHeader.setPendingBillNo(billHeaderList.get(0).getInvoiceNo().toString());
			}
		}
		
		return billEntryHeader;
	}
	@Override
	public List<BillEntryDetail> fetchBillDetail(Integer invoiceNo) {
		List<BillEntryDetail> billEntryDetailList =billEntryDetailRepository.findAllByInvoiceNo(invoiceNo);
		return billEntryDetailList;
	}
	
	@Override
	public Paged<BillReport> findAllDataByTransationDateBetween(Date fromDate, Date toDate,int pageNumber, int size) {

		PageRequest request=PageRequest.of(pageNumber - 1, size);
		
        Page<BillReport> postPage = billEntryHeaderRepository.findAllDataByTransationDateBetween(fromDate,toDate,request);
        
        return new Paged<>(postPage, Paging.of(postPage.getTotalPages(), pageNumber, size));
	}

	@Override
	public List<BillReport> findAllByDailyRegister(Date fromDate, Date toDate) {
		return billEntryHeaderRepository.findAllByDailyRegister(fromDate, toDate);
	}

	@Override
	public List<BillReport> fetchSummary(Date fromDate, Date toDate) {
		return billEntryHeaderRepository.fetchSummary(fromDate, toDate);
	}

	@Override
	public Paged<BillReport> partyWiseBalReport(Date fromDate, Date toDate, Integer partyCode, int pageNumber,
			int size) {
		PageRequest request=PageRequest.of(pageNumber - 1, size);
		Page<BillReport> postPage= billEntryHeaderRepository.partyWiseBalReport(fromDate, toDate, partyCode, request);
		return new Paged<>(postPage, Paging.of(postPage.getTotalPages(), pageNumber, size));
	}

	@Override
	public List<BillReport> partyWiseBalReportPrint(Date fromDate, Date toDate, Integer partyCode) {
		return billEntryHeaderRepository.partyWiseBalReportPrint(fromDate, toDate, partyCode);
	}

	@Override
	public List<BillReport> fetchpartyWiseBalSummary(Date fromDate, Date toDate, Integer partyCode) {
		return billEntryHeaderRepository.fetchpartyWiseBalSummary(fromDate, toDate,partyCode);
	}
	
	@Override
	public Paged<BillReport> custBalanceRegister(Date fromDate, Date toDate, int pageNumber, int size) {
		
		PageRequest request=PageRequest.of(pageNumber - 1, size,Sort.by("bill_date").descending());
		logger.info("==========="+fromDate);
		logger.info("==========="+toDate);
        Page<BillReport> postPage = billEntryHeaderRepository.findAllCustBalRegByTransationDateBetween(fromDate,toDate,request);
        logger.info("==========="+postPage.get().count());
        return new Paged<>(postPage, Paging.of(postPage.getTotalPages(), pageNumber, size));
	}
	
	@Override
	public List<BillReport> findAllcustBalanceRegister(Date fromDate, Date toDate) {
		return billEntryHeaderRepository.findAllcustBalanceRegister(fromDate, toDate);
	}

	@Override
	public List<BillReport> fetchDailyTranSummary(Date fromDate, Date toDate) {
		return billEntryHeaderRepository.fetchDailyTranSummary(fromDate, toDate);
	}
}
