package com.bytecode.hallmarks.model;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name = "PARTYMASTER")
public class PartyMaster {

	@Id
	@Column(name = "PARTY_CODE")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "party_seq")
	@SequenceGenerator(name = "party_seq", allocationSize = 1)
	private int partyCode;

	@Column(name = "PARTY_NAME")
	@Length(min = 1, max = 150, message = "*Your Party name must have minimum 5 and Max 150 characters")
	private String partyName;

	@Column(name = "ADDRESS")
	@Length(min = 1, max = 250, message = "*Your Address must have minimum 5 and Max 250  characters")
	private String address;

	@Column(name = "MOBILE_NO")
	@Length(min = 10, max = 20, message = "*Your Mobile No. must have at least 10 characters")
	private String mobileNo;

	@Column(name = "GST_NO")
	@Length(max = 20, message = "*Your GST No. Max 20 characters")
	private String gstNo;

	
	@Column(name = "LICENSE_NO")
	private String licenseNo;

	@Column(name = "LICENSE_TYPE")
	@Length(min = 1, max = 20, message = "*Your License Type must have at least 10 characters")
	private String licenseType;

	@Column(name = "LIC_EXPIRTY_DATE")
	private String licExpiryDate;

	@Column(name = "ACTIVE")
	private Boolean active;

	@Column(name = "CREATED_BY", updatable = false)
	@Length(max = 45, message = "*Created By must have Max 45 characters")
	private String createdBy;

	@Column(name = "CREATED_DATE", updatable = false)
	private Instant createdDate;

	@Column(name = "MODIFIED_BY")
	@Length(max = 45, message = "*Modified By must have Max 45 characters")
	private String modifiedBy;

	@Column(name = "MODIFIED_DATE")
	private Instant modifiedDate;

	public int getPartyCode() {
		return partyCode;
	}

	public void setPartyCode(int partyCode) {
		this.partyCode = partyCode;
	}

	public String getPartyName() {
		return partyName;
	}

	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getLicExpiryDate() {
		return licExpiryDate;
	}

	public void setLicExpiryDate(String licExpiryDate) {
		this.licExpiryDate = licExpiryDate;
	}

	public String getLicenseNo() {
		return licenseNo;
	}

	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}

	public String getLicenseType() {
		return licenseType;
	}

	public void setLicenseType(String licenseType) {
		this.licenseType = licenseType;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Instant getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Instant createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Instant getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Instant modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getGstNo() {
		return gstNo;
	}

	public void setGstNo(String gstNo) {
		this.gstNo = gstNo;
	}

}
