package com.bytecode.hallmarks.repository;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bytecode.hallmarks.model.BillEntryHeader;
import com.bytecode.hallmarks.service.BillReport;

@Repository
public interface BillEntryHeaderRepository extends JpaRepository<BillEntryHeader, Integer> {
	@Query(value = "SELECT max(invoiceNo) FROM BillEntryHeader")
	public Integer getInvoiceNo();

	@Query("from BillEntryHeader where (iscancelled is NULL or iscancelled ='N') and partyCode=:partyCode order by transationDate desc")
	public List<BillEntryHeader> fetchPreviousBillDtl(@Param("partyCode") Integer partyCode);

	@Query("from BillEntryHeader where (iscancelled is NULL or iscancelled ='N') and balanceAmount > 0 order by transationDate desc")
	public List<BillEntryHeader> fetchPendingAmountBills();

	@Query(value = "select * from bill_entry_header where (iscancelled is NULL or iscancelled ='N') and party_code=:partCode and  DATE(transation_date) between :fromDate and :todate ", nativeQuery = true)
	public Page<BillEntryHeader> findAllByTransationDateBetween(@Param("fromDate") Date fromDate,
			@Param("todate") Date todate, @Param("partCode") Integer partCode, Pageable aInPageable);

	@Query(value = "select * from bill_entry_header where (iscancelled is NULL or iscancelled ='N')  and DATE(transation_date) between :fromDate and :todate ", nativeQuery = true)
	public Page<BillEntryHeader> findAllByTransationDateBetween(@Param("fromDate") Date fromDate,
			@Param("todate") Date todate, Pageable aInPageable);

	@Transactional
	@Modifying
	@Query("update BillEntryHeader set balanceAmount=:balanceAmount , receivedAmount =:receivedAmt,updatedBy=:updatedBy ,updatedDate=:updatedDate , transationDate =:transationDate where invoiceNo =:invoiceNo ")
	public void updateBillAmount(@Param("invoiceNo") Integer invoiceNo, @Param("balanceAmount") Double balanceAmount,
			@Param("receivedAmt") Double receivedAmount, @Param("updatedBy") String updatedBy,
			@Param("updatedDate") Timestamp todate, @Param("transationDate") Timestamp transationDate);

	@Query(value = "select * from bill_entry_header where (iscancelled is NULL or iscancelled ='N') and DATE(bill_date) between :fromDate and :todate ", nativeQuery = true)
	public Page<BillEntryHeader> findAllBillByTransationDateBetween(@Param("fromDate") Date fromDate,
			@Param("todate") Date todate, Pageable aInPageable);

	@Transactional
	@Modifying
	@Query("update BillEntryHeader set iscancelled='Y' ,updatedBy=:updatedBy ,updatedDate=:updatedDate  where invoiceNo =:invoiceNo ")
	public void canceleBill(@Param("invoiceNo") Integer invoiceNo, @Param("updatedBy") String updatedBy,
			@Param("updatedDate") Timestamp todate);

	public BillEntryHeader findAllByInvoiceNo(Integer invoiceNo);

	@Query("from BillEntryHeader where invoiceNo !=:invoiceNo and partyCode=:partCode and (iscancelled is NULL or iscancelled ='N') and balanceAmount > 0 order by transationDate desc")
	public List<BillEntryHeader> fetchPendingAmountBillsOther(@Param("partCode") Integer partCode,
			@Param("invoiceNo") Integer invoiceNo);

	@Query(value = "SELECT h.invoice_no as invoiceNo,(SELECT " + " GROUP_CONCAT( distinct d.bill_type) "
			+ " FROM bill_entry_detail d where d.invoice_no =h.invoice_no "
			+ " ) as category ,h.party_name as partyName, h.bill_Date as billDate, h.balance_amt as balanceAmount,coalesce(h.discount,0),\r\n"
			+ "h.received_amt as receivedAmount, h.sub_total as subTotal,h.total_qty as totalQty,h.total_weight as totalWeight,(CASE\n" + 
			"    WHEN h.balance_amt = 0 THEN 'PAID'  ELSE '' END) as status,coalesce(GST_RATE,0) as gstRate,coalesce(PENDING_BILL_AMT,0) as pendingBillAmt  from bill_entry_header h  where DATE(bill_date) between :fromDate and :todate order by created_date desc", 
			countQuery = "SELECT count(*) FROM bill_entry_header where DATE(bill_date) between :fromDate and :todate", nativeQuery = true)
	public Page<BillReport> findAllDataByTransationDateBetween(@Param("fromDate") Date fromDate,
			@Param("todate") Date todate, Pageable aInPageable);

	@Query(value = "SELECT h.invoice_no as invoiceNo,(SELECT " + " GROUP_CONCAT( distinct d.bill_type) "
			+ " FROM bill_entry_detail d where d.invoice_no =h.invoice_no "
			+ " ) as category ,h.party_name as partyName, h.bill_Date as billDate, coalesce(h.balance_amt,0) as balanceAmount,coalesce(h.discount,0) as discount,\r\n"
			+ "coalesce(h.received_amt,0) as receivedAmount, coalesce(h.sub_total,0) as subTotal,coalesce(h.total_qty,0) as totalQty,coalesce(h.total_weight,0) as totalWeight,(CASE " + 
			" WHEN h.balance_amt = 0 THEN 'PAID' " + 
			" ELSE '' " + 
			" END) as status,coalesce(GST_RATE,0) as gstRate,coalesce(PENDING_BILL_AMT,0) as pendingBillAmt from bill_entry_header h  where DATE(bill_date) between :fromDate and :todate order by created_date desc", nativeQuery = true)
	public List<BillReport> findAllByDailyRegister(@Param("fromDate") Date fromDate, @Param("todate") Date todate);

	
	@Query(value = "SELECT coalesce(sum(total_qty),0) as totalQty,coalesce(sum(total_weight),0) as totalWeight ,coalesce(ROUND(sum(sub_total), 2),0) as subTotal,coalesce(ROUND(sum(discount),2),0) as discount,coalesce(ROUND(sum(received_amt)),0) as receivedAmount,coalesce(ROUND(sum(balance_amt)),0) as balanceAmount,coalesce(ROUND(sum(GST_RATE)),0) as gstRate,coalesce(ROUND(sum(PENDING_BILL_AMT)),0) as pendingBillAmt from bill_entry_header h  where DATE(bill_date) between :fromDate and :todate order by created_date desc", nativeQuery = true)
	public List<BillReport> fetchSummary(@Param("fromDate") Date fromDate, @Param("todate") Date todate);
	
	@Query(value = "SELECT h.invoice_no as invoiceNo,(SELECT " + " GROUP_CONCAT( distinct d.bill_type) "
			+ " FROM bill_entry_detail d where d.invoice_no =h.invoice_no "
			+ " ) as category ,h.party_name as partyName, h.bill_Date as billDate, h.balance_amt as balanceAmount,h.discount,\r\n"
			+ "h.received_amt as receivedAmount, h.sub_total as subTotal,h.total_qty as totalQty,h.total_weight as totalWeight from bill_entry_header h "
			+ " where DATE(bill_date) between :fromDate and :todate and party_code=:partCode order by created_date desc", 
			countQuery = "SELECT count(*) FROM bill_entry_header where DATE(bill_date) between :fromDate and :todate and party_code=:partCode ", nativeQuery = true)
	public Page<BillReport> partyWiseBalReport(@Param("fromDate") Date fromDate,
			@Param("todate") Date todate,@Param("partCode") Integer partCode, Pageable aInPageable);
	
	@Query(value = "SELECT h.invoice_no as invoiceNo,(SELECT " + " GROUP_CONCAT( distinct d.bill_type) "
			+ " FROM bill_entry_detail d where d.invoice_no =h.invoice_no "
			+ " ) as category ,h.party_name as partyName, h.bill_Date as billDate, h.balance_amt as balanceAmount,h.discount,\r\n"
			+ "coalesce(h.received_amt,0) as receivedAmount, h.sub_total as subTotal,h.total_qty as totalQty,h.total_weight as totalWeight from bill_entry_header h "
			+ " where DATE(bill_date) between :fromDate and :todate and party_code=:partCode order by created_date desc", 
			nativeQuery = true)
	public List<BillReport> partyWiseBalReportPrint(@Param("fromDate") Date fromDate,
			@Param("todate") Date todate,@Param("partCode") Integer partCode);

	
	@Query(value = "SELECT sum(total_qty) as totalQty,sum(total_weight) as totalWeight ,ROUND(sum(sub_total), 2) as subTotal,coalesce(ROUND(sum(received_amt),2),0) as receivedAmount,coalesce(ROUND(sum(balance_amt),2),0) as balanceAmount from bill_entry_header h  "
			+ "where DATE(bill_date) between :fromDate and :todate and party_code=:partCode order by created_date desc", nativeQuery = true)
	public List<BillReport> fetchpartyWiseBalSummary(@Param("fromDate") Date fromDate, @Param("todate") Date todate,@Param("partCode") Integer partCode);
	
//	@Query(value = "SELECT beh.invoice_no as invoiceNo, beh.iscancelled, beh.bill_date as billDate, beh.created_by, beh.created_date, beh.license_no, beh.license_type, beh.party_name as partyName, beh.received_amt as receivedAmount, beh.request_no, beh.sub_total as subTotal, beh.total_qty as totalQty, beh.total_weight as totalWeight, beh.updated_by, beh.updated_date, beh.balance_amt as balanceAmount, beh.discount, beh.transation_date, beh.party_code, beh.gst_no, beh.pending_bill_amt, beh.pending_bill_date, beh.pending_bill_no, beh.sample_weight, beh.grand_total, beh.gst_rate, pm.mobile_no as mobileNo FROM bill_entry_header beh, partymaster pm  where beh.party_code=pm.party_code and  (iscancelled is NULL or iscancelled ='N') and DATE(bill_date) between :fromDate and :todate group by party_code order by created_date desc", nativeQuery = true)
	@Query(value = "SELECT beh.invoice_no as invoiceNo, beh.iscancelled, beh.bill_date as billDate, beh.created_by, beh.created_date, beh.license_no, beh.license_type, beh.party_name as partyName, beh.received_amt as receivedAmount, beh.request_no, beh.sub_total as subTotal, beh.total_qty as totalQty, beh.total_weight as totalWeight, beh.updated_by, beh.updated_date, beh.balance_amt as balanceAmount, beh.discount, beh.transation_date, beh.party_code, beh.gst_no, beh.pending_bill_amt, beh.pending_bill_date, beh.pending_bill_no, beh.sample_weight, beh.grand_total, beh.gst_rate, pm.mobile_no as mobileNo FROM bill_entry_header beh, partymaster pm, (select party_code, max(transation_date) as transation_date  FROM hallmark.bill_entry_header where DATE(bill_date) between :fromDate and :todate GROUP BY party_code) a  where beh.party_code=pm.party_code and beh.party_code= a.party_code and beh.transation_date = a.transation_date and  (iscancelled is NULL or iscancelled ='N') and DATE(bill_date) between :fromDate and :todate group by party_code order by created_date desc", nativeQuery = true)
	public Page<BillReport> findAllCustBalRegByTransationDateBetween(@Param("fromDate") Date fromDate,
			@Param("todate") Date todate, Pageable aInPageable);
	
	@Query(value = "SELECT beh.invoice_no as invoiceNo, beh.iscancelled, beh.bill_date as billDate, beh.created_by, beh.created_date, beh.license_no, beh.license_type, beh.party_name as partyName, beh.received_amt as receivedAmount, beh.request_no, beh.sub_total as subTotal, beh.total_qty as totalQty, beh.total_weight as totalWeight, beh.updated_by, beh.updated_date, beh.balance_amt as balanceAmount, beh.discount, beh.transation_date, beh.party_code, beh.gst_no, beh.pending_bill_amt, beh.pending_bill_date, beh.pending_bill_no, beh.sample_weight, beh.grand_total, beh.gst_rate, pm.mobile_no as mobileNo FROM bill_entry_header beh, partymaster pm, (select party_code, max(transation_date) as transation_date  FROM hallmark.bill_entry_header where DATE(bill_date) between :fromDate and :todate GROUP BY party_code) a   where beh.party_code=pm.party_code and beh.party_code= a.party_code and beh.transation_date = a.transation_date and  (iscancelled is NULL or iscancelled ='N' ) and DATE(bill_date) between :fromDate and :todate group by party_code order by created_date desc", nativeQuery = true)
	public List<BillReport> findAllcustBalanceRegister(@Param("fromDate") Date fromDate, @Param("todate") Date todate);
	
	@Query(value = "SELECT coalesce(sum(total_qty),0) as totalQty,coalesce(sum(total_weight),0) as totalWeight ,coalesce(ROUND(sum(sub_total), 2),0) as subTotal,coalesce(ROUND(sum(discount),2),0) as discount,coalesce(ROUND(sum(received_amt)),0) as receivedAmount,coalesce(ROUND(sum(balance_amt)),0) as balanceAmount,coalesce(ROUND(sum(GST_RATE)),0) as gstRate,coalesce(ROUND(sum(PENDING_BILL_AMT)),0) as pendingBillAmt from "
			+ "(SELECT total_qty,total_weight ,sub_total,discount,received_amt,balance_amt,GST_RATE,PENDING_BILL_AMT FROM bill_entry_header beh, (select party_code, max(transation_date) as transation_date  FROM bill_entry_header where DATE(bill_date) between :fromDate and :todate GROUP BY party_code) a  where  beh.party_code= a.party_code and beh.transation_date = a.transation_date  and DATE(bill_date) between :fromDate and :todate group by beh.party_code order by created_date desc) b ", nativeQuery = true)
	public List<BillReport> fetchDailyTranSummary(@Param("fromDate") Date fromDate, @Param("todate") Date todate);
}


