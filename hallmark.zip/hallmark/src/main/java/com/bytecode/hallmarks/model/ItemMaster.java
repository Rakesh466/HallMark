package com.bytecode.hallmarks.model;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name = "ITEMMASTER")
public class ItemMaster {

	@Id
	@Column(name = "ITEM_CODE")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "item_seq")
	@SequenceGenerator(name = "item_seq", allocationSize = 1)
	private int itemCode;

	@Column(name = "ITEM_NAME")
	@Length(min = 1, max = 150, message = "*Your Item name must have minimum 5 and max 150 characters")
	private String itemName;

	@Column(name = "ACTIVE")
	private Boolean active;

	@Column(name = "CREATED_BY", updatable = false)
	@Length(max = 45, message = "*Created By must have Max 45 characters")
	private String createdBy;

	@Column(name = "CREATED_DATE", updatable = false)
	private Instant createdDate;

	@Column(name = "MODIFIED_BY")
	@Length(max = 45, message = "*Modified By must have Max 45 characters")
	private String modifiedBy;

	@Column(name = "MODIFIED_DATE")
	private Instant modifiedDate;

	public int getItemCode() {
		return itemCode;
	}

	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Instant getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Instant createdDate) {
		this.createdDate = createdDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Instant getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Instant modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

}
