package com.bytecode.hallmarks.service;

public class PageItemBuilder {
	 PageItemType pageItemType;
     int index;
    boolean active;
    
    public PageItemBuilder pageItemType(PageItemType pageItemType) {
    	this.pageItemType=pageItemType;
    	return this;
    }
    public PageItemBuilder index(int index) {
    	this.index=index;
    	return this;
    }
    public PageItemBuilder active(boolean active) {
    	this.active=active;
    	return this;
    }
    public PageItem build() {
    	PageItem pageItem =  new PageItem(this);
        return pageItem;
    }
}
