package com.bytecode.hallmarks.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.bytecode.hallmarks.model.ItemMaster;
import com.bytecode.hallmarks.service.ItemMasterService;
import com.bytecode.hallmarks.service.Paged;
import com.bytecode.hallmarks.util.HallMarkUtil;

@Controller
public class ItemMasterController {
	
	 Logger logger = LoggerFactory.getLogger(ItemMasterController.class);
	 
    @Autowired
    private ItemMasterService itemMasterService;
    
    @GetMapping(value="/loadItemMaster")
    public ModelAndView loadPartyMaster(){
    	List<ItemMaster> itemMasterList =itemMasterService.listAll();
    	logger.info("partyMasterList size {}: ", itemMasterList.size());
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("itemMasterList",itemMasterList);
        modelAndView.addObject("itemMaster", new ItemMaster());
        modelAndView.setViewName("itemMaster");
        return modelAndView;
    }
    
    @GetMapping(value = "/loadItemMasterPage")
	public ModelAndView loadItemMasterPage(@RequestParam(value = "pageNumber", required = false, defaultValue = "1") int pageNumber,
            @RequestParam(value = "size", required = false, defaultValue = "10") int size,@RequestParam(value = "keyword", required = false) String keyword, Model model){
    	Paged<ItemMaster> itemMasterList=null;
    	ModelAndView modelAndView = new ModelAndView();
    	if(!HallMarkUtil.isEmpty(keyword)) {
			logger.info("keyword:"+keyword);
			itemMasterList = itemMasterService.fetchAllItemList(keyword,pageNumber,size);
			modelAndView.addObject("keyword", keyword);
		}else {
    	 itemMasterList =itemMasterService.fetchItemDtl(pageNumber, size);
		}
    	
    	modelAndView.addObject("itemMasterList",itemMasterList);
    	modelAndView.addObject("itemMaster", new ItemMaster());
    	modelAndView.setViewName("itemMaster");
    	return modelAndView;
    }
    
    @GetMapping(value="/getItemMaster/{itemCode}")
    public ModelAndView getItemMaster(@PathVariable(name = "itemCode") int itemCode){
    	logger.info("itemCode : {}", itemCode);
    	logger.info("###################### : ");
    	ItemMaster itemMaster =itemMasterService.get(itemCode);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("itemMaster",itemMaster);
        modelAndView.setViewName("itemMaster");
        return modelAndView;
    }
    
    @PostMapping("/saveItemMaster")
    public String saveEmployee(@ModelAttribute("itemMaster") ItemMaster itemMaster) {
    	itemMaster.setActive(true);
    	itemMasterService.save(itemMaster);
    	return "redirect:/loadItemMasterPage";
    	 
    }
    
    @PostMapping("/deleteItem/{itemCode}")
    public String deleteProduct(@PathVariable(name = "itemCode") int itemCode) {
    	itemMasterService.delete(itemCode);
        return "redirect:/loadItemMasterPage";       
    }
    
    @PostMapping("/deleteMultiItem/")
    public String deleteMultiItem(HttpServletRequest req) {
    	String[] codes = req.getParameterValues("idChecked");
    	if(null != codes) {
	    	for(String code : codes) {
	    		itemMasterService.delete(Integer.parseInt(code));
	    	}
    	}
        return "redirect:/loadItemMasterPage";       
    }
}
