package com.bytecode.hallmarks.service;

public enum PageItemType {
	DOTS,
    PAGE
}
