package com.bytecode.hallmarks.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bytecode.hallmarks.model.BillAudit;

public interface BillAuditRepository extends JpaRepository<BillAudit, Long>{

}
