package com.bytecode.hallmarks.service;

public class PageItem {
	private PageItemType pageItemType;
    private int index;
    private boolean active;
    
	public PageItemType getPageItemType() {
		return pageItemType;
	}
	public void setPageItemType(PageItemType pageItemType) {
		this.pageItemType = pageItemType;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	
	public PageItem(PageItemType pageItemType, int index, boolean active) {
		super();
		this.pageItemType = pageItemType;
		this.index = index;
		this.active = active;
	}
	public PageItem(PageItemBuilder pageItemBuilder) {
		this.pageItemType = pageItemBuilder.pageItemType;
		this.index = pageItemBuilder.index;
		this.active = pageItemBuilder.active;
	}
	public static PageItemBuilder builder() {
		return new PageItemBuilder();
	}
}
