package com.bytecode.hallmarks.util;

import java.math.RoundingMode;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;


public class HallMarkUtil {
	 private static final DecimalFormat df = new DecimalFormat("0.00");
	public static String currentDate() {
		DateTimeFormatter FOMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate localDate = LocalDate.now();
		return FOMATTER.format(localDate);
	}
	
	public static String currentDate(String DateFormat) {
		DateTimeFormatter FOMATTER = DateTimeFormatter.ofPattern(DateFormat);
		LocalDate localDate = LocalDate.now();
		return FOMATTER.format(localDate);
	}
	 public static Timestamp convertStringToTimestamp(String strDate) throws Exception {
		    try {
		      DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		       // you can change format of date
		      Date date = formatter.parse(strDate);
		      Timestamp timeStampDate = new Timestamp(date.getTime());

		      return timeStampDate;
		    } catch (ParseException e) {
		      System.out.println("Exception :" + e);
		      throw new Exception("Exception at date parsing");
		    }
		  }
	 public static java.sql.Date convertStrintTOSqlDate(String strDate) {
		 java.sql.Date dateconverted=java.sql.Date.valueOf(strDate);
		 System.out.println("strDate=="+strDate);
		 System.out.println("dateconverted=="+dateconverted);
		 return dateconverted;
	 }
	 public static Timestamp currentSqlTimestamp() {
		    try {
		     java.util.Date currentdate=new java.util.Date();
		      Timestamp timeStampDate = new Timestamp(currentdate.getTime());

		      return timeStampDate;
		    } catch (Exception e) {
		      System.out.println("Exception :" + e);
		      return null;
		    }
		  }
	 public static java.sql.Date currentSqlDate() {
		return 	 new java.sql.Date(Calendar.getInstance().getTime().getTime());

	 }
	 
	 public static Date currentUtilDate(String DateFormat) throws ParseException {
		 DateFormat formatter = new SimpleDateFormat(DateFormat);
		 Date today = new Date();
		 Date todayWithZeroTime = formatter.parse(formatter.format(today));
		return todayWithZeroTime;
		 }
	 public static boolean isEmpty(String str) {
		 return (null==str || "".equals(str) || "null".equals(str)); 
	 }
	 
	 public static Date convertStringToDateUtil(String strDate,String DateFormat) throws ParseException {
		 SimpleDateFormat formatter=new SimpleDateFormat(DateFormat);
			
			return formatter.parse(strDate);
		}
	 

	    public static Double formtAmount(Double amount) {

	        //df.setRoundingMode(RoundingMode.DOWN);
	        //System.out.println("\ndouble (RoundingMode.DOWN) : " + df.format(amount));  //3.14

	        df.setRoundingMode(RoundingMode.UP);
	        return Double.valueOf(df.format(amount));
	    }
	    
	    public static String convertDateToString(java.sql.Date strDate,String DateFormat) throws ParseException {
			 SimpleDateFormat formatter=new SimpleDateFormat(DateFormat);
				return formatter.format(strDate);
			}
}
