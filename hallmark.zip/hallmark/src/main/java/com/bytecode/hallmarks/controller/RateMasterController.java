package com.bytecode.hallmarks.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.bytecode.hallmarks.model.RateMaster;
import com.bytecode.hallmarks.service.Paged;
import com.bytecode.hallmarks.service.RateMasterService;

@Controller
public class RateMasterController {

	Logger logger = LoggerFactory.getLogger(RateMasterController.class);
	String exceptionDetails = "";

	@Autowired
	private RateMasterService rateMasterService;

	@GetMapping(value = "/loadRateMaster")
	public ModelAndView loadPartyMaster() {
		List<RateMaster> rateMasterList = rateMasterService.listAll();
		logger.info("rateMasterList size : ", rateMasterList.size());
		for (RateMaster rateMaster : rateMasterList) {
			System.out.println(rateMaster.getRateType());
			
		}
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("rateMasterList", rateMasterList);
		modelAndView.addObject("rateMaster", new RateMaster());
		modelAndView.addObject("exceptionDetails", exceptionDetails);
		modelAndView.setViewName("rateMaster");
		return modelAndView;
	}
	
	@GetMapping(value = "/loadRateMasterPage")
	public ModelAndView loadPartyMasterPage(@RequestParam(value = "pageNumber", required = false, defaultValue = "1") int pageNumber,
            @RequestParam(value = "size", required = false, defaultValue = "10") int size, Model model){
		Paged<RateMaster> rateMasterList = rateMasterService.fetchRateDtl(pageNumber, size);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("rateMasterList", rateMasterList);
		modelAndView.addObject("rateMaster", new RateMaster());
		modelAndView.addObject("exceptionDetails", exceptionDetails);
		modelAndView.setViewName("rateMaster");
		return modelAndView;
	}

	@GetMapping(value = "/getRateMaster/{rateCode}")
	public String getPartyMaster(@PathVariable(name = "rateCode") int rateCode, Model model) {
		logger.info("rateCode : {}", rateCode);
		RateMaster rateMaster = rateMasterService.get(rateCode);
		model.addAttribute("rateMaster", rateMaster);

		return "rateMaster";
	}

	@PostMapping("/saveRateMaster")
	public String saveRateMaster(@ModelAttribute("rateMaster") RateMaster rateMaster, Model model) throws Exception {
		setExceptionDetails("");
		try {
			rateMasterService.save(rateMaster);
		} catch (Exception e) {
			setExceptionDetails( e.getMessage());
		}
		return "redirect:/loadRateMasterPage";
	}

	@PostMapping("/deleteRate/{rateCode}")
	public String deleteRate(@PathVariable(name = "rateCode") int rateCode) {
		rateMasterService.delete(rateCode);
		return "redirect:/loadRateMasterPage";
	}

	public String getExceptionDetails() {
		return exceptionDetails;
	}

	public void setExceptionDetails(String exceptionDetails) {
		this.exceptionDetails = exceptionDetails;
	}

	@PostMapping("/deleteMultiRate/")
    public String deleteMultiItem(HttpServletRequest req) {
    	String[] codes = req.getParameterValues("idChecked");
    	if(null != codes) {
	    	for(String code : codes) {
	    		rateMasterService.delete(Integer.parseInt(code));
	    	}
    	}
        return "redirect:/loadRateMasterPage";       
    }
	
}
