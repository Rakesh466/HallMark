package com.bytecode.hallmarks.service;

import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bytecode.hallmarks.model.PartyMaster;
import com.bytecode.hallmarks.model.RateMaster;
import com.bytecode.hallmarks.repository.RateMasterRepository;

@Service
@Transactional
public class RateMasterService {

	@Autowired
	private RateMasterRepository repo;

	public List<RateMaster> listAll() {
		return repo.findAll();
	}

	public void save(RateMaster rateMaster) throws Exception {
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (rateMaster.getRateCode() == 0) {
			List<RateMaster> rateMasterList = repo.rateMasterList();
			for (RateMaster rateMaster2 : rateMasterList) {
				if(rateMaster2.getRateType().equalsIgnoreCase(rateMaster.getRateType())) {
					System.out.println(rateMaster2.getRateType() + "   " + rateMaster.getRateType());
					throw new Exception("Rate Type already Exist");
				}
			}
			
			rateMaster.setCreatedBy(userDetails.getUsername());
			rateMaster.setCreatedDate(Instant.now());
		} else {
			rateMaster.setModifiedBy(userDetails.getUsername());
			rateMaster.setModifiedDate(Instant.now());
		}
		rateMaster.setActive(true);
		repo.save(rateMaster);
	}

	public RateMaster get(Integer id) {
		return repo.findById(id).get();
	}

	public void delete(Integer id) {
		repo.deleteById(id);
	}

	public List<RateMaster> partyMasterList() {
		return repo.rateMasterList();
	}
	
	public Paged<RateMaster> fetchRateDtl(int pageNumber, int size) {
		PageRequest request=PageRequest.of(pageNumber - 1, size,Sort.by("rate_code").descending());
        Page<RateMaster> postPage = repo.fetchRateDtl(request);
        return new Paged<>(postPage, Paging.of(postPage.getTotalPages(), pageNumber, size));
	}
	
}
