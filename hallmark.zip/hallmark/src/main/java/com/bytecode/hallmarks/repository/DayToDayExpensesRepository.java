package com.bytecode.hallmarks.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bytecode.hallmarks.model.DayToDayExpenses;
import com.bytecode.hallmarks.service.BillReport;
import com.bytecode.hallmarks.service.DailyReport;

public interface DayToDayExpensesRepository extends JpaRepository<DayToDayExpenses, Integer> {

	@Query(value = "SELECT daytodayexp_code as daytodayexpCode, active, amount , bank_name as bankName , cheque_no as chequeNo, created_by as createdBy, created_date as createdDate, modified_by as modifiedBy, modified_date as modifiedDate, name, narration, payment_date as paymentDate , payment_mode as paymentMode, payment_type as paymentType FROM daytodayexpenses where DATE(payment_date) between :fromDate and :todate",
			countQuery = "SELECT count(1) FROM daytodayexpenses where DATE(payment_date) between :fromDate and :todate", nativeQuery = true)
	public Page<DailyReport> findAllcashDayBookByTransationDateBetween(@Param("fromDate") Date fromDate,
			@Param("todate") Date todate, Pageable aInPageable);

	@Query(value = "SELECT daytodayexp_code as daytodayexpCode, active, amount , bank_name as bankName , cheque_no as chequeNo, created_by as createdBy, created_date as createdDate, modified_by as modifiedBy, modified_date as modifiedDate, name, narration, payment_date as paymentDate , payment_mode as paymentMode, payment_type as paymentType FROM daytodayexpenses where DATE(payment_date) between :fromDate and :todate order by payment_date", nativeQuery = true)
	public List<DailyReport> findAllCashDayBook(@Param("fromDate") Date fromDate, @Param("todate") Date todate);

	@Query(value = "SELECT coalesce(sum(amount),0) as totalAmount from daytodayexpenses where DATE(payment_date) between :fromDate and :todate order by created_date desc", nativeQuery = true)
	public List<Double> fetchSummary(@Param("fromDate") Date fromDate, @Param("todate") Date todate);
}
