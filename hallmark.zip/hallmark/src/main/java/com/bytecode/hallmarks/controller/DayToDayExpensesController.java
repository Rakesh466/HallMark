package com.bytecode.hallmarks.controller;

import java.sql.Date;
import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bytecode.hallmarks.model.DayToDayExpenses;
import com.bytecode.hallmarks.service.BillEntryService;
import com.bytecode.hallmarks.service.BillReport;
import com.bytecode.hallmarks.service.DailyReport;
import com.bytecode.hallmarks.service.DayToDayExpensesService;
import com.bytecode.hallmarks.service.Paged;
import com.bytecode.hallmarks.util.HallMarkUtil;

@Controller
public class DayToDayExpensesController {

	Logger logger = LoggerFactory.getLogger(DayToDayExpensesController.class);

	@Autowired
	private DayToDayExpensesService dayToDayExpensesService;
	
	@Autowired
	BillEntryService billEntryService;

	@GetMapping(value = "/loadDayToDayExpenses")
	public ModelAndView loadPartyMaster() {
		List<DayToDayExpenses> dayToDayExpensesList = dayToDayExpensesService.listAll();
		logger.info("dayToDayExpensesList size : ", dayToDayExpensesList.size());
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("dayToDayExpensesList", dayToDayExpensesList);
		modelAndView.addObject("dayToDayExpenses", new DayToDayExpenses());
		modelAndView.setViewName("daytoDayExp");
		return modelAndView;
	}

	@GetMapping(value = "/getDayToDayExpenses/{dayToDayExpCode}")
	public String getPartyMaster(@PathVariable(name = "dayToDayExpCode") int dayToDayExpCode, Model model) {
		logger.info("dayToDayExpCode : {}", dayToDayExpCode);
		DayToDayExpenses dayToDayExpenses = dayToDayExpensesService.get(dayToDayExpCode);
		model.addAttribute("dayToDayExpenses", dayToDayExpenses);
		return "daytoDayExp";
	}

	@PostMapping("/saveDayToDayExpenses")
	public String saveDayToDayExpenses(@ModelAttribute("dayToDayExpenses") DayToDayExpenses dayToDayExpenses) {
		dayToDayExpensesService.save(dayToDayExpenses);
		return "redirect:/loadDayToDayExpenses";
	}

	@PostMapping("/deleteDayToDayExpenses/{dayToDayExpCode}")
	public String deleteProduct(@PathVariable(name = "dayToDayExpCode") int dayToDayExpCode) {
		dayToDayExpensesService.delete(dayToDayExpCode);
		return "redirect:/loadDayToDayExpenses";
	}
	
	@PostMapping("/deleteMultiDayToDayExpCode/")
    public String deleteMultiDayToDayExpCode(HttpServletRequest req) {
    	String[] codes = req.getParameterValues("idChecked");
    	if(null != codes) {
	    	for(String code : codes) {
	    		dayToDayExpensesService.delete(Integer.parseInt(code));
	    	}
    	}
        return "redirect:/loadDayToDayExpenses";       
    }
	
	@GetMapping("/cashDayBookPage")
	public ModelAndView custBalanceRegisterPage(Model model) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("cashDayBook");
		Paged<DailyReport> outFlow = dayToDayExpensesService.cashDayBook(HallMarkUtil.currentSqlDate(), HallMarkUtil.currentSqlDate(), 1, 10);
		Paged<BillReport> inFlow = billEntryService.findAllDataByTransationDateBetween(HallMarkUtil.currentSqlDate(),HallMarkUtil.currentSqlDate(),1, 10);
		
		model.addAttribute("outFlow", outFlow);
		model.addAttribute("inFlow", inFlow );
		if(outFlow.page.getTotalPages() > inFlow.page.getTotalPages()) {
			model.addAttribute("pageObject",outFlow);
		}else {
			model.addAttribute("pageObject",inFlow);
		}
		List<BillReport> summaryList=billEntryService.fetchSummary(HallMarkUtil.currentSqlDate(), HallMarkUtil.currentSqlDate());
		List<Double> dailySummaryList=dayToDayExpensesService.fetchSummary(HallMarkUtil.currentSqlDate(), HallMarkUtil.currentSqlDate());
        model.addAttribute("summaryList",summaryList);
        model.addAttribute("dailySummaryList",dailySummaryList.stream().mapToDouble(Double::doubleValue).sum());
		model.addAttribute("fromDate", HallMarkUtil.currentSqlDate());
		model.addAttribute("toDate", HallMarkUtil.currentSqlDate());
		
		return modelAndView;
	}
	
	@GetMapping("/cashDayBook")
	public ModelAndView cashDayBook(@RequestParam(value="fromDate") Date fromDate,@RequestParam(value="toDate") Date toDate,@RequestParam(value = "pageNumber", required = false, defaultValue = "1") int pageNumber,
            @RequestParam(value = "size", required = false, defaultValue = "10") int size, Model model){
		logger.info("cashDayBook::========================================={}",pageNumber);
        ModelAndView modelAndView = new ModelAndView();
        
        Paged<DailyReport> outFlow = dayToDayExpensesService.cashDayBook(fromDate,toDate,pageNumber, size);
		Paged<BillReport> inFlow = billEntryService.findAllDataByTransationDateBetween(fromDate,toDate,pageNumber, size);
		model.addAttribute("outFlow", outFlow);
		model.addAttribute("inFlow", inFlow );
		
		if(outFlow.page.getTotalPages() > inFlow.page.getTotalPages()) {
			model.addAttribute("pageObject",outFlow);
		}else {
			model.addAttribute("pageObject",inFlow);
		}
		
        List<BillReport> summaryList=billEntryService.fetchSummary(fromDate, toDate);
        List<Double> dailySummaryList=dayToDayExpensesService.fetchSummary(fromDate, toDate);
        model.addAttribute("dailySummaryList",dailySummaryList.stream().mapToDouble(Double::doubleValue).sum());
        model.addAttribute("summaryList",summaryList);
        model.addAttribute("fromDate",fromDate);
        model.addAttribute("toDate",toDate);
        modelAndView.setViewName("cashDayBook");
        return modelAndView;
    }
	
	@GetMapping("/cashDayBookPrint")
	  @ResponseBody 
	  public String cashDayBookPrint(@RequestParam(value="fromDate") Date fromDate,@RequestParam(value="toDate") Date toDate) throws ParseException{
		List<BillReport> inReportList= billEntryService.findAllByDailyRegister(fromDate, toDate);
		  List<DailyReport> outReportList= dayToDayExpensesService.findAllCashDayBook(fromDate, toDate);
		  
		  String result="<table style='width:100%;'><tr><td colspan='3'><div><h6 style='text-align:center;'><b>Cash Day Book</b></h6></div></td></tr><tr><td><div style='text-align:left;'> INFLOW </div> </td><td><div style='text-align:center;'> Date: From : "+HallMarkUtil.convertDateToString(fromDate,"dd-MM-yyyy")+"  To:  "+HallMarkUtil.convertDateToString(toDate,"dd-MM-yyyy")+"</div></td><td><div style='text-align:right;'> OUTFLOW </div></td></tr></table><br/>"
		  		+ "<table style='width:100%;'><tr style=\"vertical-align: top;\"><td><div class='table-responsive'>\r\n" + 
		  			"			<table id='billTbl' class='table table-striped table-hover' style='width:100%;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>\r\n" + 
		  			"				<thead>\r\n" + 
		  			"					<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse; background-color:pink;'>\r\n" + 
		  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse; '>Payment Date</th>\r\n" + 
		  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse; '>Amount</th>\r\n" + 
		  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse; '>Given By</th>\r\n" + 
		  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse; '>Narration</th>\r\n" +
		  			"					</tr>\r\n" + 
		  			"				</thead>\r\n" + 
		  			"				<tbody>\r\n" ;
		  int i=1;
		  logger.info("inReportList: {}",inReportList.size());
		  double totalamt = 0;
		  for(BillReport billReport:inReportList) {
			  result= result+"				<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>\r\n" + 
		  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+HallMarkUtil.convertDateToString(billReport.getBillDate(),"dd-MM-yyyy")+"</td>" + 
		  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse; text-align: right;'>"+billReport.getReceivedAmount()+"</td>" + 
		  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getPartyName()+"</td>" + 
		  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getCategory()+"</td>" + 
		  			"					</tr>\r\n" ; 
		  			
		  i++;
		  totalamt = totalamt + billReport.getReceivedAmount();
		  }
		  
		  result= result+"				<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>\r\n" + 
		  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse; text-align: right; font-weight: bold;' >Total : </td>" +
		  			"						<td colspan='0' style='font-size: 12px;border: 1px solid black;border-collapse: collapse; text-align: right; font-weight: bold;'>"+totalamt+"</td>" +
		  			"						<td ></td>" +
		  			"						<td ></td>" +
		  			"					</tr>\r\n" ; 
		  
		  result=result+"</tbody></table></div></td>";
		  
		  
		  result=result+ "<td><div class='table-responsive'>\r\n" + 
			"			<table id='billTbl' class='table table-striped table-hover' style='width:100%;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>\r\n" + 
			"				<thead>\r\n" + 
			"					<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse; background-color:pink;'>\r\n" + 
			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse; '>Payment Date</th>\r\n" + 
			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse; text-align: right;'>Amount</th>\r\n" + 
			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse; '>Given To</th>\r\n" + 
			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse; '>Narration</th>\r\n" +
			"					</tr>\r\n" + 
			"				</thead>\r\n" + 
			"				<tbody>\r\n" ;
			logger.info("reportList: {}",outReportList.size());
			double totalamt1 = 0;
			for(DailyReport billReport:outReportList) {
				String narration = billReport.getPaymentMode().equalsIgnoreCase("CASH") ? "CASH-" + billReport.getNarration() : "CHQ-"+billReport.getBankName() + " " +billReport.getChequeNo();
				  result= result+"				<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>\r\n" + 
						"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+HallMarkUtil.convertDateToString(billReport.getPaymentDate(),"dd-MM-yyyy")+"</td>" + 
						"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse; text-align: right;'>"+billReport.getAmount()+"</td>" + 
						"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getName()+"</td>" + 
						"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+narration+"</td>" + 
						"					</tr>\r\n" ; 
						
			i++;
			totalamt1 = totalamt1 + billReport.getAmount();
			}
			
			result= result+"				<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>\r\n" + 
						"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse; text-align: right; font-weight: bold;' >Total : </td>" +
						"						<td colspan='0' style='font-size: 12px;border: 1px solid black;border-collapse: collapse; text-align: right; font-weight: bold;'>"+totalamt1+"</td> " +
						"						<td></td> " +
						"						<td></td> " +
						"					</tr>\r\n" ; 
			
			result=result+"</tbody></table></div></td></tr></table>";
		return result;  
	  }
	
	
}

