package com.bytecode.hallmarks.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.bytecode.hallmarks.model.ItemMaster;

public interface ItemMasterRepository extends JpaRepository<ItemMaster, Integer> {
	@Query("select itemName from ItemMaster where active=true ")
	public List<String> itemNameNameList();
	
	@Query(value = "select * from itemmaster where active='1'",countQuery = "select count(1) from itemmaster where active='1'", nativeQuery = true)
	public Page<ItemMaster> fetchItemDtl(Pageable aInPageable);
	
	@Query(value = "select * from itemmaster where active=true and CONCAT(item_code, ' ', item_name) LIKE %?1%", nativeQuery = true)
	public Page<ItemMaster> fetchAllItemList(String keyword,Pageable aInPageable);
	
}
