package com.bytecode.hallmarks.service;

import java.text.ParseException;
import java.time.Instant;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bytecode.hallmarks.controller.BillEntryController;
import com.bytecode.hallmarks.model.PartyMaster;
import com.bytecode.hallmarks.repository.PartyMasterRepository;
import com.bytecode.hallmarks.util.HallMarkUtil;

@Service
@Transactional
public class PartyMasterService {
public static final Logger logger=LoggerFactory.getLogger(PartyMasterService.class);

	@Autowired
	private PartyMasterRepository repo;

	public List<PartyMaster> listAll() {
		return repo.findAll();
	}
	public void save(PartyMaster partyMaster) {
		UserDetails userDetails =  (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if(partyMaster.getPartyCode()==0) {
			partyMaster.setActive(true);
			partyMaster.setCreatedBy(userDetails.getUsername());
			partyMaster.setCreatedDate(Instant.now());
		}else {
			partyMaster.setActive(true);
			partyMaster.setModifiedBy(userDetails.getUsername());
			partyMaster.setModifiedDate(Instant.now());
		}
		partyMaster.setActive(true);
		repo.save(partyMaster);
	}

	public PartyMaster get(Integer id) {
		return repo.findById(id).get();
	}

	public void delete(Integer id) {
		repo.deleteById(id);
	}
	
	public List<String> partyNameList() {
		return repo.partyNameList();
	}
	
	public List<PartyMaster> partyMasterList() {
		return repo.partyMasterList();
	}
	public String getLicenseDtl(Integer partyCode) {
		String result="";
		List<PartyMaster> partyMasterList=repo.fetchLicenseDtl(partyCode);
		String expireDateResult="";
		for(PartyMaster partyMaster:partyMasterList) {
			if(BillEntryConstant.PARTYTYPE_LICENSED.equals(partyMaster.getLicenseType()))
			{
				try {
					Date licExpiryDate=HallMarkUtil.convertStringToDateUtil(partyMaster.getLicExpiryDate(),"yyyy-MM-dd");
					Date currentDate=HallMarkUtil.currentUtilDate("yyyy-MM-dd");
					logger.info("licExpiryDate={}",licExpiryDate);
					logger.info("currentDate={}",currentDate);
					logger.info("Exp={}",currentDate.compareTo(licExpiryDate));
					if(currentDate.compareTo(licExpiryDate)>0) {
						logger.info("Date is expired.....");
						expireDateResult="ERROR~License expired, bill can not be created, expiry Date. "+partyMaster.getLicExpiryDate();
					}else
					{
						expireDateResult="SUCCESS~"+partyMaster.getLicExpiryDate();
					}
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			String partyAddress="";
			if(!HallMarkUtil.isEmpty(partyMaster.getAddress())) {
				partyAddress=partyMaster.getAddress().replaceAll(":", "").replaceAll("~", "");
			}
					result=partyMaster.getLicenseType() +":"+partyMaster.getLicenseNo()+":"+expireDateResult+":"+partyMaster.getGstNo()+":"+partyAddress;
		}
		return result;
	}
	
   public Paged<PartyMaster> fetchPartyDtl(int pageNumber, int size) {
		PageRequest request=PageRequest.of(pageNumber - 1, size,Sort.by("party_code").descending());
        Page<PartyMaster> postPage = repo.fetchPartyDtl(request);
        logger.info("==========="+postPage.get().count());
        return new Paged<>(postPage, Paging.of(postPage.getTotalPages(), pageNumber, size));
	}
   
   public String fetchPartyAddress(Integer partyCode) {
		String result="";
		List<PartyMaster> partyMasterList=repo.fetchLicenseDtl(partyCode);
		for(PartyMaster partyMaster:partyMasterList) {
			result=partyMaster.getAddress();
		}
		return result;
   }
   public Paged<PartyMaster> fetchAllPartyList(String keyword,int pageNumber, int size) {
		PageRequest request=PageRequest.of(pageNumber - 1, size,Sort.by("party_code").descending());
       Page<PartyMaster> postPage = repo.fetchAllPartyList(keyword,request);
       logger.info("==========="+postPage.get().count());
       return new Paged<>(postPage, Paging.of(postPage.getTotalPages(), pageNumber, size));
	}
   
}
