package com.bytecode.hallmarks.service;

import org.springframework.data.domain.Page;

public class Paged<T> {

	public Page<T> page;

	public Paging paging;

	public Paged(Page<T> page, Paging paging) {
		super();
		this.page = page;
		this.paging = paging;
	}

}
