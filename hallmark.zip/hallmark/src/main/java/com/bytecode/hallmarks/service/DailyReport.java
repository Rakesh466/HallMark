package com.bytecode.hallmarks.service;

import java.sql.Date;

public interface DailyReport {

	Date getPaymentDate();

	Double getAmount();

	String getNarration();

	String getName();

	String getModifiedBy();

	String getCreatedBy();

	String getPaymentMode();

	String getBankName();

	String getChequeNo();

}
