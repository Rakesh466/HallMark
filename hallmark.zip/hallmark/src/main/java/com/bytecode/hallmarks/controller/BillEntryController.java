package com.bytecode.hallmarks.controller;

import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.printing.PDFPageable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.bytecode.hallmarks.model.BillEntryDetail;
import com.bytecode.hallmarks.model.BillEntryH;
import com.bytecode.hallmarks.model.BillEntryHeader;
import com.bytecode.hallmarks.model.PartyMaster;
import com.bytecode.hallmarks.model.RateMaster;
import com.bytecode.hallmarks.repository.BillEntryHeaderRepository;
import com.bytecode.hallmarks.service.BillEntryConstant;
import com.bytecode.hallmarks.service.BillEntryService;
import com.bytecode.hallmarks.service.BillReport;
import com.bytecode.hallmarks.service.ItemMasterService;
import com.bytecode.hallmarks.service.Paged;
import com.bytecode.hallmarks.service.PartyMasterService;
import com.bytecode.hallmarks.service.RateMasterService;
import com.bytecode.hallmarks.util.FileUploadUtil;
import com.bytecode.hallmarks.util.HallMarkUtil;
import com.bytecode.hallmarks.util.LabelBlockCssApplierFactory;
import com.bytecode.hallmarks.util.NumberToWords;
import com.bytecode.hallmarks.util.PrintUtil;
import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.html2pdf.resolver.font.DefaultFontProvider;
import com.itextpdf.io.font.otf.GlyphLine;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfString;
import com.itextpdf.kernel.pdf.PdfViewerPreferences;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.WriterProperties;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.font.FontProvider;
import com.itextpdf.layout.property.Property;
import com.itextpdf.layout.splitting.DefaultSplitCharacters;

import common_java.JavaPrint1;




@Controller
public class BillEntryController {
	public static final Logger logger=LoggerFactory.getLogger(BillEntryController.class);
	@Autowired
	BillEntryService billEntryService;
	
	@Autowired
	PartyMasterService partyMasterService;
	
	@Autowired
	ItemMasterService itemMasterService;
	
	@Autowired
	RateMasterService rateMasterService;
	@Autowired
	BillEntryHeaderRepository billEntryHeaderRepository;
	
	@Autowired
	HttpSession session;
	
	@Autowired
	PrintUtil printUtil;
	
	@Value("${print.file.generation.path}")
	private String printFilePath;
	
	@Value("${printer.name}")
	private String printerName;
	
	@Value("${card.printer.name}")
	private String cardPrinterName;
	
	@Value("${card.image.path}")
	private String cardImagePath;
	
	@Value("${card.partyName.Yaxis}")
	private String partyNameYaxis;
	
	@Value("${card.date.Yaxis}")
	private String dateYaxis;
	
	@Value("${card.item.Yaxis}")
	private String itemYaxis;
	
	@Value("${card.netWeight.Yaxis}")
	private String netWeightYaxis;
	
	@Value("${card.karat.Yaxis}")
	private String karatYaxis;
	
	@Value("${card.purity.Yaxis}")
	private String purityYaxis;
	
	
	
	@GetMapping(value="/loadBillPage")
    public ModelAndView loadBillPage(Model model){
		logger.info("itemList::=========================================");
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("bill");
        modelAndView.addObject("currentDate", HallMarkUtil.currentDate());
        //modelAndView.addObject("invoiceNo", billEntryService.getInvoiceNo());
        //logger.info("InvoiceNo()::========================================="+billEntryService.getInvoiceNo());
        BillEntryHeader billEntryH=  new BillEntryHeader();
        //billEntryH.setInvoiceNo(billEntryService.getInvoiceNo());
        billEntryH.setBillDate(HallMarkUtil.currentSqlDate());
        modelAndView.addObject("BillEntryH", billEntryH);
        modelAndView.addObject("partyMaster", new PartyMaster());
        modelAndView.addObject("partyNameList",partyNameList());
        modelAndView.addObject("itemNameList",itemMasterService.itemNameNameList());
        fetchRate(modelAndView);
        return modelAndView;
    }

	public ModelAndView fetchRate(ModelAndView modelAndView) {
		List<RateMaster> rateList=rateMasterService.listAll();
		for(RateMaster rateMaster:rateList) {
			if(BillEntryConstant.HUID.equals(rateMaster.getRateType())){
				modelAndView.addObject("HUID_UP_RATE", rateMaster.getRateLT());
				modelAndView.addObject("HUID_RATE", rateMaster.getRateGT());
				modelAndView.addObject("HUID_QTY", rateMaster.getRateQty());
			}
			
			if(BillEntryConstant.CARD.equals(rateMaster.getRateType())){
				modelAndView.addObject("CARD_RATE", rateMaster.getRate());
			}
			if(BillEntryConstant.TUNCH.equals(rateMaster.getRateType())){
				modelAndView.addObject("TUNCH_RATE", rateMaster.getRate());
			}
			if(BillEntryConstant.LESSER.equals(rateMaster.getRateType())){
				modelAndView.addObject("LESSER_RATE", rateMaster.getRate());
			}
			if(BillEntryConstant.GST.equals(rateMaster.getRateType())){
				modelAndView.addObject("GST_RATE", rateMaster.getRate());
			}
		}
		
		return modelAndView;
	}
	public String partyNameList() {
		 String taskList="";
	        taskList += "[";
	        int i=0;
	        for(PartyMaster partyMaster :partyMasterService.partyMasterList()) {
	        	if(i > 0)
				{
					taskList +=",";
				}
	        taskList+= "{\"value\":\""+partyMaster.getPartyCode()+"\",\"label\":\""+partyMaster.getPartyName()+"\"}";
	        i++;
	        }
	        taskList += "]";
	        return taskList;
	}
	@PostMapping("/saveBill")
	@ResponseBody
	public String saveBooks(@ModelAttribute BillEntryHeader billEntryH,BindingResult bindingResult, Model model) throws Exception {
		String result="";
		String dir=printFilePath; //+ "HUID_"+billEntryH.getInvoiceNo()+"_"+HallMarkUtil.currentDate("dd-MM-yyyy")+".pdf";
		String fileName="";
		String strPdf="";
		try {
			
			result=billEntryService.savebillEntry(billEntryH);
			
			if((null!=billEntryH.getHallmarkingChk() && billEntryH.getHallmarkingChk()) 
					&& (null==billEntryH.getTunchChk() || !billEntryH.getTunchChk())
					&& (null==billEntryH.getLesserChk() || !billEntryH.getLesserChk()) 
					&& (null==billEntryH.getCardChk() || !billEntryH.getCardChk()))
			{
				logger.info("HUID Entry");
				fileName=dir +BillEntryConstant.HUID+"_"+billEntryH.getInvoiceNo()+"_"+HallMarkUtil.currentDate("dd-MM-yyyy")+".pdf";
				
				if(null!=session.getAttribute("roleList")) {
					List<String> roleList=(List<String>) session.getAttribute("roleList");
					logger.info("Role:"+session.getAttribute("roleList"));
					if(roleList.contains(BillEntryConstant.ADMIN)) {
						billEntryH.setPartyAddress(partyMasterService.fetchPartyAddress(billEntryH.getPartyCode()));
						strPdf=printUtil.createAdminHuidHtml(billEntryH,fileName);
						logger.info("strPdf:"+strPdf);
						printUtil.generatePDF(strPdf,fileName,BillEntryConstant.PAGE_SIZE_A4);
						result=result+"~"+billEntryH.getPartyAddress();
					}else {
						getPDF(billEntryH,fileName);
						findPrinterJob(printerName,fileName);
					}
				}else {
					getPDF(billEntryH,fileName);
					findPrinterJob(printerName,fileName);
				}
			}else if((null==billEntryH.getHallmarkingChk() || !billEntryH.getHallmarkingChk()) 
					&& (null!=billEntryH.getTunchChk() && billEntryH.getTunchChk())
					&& (null==billEntryH.getLesserChk() || !billEntryH.getLesserChk())
					&& (null==billEntryH.getCardChk() || !billEntryH.getCardChk()))
			{
					logger.info("TUNCH Entry");
					logger.info("billEntryH.getTunchChk():"+billEntryH.getTunchChk());
					fileName=dir +BillEntryConstant.TUNCH+"_"+billEntryH.getInvoiceNo()+"_"+HallMarkUtil.currentDate("dd-MM-yyyy")+".pdf";
					strPdf=printUtil.createTunchHtml(billEntryH,BillEntryConstant.TUNCH);
					printUtil.generatePDF(strPdf,fileName,BillEntryConstant.PAGE_SIZE_3IN);
					findPrinterJob(printerName,fileName);
			}else if((null==billEntryH.getHallmarkingChk() || !billEntryH.getHallmarkingChk()) 
					&& (null==billEntryH.getTunchChk() || !billEntryH.getTunchChk())
					&& (null!=billEntryH.getLesserChk() && billEntryH.getLesserChk())
					&& (null==billEntryH.getCardChk() || !billEntryH.getCardChk()))
			{
					logger.info("LESSER Entry");
					 fileName=dir +BillEntryConstant.LESSER+"_"+billEntryH.getInvoiceNo()+"_"+HallMarkUtil.currentDate("dd-MM-yyyy")+".pdf";
					 logger.info("billEntryH.getLesserChk():"+billEntryH.getLesserChk());
					 strPdf=printUtil.createTunchHtml(billEntryH,BillEntryConstant.LESSER);
					 printUtil.generatePDF(strPdf,fileName,BillEntryConstant.PAGE_SIZE_3IN);
					 findPrinterJob(printerName,fileName);
			}else if((null!=billEntryH.getHallmarkingChk() && billEntryH.getHallmarkingChk()) 
					&& (null!=billEntryH.getTunchChk() && billEntryH.getTunchChk())
					&& (null!=billEntryH.getLesserChk() && billEntryH.getLesserChk())
					&& (null!=billEntryH.getCardChk() && billEntryH.getCardChk())) {
				
					logger.info("Miltibill Entry");
				 fileName=dir +BillEntryConstant.MUTILBILL+"_"+billEntryH.getInvoiceNo()+"_"+HallMarkUtil.currentDate("dd-MM-yyyy")+".pdf";
				 
				 strPdf=printUtil.createMultiBilHtml(billEntryH,BillEntryConstant.MUTILBILL);
				 printUtil.generatePDF(strPdf,fileName,BillEntryConstant.PAGE_SIZE_3IN);
				 findPrinterJob(printerName,fileName);
			}else if((null==billEntryH.getHallmarkingChk() || !billEntryH.getHallmarkingChk()) 
					&& (null==billEntryH.getTunchChk() || !billEntryH.getTunchChk())
					&& (null==billEntryH.getLesserChk() || !billEntryH.getLesserChk())
					&& (null!=billEntryH.getCardChk()  && billEntryH.getCardChk())) {
				
					logger.info("Card Entry");
				 fileName=dir +BillEntryConstant.CARD+"_"+billEntryH.getInvoiceNo()+"_"+HallMarkUtil.currentDate("dd-MM-yyyy")+".pdf";
				 
				 strPdf=printUtil.createCardBilHtml(billEntryH,BillEntryConstant.CARD);
				 printUtil.generatePDF(strPdf,fileName,BillEntryConstant.PAGE_SIZE_3IN);
				 findPrinterJob(printerName,fileName);
			}			
			else {
				fileName=dir +BillEntryConstant.MUTILBILL+"_"+billEntryH.getInvoiceNo()+"_"+HallMarkUtil.currentDate("dd-MM-yyyy")+".pdf";
				 
				 strPdf=printUtil.createMultiBilHtml(billEntryH,BillEntryConstant.MUTILBILL);
				 printUtil.generatePDF(strPdf,fileName,BillEntryConstant.PAGE_SIZE_3IN);
				 findPrinterJob(printerName,fileName);
			}
			/*
			 * else if(BillEntryConstant.EDITBILL.equals(billEntryH.getBillTypeScreen()) ) {
			 * 
			 * } else if(null!=billEntryH.getHallmarkingChk() &&
			 * billEntryH.getHallmarkingChk()) {
			 * 
			 * logger.info("billEntryH.getHallmarkingChk():"+billEntryH.getHallmarkingChk())
			 * ; fileName=dir
			 * +BillEntryConstant.HUID+"_"+billEntryH.getInvoiceNo()+"_"+HallMarkUtil.
			 * currentDate("dd-MM-yyyy")+".pdf"; getPDF(billEntryH,fileName);
			 * 
			 * }else if(null!=billEntryH.getTunchChk() && billEntryH.getTunchChk()) {
			 * logger.info("billEntryH.getTunchChk():"+billEntryH.getTunchChk());
			 * fileName=dir
			 * +BillEntryConstant.TUNCH+"_"+billEntryH.getInvoiceNo()+"_"+HallMarkUtil.
			 * currentDate("dd-MM-yyyy")+".pdf"; //getPDF(billEntryH,fileName);
			 * //findPrinterJob("CITIZEN CT-D150",fileName);
			 * strPdf=printUtil.createTunchHtml(billEntryH,BillEntryConstant.TUNCH);
			 * printUtil.generatePDF(strPdf,fileName); } else
			 * if(null!=billEntryH.getLesserChk() && billEntryH.getLesserChk()) {
			 * 
			 * fileName=dir
			 * +BillEntryConstant.LESSER+"_"+billEntryH.getInvoiceNo()+"_"+HallMarkUtil.
			 * currentDate("dd-MM-yyyy")+".pdf";
			 * logger.info("billEntryH.getLesserChk():"+billEntryH.getLesserChk());
			 * strPdf=printUtil.createTunchHtml(billEntryH,BillEntryConstant.LESSER);
			 * printUtil.generatePDF(strPdf,fileName); }
			 */
			
			
			
			return result;
		}catch(Exception e)
		{
			//e.printStackTrace();
			result="ERROR~";
			 return result;
		}
	   
	}
	
	@PostMapping("/fetchLicensDtl")
	@ResponseBody
	public String fetchLicensDtl(@RequestParam String partyCode) {
		logger.info("partyName:"+partyCode);
		String result="";
		if(!HallMarkUtil.isEmpty(partyCode)) {
			int partyId=Integer.parseInt(partyCode);
		 result=partyMasterService.getLicenseDtl(partyId);
		result =result+":"+billEntryService.previouseBillDtl(partyId);
		logger.info("result:"+result);
		}
	    return result;
	}
	
	
	@GetMapping(value="/loadBillPaidPage")
    public ModelAndView loadBillPaidPage(@RequestParam(value = "pageNumber", required = false, defaultValue = "1") int pageNumber,
            @RequestParam(value = "size", required = false, defaultValue = "20") int size, Model model){
		logger.info("pageNumber::========================================="+pageNumber);
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("partyNameList",partyNameList());
        model.addAttribute("posts",billEntryService.searchBill(HallMarkUtil.currentSqlDate(),HallMarkUtil.currentSqlDate(),0,pageNumber, size));
        model.addAttribute("fromDate",HallMarkUtil.currentSqlDate());
        model.addAttribute("toDate",HallMarkUtil.currentSqlDate());
        modelAndView.addObject("billEntryHeader", new BillEntryHeader());
        modelAndView.setViewName("billPaid");
        return modelAndView;
    }
	
	@GetMapping("/searchBill")
	public ModelAndView searchBill(@RequestParam(value="fromDate") Date fromDate,@RequestParam(value="toDate") Date toDate,@RequestParam(value="partyCode") String partyCode,@RequestParam(value = "pageNumber", required = false, defaultValue = "1") int pageNumber,
            @RequestParam(value = "size", required = false, defaultValue = "20") int size, Model model){
		logger.info("partyCode::========================================="+partyCode);
		logger.info("fromDate::========================================="+fromDate);
		logger.info("toDate::========================================="+toDate);
        ModelAndView modelAndView = new ModelAndView();
       // modelAndView.addObject("pendingBillList", billEntryService.fetchPendingAmountBills());
        int partyCodeInt=0;
        Paged<BillEntryHeader> posts;
        if(!HallMarkUtil.isEmpty(partyCode)) {
        	partyCodeInt=Integer.parseInt(partyCode);
             posts= billEntryService.searchBill(fromDate,toDate,partyCodeInt,pageNumber, size);

        }else
        {
            posts= billEntryService.searchBill(fromDate,toDate,pageNumber, size);

        }
       // posts.page
       List<BillEntryHeader> billEntryHeaderList= posts.page.getContent();
      // billEntryHeaderList.get(0).getBalanceAmount();
       
       
        model.addAttribute("posts", posts);
        model.addAttribute("fromDate",fromDate);
        model.addAttribute("toDate",toDate);
        model.addAttribute("partyCode",partyCode);
        if(!billEntryHeaderList.isEmpty()) {
        model.addAttribute("totalBalance",billEntryHeaderList.get(0).getBalanceAmount());
        model.addAttribute("invoiceNo",billEntryHeaderList.get(0).getInvoiceNo());
        }else
        {
        	model.addAttribute("totalBalance",0.0);
        }
        modelAndView.addObject("partyNameList",partyNameList());
        modelAndView.addObject("billEntryHeader", new BillEntryH());
        
        modelAndView.setViewName("billPaid");
        return modelAndView;
    }
	
	
	@PostMapping("/updateBill")
	public ModelAndView updateBill(Model model,@RequestParam(value="fromDate") Date fromDate,@RequestParam(value="toDate") Date toDate,@RequestParam(value="partyCode") Integer partyCode,@RequestParam(value = "pageNumber", required = false, defaultValue = "1") int pageNumber,
            @RequestParam(value = "size", required = false, defaultValue = "20") int size, @RequestParam(value="invoiceNo") String invoiceNo,@RequestParam(value="balanceAmount") Double balanceAmount,
            @RequestParam(value="receivedAmount") Double receivedAmount){
		logger.info("Invoice No::"+invoiceNo);
			try {
				billEntryService.updateBill(invoiceNo,balanceAmount,receivedAmount);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			ModelAndView modelAndView = new ModelAndView();
			Paged<BillEntryHeader> posts;
			
			if(null!=partyCode) {
				 posts= billEntryService.searchBill(fromDate,toDate,partyCode,pageNumber, size);

	        }else
	        {
	            posts= billEntryService.searchBill(fromDate,toDate,pageNumber, size);

	        }
		       List<BillEntryHeader> billEntryHeaderList= posts.page.getContent();
		       
	        model.addAttribute("posts", posts);
	        model.addAttribute("fromDate",fromDate);
	        model.addAttribute("toDate",toDate);
	        model.addAttribute("partyCode",partyCode);
	        modelAndView.addObject("partyNameList",partyNameList());
	        modelAndView.addObject("billEntryHeader", new BillEntryHeader());
	        modelAndView.setViewName("billPaid");
	        
	        if(!billEntryHeaderList.isEmpty()) {
	        	logger.info("Updated List Amt:"+billEntryHeaderList.get(0).getBalanceAmount());
	        	logger.info("Updated List R Amt:"+billEntryHeaderList.get(0).getReceivedAmount());
	           model.addAttribute("totalBalance",billEntryHeaderList.get(0).getBalanceAmount());
	           model.addAttribute("invoiceNo",billEntryHeaderList.get(0).getInvoiceNo());
	           model.addAttribute("OldReceivedAmount",billEntryHeaderList.get(0).getReceivedAmount());
	            }else
	            {
	            	model.addAttribute("totalBalance",0.0);
	            }
	        
	        return modelAndView;
	}
	
	@GetMapping(value="/loadBillCancelPage")
    public ModelAndView loadBillCancelPage(@RequestParam(value = "pageNumber", required = false, defaultValue = "1") int pageNumber,
            @RequestParam(value = "size", required = false, defaultValue = "20") int size, Model model){
		logger.info("loadBillCancelPage::========================================={}",pageNumber);
        ModelAndView modelAndView = new ModelAndView();

        model.addAttribute("posts",billEntryService.searchBillForCancel(HallMarkUtil.currentSqlDate(),HallMarkUtil.currentSqlDate(),pageNumber, size));
        model.addAttribute("fromDate",HallMarkUtil.currentSqlDate());
        model.addAttribute("toDate",HallMarkUtil.currentSqlDate());
        modelAndView.addObject("billEntryHeader", new BillEntryHeader());
        modelAndView.setViewName("billCancel");
        return modelAndView;
    }
	
	@GetMapping(value="/searchBillCancel")
    public ModelAndView searchBillCancel(@RequestParam(value="fromDate") Date fromDate,@RequestParam(value="toDate") Date toDate,@RequestParam(value = "pageNumber", required = false, defaultValue = "1") int pageNumber,
            @RequestParam(value = "size", required = false, defaultValue = "20") int size, Model model){
		logger.info("searchBillCancel::========================================={}",pageNumber);
        ModelAndView modelAndView = new ModelAndView();

    	logger.info("pageNumber::========================================="+fromDate);
		logger.info("pageNumber::========================================="+toDate);
        model.addAttribute("posts", billEntryService.searchBill(fromDate,toDate,pageNumber, size));
        model.addAttribute("fromDate",fromDate);
        model.addAttribute("toDate",toDate);	
        modelAndView.addObject("billEntryHeader", new BillEntryH());
        modelAndView.setViewName("billCancel");
        return modelAndView;
    }
	
	
	@PostMapping("/deleteBill")
	public ModelAndView deleteBill(Model model,@RequestParam(value="fromDate") Date fromDate,@RequestParam(value="toDate") Date toDate,@RequestParam(value = "pageNumber", required = false, defaultValue = "1") int pageNumber,
            @RequestParam(value = "size", required = false, defaultValue = "20") int size, @RequestParam(value="invoiceNo") Integer invoiceNo){
			try {
				billEntryService.canceleBill(invoiceNo);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			ModelAndView modelAndView = new ModelAndView();
	        model.addAttribute("posts", billEntryService.searchBill(fromDate,toDate,pageNumber, size));
	        model.addAttribute("fromDate",fromDate);
	        model.addAttribute("toDate",toDate);	
	        modelAndView.addObject("billEntryHeader", new BillEntryHeader());
	        modelAndView.setViewName("billCancel");
	        return modelAndView;
	}
	
	@GetMapping(value= {"/huidPage","/cardPage","/tunchPage","/lesserPage"})
	public ModelAndView huidPage(Model model,HttpServletRequest request){
		logger.info("huidPage::========================================="+request.getServletPath().replace("/", ""));
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName(request.getServletPath().replace("/", ""));
        modelAndView.addObject("currentDate", HallMarkUtil.currentDate());
       // modelAndView.addObject("invoiceNo", billEntryService.getInvoiceNo());
        //logger.info("InvoiceNo()::========================================="+billEntryService.getInvoiceNo());
        BillEntryHeader billEntryH=  new BillEntryHeader();
        //billEntryH.setInvoiceNo(billEntryService.getInvoiceNo());
        billEntryH.setBillDate(HallMarkUtil.currentSqlDate());
        modelAndView.addObject("BillEntryH", billEntryH);
        modelAndView.addObject("partyMaster", new PartyMaster());
        
        modelAndView.addObject("partyNameList",partyNameList());
        modelAndView.addObject("itemNameList",itemMasterService.itemNameNameList());
        fetchRate(modelAndView);
        return modelAndView;
    }
	
	@GetMapping("/searchBillEntry")
	public ModelAndView loadEditBillPage(Model model){
		 ModelAndView modelAndView = new ModelAndView();
	        modelAndView.setViewName("searchBillEntry");
	        return modelAndView;
	}
	@GetMapping("/loadEditBillPage")
	public ModelAndView loadEditBillPage(Model model,@RequestParam(value="invoiceNo") String invoiceNo){
		logger.info("invoiceNo::{}",invoiceNo);
		ModelAndView modelAndView = new ModelAndView();
		try {
		
       
        //modelAndView.addObject("currentDate", HallMarkUtil.currentDate());
        modelAndView.addObject("invoiceNo", invoiceNo);
        //BillEntryH billEntryH=  new BillEntryH();
        modelAndView.addObject("partyMaster", new PartyMaster());
        int invoiceNoInt=0;
        if(!HallMarkUtil.isEmpty(invoiceNo))
        {
        	invoiceNoInt=Integer.parseInt(invoiceNo);
        }
        BillEntryHeader billEntryH= billEntryService.fetchBillsHeader(invoiceNoInt);
        
        if(null==billEntryH) {
        	modelAndView.setViewName("searchBillEntry");
        	modelAndView.addObject("message","Invalid bill no entered");
        	return modelAndView;
		}
        logger.info("billEntryH.getIsCancelled():"+billEntryH.getIsCancelled());
        if(BillEntryConstant.Y.equals(billEntryH.getIsCancelled())){
        	modelAndView.setViewName("searchBillEntry");
        	modelAndView.addObject("message","Bill no "+invoiceNo+" is already cancelled, can't modify");
        	return modelAndView;
        }
        logger.info("PartyName:"+billEntryH.getPartyName());
        modelAndView.setViewName("editBillEntry");
        List<BillEntryDetail> billEntryDetailList=billEntryService.fetchBillDetail(invoiceNoInt);
        List<BillEntryDetail> hallMarkList=new ArrayList<BillEntryDetail>();
        List<BillEntryDetail> cardList=new ArrayList<BillEntryDetail>();
        List<BillEntryDetail> tunchList=new ArrayList<BillEntryDetail>();
        List<BillEntryDetail> lesserList=new ArrayList<BillEntryDetail>();

        for(BillEntryDetail billEntryDetail:billEntryDetailList)
        {
        	 logger.info("BillType:"+billEntryDetail.getBillType());
        		if("hallMark".equals(billEntryDetail.getBillType()) || "HUID".equals(billEntryDetail.getBillType()))
        			{
        			hallMarkList.add(billEntryDetail);
        			}else if("card".equals(billEntryDetail.getBillType())) {
        				cardList.add(billEntryDetail);
        			}else if("tunch".equals(billEntryDetail.getBillType())) {
        				tunchList.add(billEntryDetail);
        			}else if("lesser".equals(billEntryDetail.getBillType())) {
        				lesserList.add(billEntryDetail);
        			}
        	
        }
        
        logger.info("hallMarkList:"+hallMarkList.size());
        logger.info("cardList:"+cardList.size());
        logger.info("tunchList:"+tunchList.size());
        logger.info("lesserList:"+lesserList.size());
        billEntryH.setHallMarkList(hallMarkList);
        billEntryH.setCardList(cardList);
        billEntryH.setTunchList(tunchList);
        billEntryH.setLesserList(lesserList);
       
        modelAndView.addObject("BillEntryH", billEntryH);
        modelAndView.addObject("partyNameList",partyNameList());
        modelAndView.addObject("itemNameList",itemMasterService.itemNameNameList());
        fetchRate(modelAndView);
        return modelAndView;
		}catch (Exception e) {
			modelAndView.setViewName("searchBillEntry");
        	modelAndView.addObject("message","Invalid bill no entered");
        	return modelAndView;
		}
	}
	
	  @GetMapping("/dailyregisterPrint")
	  @ResponseBody 
	  public String dailyregisterPrint(@RequestParam(value="fromDate") Date fromDate,@RequestParam(value="toDate") Date toDate) throws ParseException{
		  List<BillReport> reportList= billEntryService.findAllByDailyRegister(fromDate, toDate);
		  
		  if(reportList.isEmpty()) {
			  return "ERROR~Record is not available.";
		  }
		  List<BillReport> summaryList=billEntryService.fetchSummary(fromDate, toDate);
		  String result="<div><h6 style='text-align:center;'><b>Daily Register</b></h6><div><br/> Date: From : "+HallMarkUtil.convertDateToString(fromDate,"dd-MM-yyyy")+"  To:  "+HallMarkUtil.convertDateToString(toDate,"dd-MM-yyyy")+" <br/></div><br/>"
		  		+ "<div class='table-responsive'>\r\n" + 
		  			"			<table id='billTbl' class='table table-striped table-hover' style='width:100%;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>\r\n" + 
		  			"				<thead>\r\n" + 
		  			"					<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>\r\n" + 
		  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>#</th>\r\n" + 
		  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Date</th>\r\n" + 
		  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Receipt No.</th>\r\n" + 
		  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Category</th>\r\n" + 
		  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Party Name</th>\r\n" + 
		  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Pieces</th>\r\n" + 
		  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Weight</th>\r\n" + 
		  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Bill Amt.</th>\r\n" + 
		  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>GST</th>\r\n" +
		  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Disc. Amt.</th>\r\n" +
		  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Pending Amt.</th>\r\n" +
		  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Paid</th>\r\n" + 
		  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Balance Amt</th>\r\n" + 
		  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Status</th>\r\n" + 
		  			"					</tr>\r\n" + 
		  			"				</thead>\r\n" + 
		  			"				<tbody>\r\n" ;
		  int i=1;
		  logger.info("reportList: {}",reportList.size());
		  for(BillReport billReport:reportList) {
			  result= result+"				<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>\r\n" + 
		  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+i+"</td>" + 
		  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+HallMarkUtil.convertDateToString(billReport.getBillDate(),"dd-MM-yyyy")+"</td>" + 
		  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getInvoiceNo()+"</td>\r\n" + 
		  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getCategory()+"</td>" + 
		  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;word-break: break-word;'>"+billReport.getPartyName()+"</td>" + 
		  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getTotalQty()+"</td>" + 
		  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getTotalWeight()+"</td>" + 
		  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getSubTotal()+"</td>" +
		  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getGstRate()+"</td>" +
		  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getDiscount()+"</td>" +
		  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getPendingBillAmt()+"</td>" +
		  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getReceivedAmount()+"</td>" + 
		  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getBalanceAmount()+"</td>" + 
		  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getStatus()+"</td>\r\n" + 
		  			"					</tr>\r\n" ; 
		  			
		  i++;
		  }
		  result=result+"<tfoot>";
		  for(BillReport summary:summaryList) {
			  result= result+	"				<tr>\r\n" + 
			  		"					<td colspan='5' style='text-align:center;font-size: 12px;border: 1px solid black;border-collapse: collapse;'><b>Summary:</b></td>\r\n" + 
			  		"					<td style='font-weight: bold;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+summary.getTotalQty()+"</td>\r\n" + 
			  		"					<td style='font-weight: bold;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+summary.getTotalWeight()+"</td>\r\n" + 
			  		"					<td style='font-weight: bold;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+summary.getSubTotal()+"</td>\r\n" +
			  		"					<td style='font-weight: bold;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+summary.getGstRate()+"</td>\r\n" +
			  		"					<td style='font-weight: bold;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+summary.getDiscount()+"</td>\r\n" +
			  		"					<td style='font-weight: bold;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+summary.getPendingBillAmt()+"</td>\r\n" +
			  		"					<td style='font-weight: bold;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+summary.getReceivedAmount()+"</td>\r\n" + 
			  		"					<td style='font-weight: bold;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+summary.getBalanceAmount()+"</td>\r\n" +
			  		"					<td style='font-weight: bold;font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>"+
			  		"				</tr>\r\n" + 
			  		"				</tfoot>";
		  }
		  result=result+"</tbody></table></div></div>";
		return result;  
	  }
	
	  @GetMapping("/dailyRegisterPage")
	  public ModelAndView dailyRegisterPage(Model model){
			 ModelAndView modelAndView = new ModelAndView();
		        modelAndView.setViewName("dailyRegister");
		        model.addAttribute("posts", billEntryService.findAllDataByTransationDateBetween(HallMarkUtil.currentSqlDate(),HallMarkUtil.currentSqlDate(),1, 20));
		        model.addAttribute("fromDate",HallMarkUtil.currentSqlDate());
		        model.addAttribute("toDate",HallMarkUtil.currentSqlDate());	
		        List<BillReport> summaryList=billEntryService.fetchSummary(HallMarkUtil.currentSqlDate(), HallMarkUtil.currentSqlDate());
		        
		        model.addAttribute("summaryList",summaryList);
		        return modelAndView;
		}
		
		@GetMapping("/dailyregister")
		public ModelAndView generateReport(@RequestParam(value="fromDate") Date fromDate,@RequestParam(value="toDate") Date toDate,@RequestParam(value = "pageNumber", required = false, defaultValue = "1") int pageNumber,
	            @RequestParam(value = "size", required = false, defaultValue = "20") int size, Model model){
			logger.info("searchBillCancel::========================================={}",pageNumber);
	        ModelAndView modelAndView = new ModelAndView();

	    	logger.info("pageNumber::========================================="+fromDate);
			logger.info("pageNumber::========================================="+toDate);
	        model.addAttribute("posts", billEntryService.findAllDataByTransationDateBetween(fromDate,toDate,pageNumber, size));
	        List<BillReport> summaryList=billEntryService.fetchSummary(fromDate, toDate);
	        model.addAttribute("fromDate",fromDate);
	        model.addAttribute("toDate",toDate);	
	        model.addAttribute("summaryList",summaryList);
	        modelAndView.setViewName("dailyregister");
	        return modelAndView;
	    }
		
		
		@GetMapping("/partyWiseBalReptPage")
		public ModelAndView partyWiseBalReptPage(Model model){
			ModelAndView modelAndView = new ModelAndView();
			modelAndView.setViewName("partyWiseBalReport");
			model.addAttribute("posts", billEntryService.findAllDataByTransationDateBetween(null,null,1, 20));
			model.addAttribute("fromDate",HallMarkUtil.currentSqlDate());
			model.addAttribute("toDate",HallMarkUtil.currentSqlDate());	
			modelAndView.addObject("partyNameList",partyNameList());
			model.addAttribute("summaryList",null);
			return modelAndView;
		}
		
		@GetMapping("/partyWiseBalReport")
		public ModelAndView partyWiseBalReport(@RequestParam(value="fromDate") Date fromDate,@RequestParam(value="toDate") Date toDate,@RequestParam(value="partyCode") String partyCode,
				@RequestParam(value="partyName") String partyName,@RequestParam(value = "pageNumber", required = false, defaultValue = "1") int pageNumber,
	            @RequestParam(value = "size", required = false, defaultValue = "20") int size,@RequestParam(value="FinalbalanceAmt") String FinalbalanceAmt, Model model){
			logger.info("partyCode::========================================="+partyCode);
			logger.info("fromDate::========================================="+fromDate);
			logger.info("toDate::========================================="+toDate);
			logger.info("partyCode::========================================="+partyCode);
	        ModelAndView modelAndView = new ModelAndView();
	        Paged<BillReport> posts=billEntryService.partyWiseBalReport(fromDate,toDate,Integer.parseInt(partyCode),pageNumber, size);
	        model.addAttribute("posts", posts);
			List<BillReport> summaryList=billEntryService.fetchpartyWiseBalSummary(fromDate, toDate,Integer.parseInt(partyCode));
			model.addAttribute("summaryList",summaryList);
			if(HallMarkUtil.isEmpty(FinalbalanceAmt)) {
				List<BillReport> billReport=posts.page.getContent();
				model.addAttribute("FinalbalanceAmt",billReport.get(0).getBalanceAmount());
			}else
			{
				model.addAttribute("FinalbalanceAmt",FinalbalanceAmt);
			}
	        model.addAttribute("fromDate",fromDate);
	        model.addAttribute("toDate",toDate);
	        model.addAttribute("partyCode",partyCode);
	        
	        model.addAttribute("partyName",partyName);
	        modelAndView.addObject("partyNameList",partyNameList());
	        
	        modelAndView.setViewName("partyWiseBalReport");
	        return modelAndView;
	    }
		
		@GetMapping("/partyWiseBalReportPrint")
		  @ResponseBody 
		  public String partyWiseBalReportPrint(@RequestParam(value="fromDate") Date fromDate,@RequestParam(value="toDate") Date toDate,@RequestParam(value="partyCode") String partyCode,@RequestParam(value="partyName") String partyName) throws ParseException{
			  
			try {
			List<BillReport> reportList= billEntryService.partyWiseBalReportPrint(fromDate, toDate,Integer.parseInt(partyCode));
			  if(reportList.isEmpty()) {
				  return "ERROR~Record is not available.";
			  }
			  List<BillReport> summaryList=billEntryService.fetchpartyWiseBalSummary(fromDate, toDate,Integer.parseInt(partyCode));
			  String result="<div><h6 style='text-align:center;'><b>Partywise Summary</b></h6><div><br/> Date: From : "+HallMarkUtil.convertDateToString(fromDate,"dd-MM-yyyy")+"  To:  "+HallMarkUtil.convertDateToString(toDate,"dd-MM-yyyy")+" <br/></div><br/>"
			  				+"<div>\r\n" + 
			  				"			<table id='billTbl' class='table table-striped table-hover' style='width:100%;'>\r\n" + 
			  				"				<thead>\r\n" + 
			  				"					<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>\r\n" + 
			  				"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Sr.No.</th>\r\n" + 
			  				"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Bill No.</th>\r\n" + 
			  				"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Date</th>\r\n" + 
			  				"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Bill Type</th>\r\n" + 
			  				"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Total Qty</th>\r\n" + 
			  				"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Total Weight</th>\r\n" + 
			  				"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Total Amt</th>\r\n" + 
			  				"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Received Amt</th>\r\n" + 
			  				"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Balance Amt</th>\r\n" + 
			  				"					</tr>\r\n" + 
			  				"				</thead>\r\n" + 
			  				"				<tbody><tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>\r\n" + 
			  				"				<td colspan='4' style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Party Name: "+partyName+"</td>\r\n" + 
			  				"				<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>\r\n" + 
			  				"				<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>\r\n" + 
			  				"				<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>\r\n" + 
			  				"				<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>\r\n" + 
			  				"				<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'></td>\r\n" + 
			  				"				</tr>";
			  int i=1;
			  logger.info("reportList: {}",reportList.size());
			  for(BillReport billReport:reportList) {
				  result= result+"				"
				  		+ "<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>\r\n" + 
			  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+i+"</td>" + 
			  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getInvoiceNo()+"</td>\r\n" +
			  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+HallMarkUtil.convertDateToString(billReport.getBillDate(),"dd-MM-yyyy")+"</td>" + 
			  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getCategory()+"</td>" + 
			  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getTotalQty()+"</td>" + 
			  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getTotalWeight()+"</td>" + 
			  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getSubTotal()+"</td>" + 
			  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getReceivedAmount()+"</td>" + 
			  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getBalanceAmount()+"</td>" + 
			  			"					</tr>\r\n" ; 
			  			
			  i++;
			  }
			  result=result+"<tfoot>";
			  for(BillReport summary:summaryList) {
				  result= result+	"				<tr>\r\n" + 
				  		"					<td colspan='4' style='text-align:center;font-size: 12px;border: 1px solid black;border-collapse: collapse;'><b>Summary:</b></td>\r\n" + 
				  		"					<td style='font-weight: bold;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+summary.getTotalQty()+"</td>\r\n" + 
				  		"					<td style='font-weight: bold;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+summary.getTotalWeight()+"</td>\r\n" + 
				  		"					<td style='font-weight: bold;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+summary.getSubTotal()+"</td>\r\n" + 
				  		"					<td style='font-weight: bold;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+summary.getReceivedAmount()+"</td>\r\n" + 
				  		"					<td style='font-weight: bold;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+reportList.get(0).getBalanceAmount()+"</td>\r\n" +
				  		"				</tr>\r\n" + 
				  		"				</tfoot>";
			  }
			  result=result+"</tbody></table></div></div>";
			return result;  
			}catch(Exception e) {
				logger.error("Exception occured at the time of party summary report generation :{}",e.getCause());
				return "ERROR~Record is not available.";
			}
		  }
		
		@GetMapping("/custBalanceRegisterPage")
		public ModelAndView custBalanceRegisterPage(Model model) {
			ModelAndView modelAndView = new ModelAndView();
			modelAndView.setViewName("custBalanceRegister");
			Paged<BillReport> posts = billEntryService.custBalanceRegister(HallMarkUtil.currentSqlDate(), HallMarkUtil.currentSqlDate(), 1, 20);
	        model.addAttribute("posts", posts);
			model.addAttribute("fromDate", HallMarkUtil.currentSqlDate());
			model.addAttribute("toDate", HallMarkUtil.currentSqlDate());
			return modelAndView;
		}
		
		@GetMapping("/custBalanceRegister")
		public ModelAndView cashDayBook(@RequestParam(value="fromDate") Date fromDate,@RequestParam(value="toDate") Date toDate,@RequestParam(value = "pageNumber", required = false, defaultValue = "1") int pageNumber,
	            @RequestParam(value = "size", required = false, defaultValue = "20") int size, Model model){
			logger.info("loadBillCancelPage::========================================={}",pageNumber);
	        ModelAndView modelAndView = new ModelAndView();
	        Paged<BillReport> posts = billEntryService.custBalanceRegister(fromDate,toDate,pageNumber, size);
	        model.addAttribute("posts", posts);
	        model.addAttribute("fromDate",fromDate);
	        model.addAttribute("toDate",toDate);	
	        modelAndView.setViewName("custBalanceRegister");
	        return modelAndView;
	    }
		
		@GetMapping("/custBalanceRegisterPrint")
		  @ResponseBody 
		  public String custBalanceRegisterPrint(@RequestParam(value="fromDate") Date fromDate,@RequestParam(value="toDate") Date toDate) throws ParseException{
			  List<BillReport> reportList= billEntryService.findAllcustBalanceRegister(fromDate, toDate);	
			  String result="<div><h6 style='text-align:center;'><b>Cutomer Balance Register</b></h6><div><br/> Date: From : "+HallMarkUtil.convertDateToString(fromDate,"dd-MM-yyyy")+"  To:  "+HallMarkUtil.convertDateToString(toDate,"dd-MM-yyyy")+" <br/></div><br/>"
			  		+ "<div class='table-responsive'>\r\n" + 
			  			"			<table id='billTbl' class='table table-striped table-hover' style='width:100%;font-size: 12px;border: 1px solid black;border-collapse: collapse;'>\r\n" + 
			  			"				<thead>\r\n" + 
			  			"					<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>\r\n" + 
			  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Sr.No.</th>\r\n" + 
			  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Bill No.</th>\r\n" + 
			  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Date</th>\r\n" + 
			  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Customer Name</th>\r\n" + 
			  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Mobile No.</th>\r\n" + 
			  			"						<th style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>Pending Amt</th>\r\n" + 
			  			"					</tr>\r\n" + 
			  			"				</thead>\r\n" + 
			  			"				<tbody>\r\n" ;
			  int i=1;
			  logger.info("reportList: {}",reportList.size());
			  double totalamt = 0;
			  for(BillReport billReport:reportList) {
				  String mobileNumber = billReport.getMobileNo() ==null ? "" : billReport.getMobileNo();
				  logger.info("############ billReport.getBillDate(): {}",billReport.getBillDate());
				  
				  result= result+"				<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>\r\n" + 
			  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+i+"</td>" + 
			  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getInvoiceNo()+"</td>\r\n" + 
			  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+HallMarkUtil.convertDateToString(billReport.getBillDate(),"dd-MM-yyyy")+"</td>" + 
			  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getPartyName()+"</td>" + 
			  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+mobileNumber+"</td>" + 
			  			"						<td style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>"+billReport.getBalanceAmount()+"</td>" + 
			  			"					</tr>\r\n" ; 
			  			
			  i++;
			  totalamt = totalamt + billReport.getBalanceAmount();
			  }
			  
			  result= result+"				<tr style='font-size: 12px;border: 1px solid black;border-collapse: collapse;'>\r\n" + 
			  			"						<td colspan='5' style='font-size: 12px;border: 1px solid black;border-collapse: collapse; text-align: right; font-weight: bold;' >Total : </td>" +
			  			"						<td colspan='5' style='font-size: 12px;border: 1px solid black;border-collapse: collapse; font-weight: bold;'>"+totalamt+"</td>" +
			  			"					</tr>\r\n" ; 
			  
			  result=result+"</tbody></table></div></div>";
			return result;  
		  }
		
		@GetMapping("/searchBillEntryFrCardPrint")
		public ModelAndView searchBillEntryFrCardPrint(Model model) {
			ModelAndView modelAndView = new ModelAndView();
			modelAndView.setViewName("searchBillEntryFrCardPrint");
			return modelAndView;
		}
		
		
		@GetMapping("/loadEditBillFrCardPrintPage")
		public ModelAndView loadEditBillFrCardPrintPage(Model model,@RequestParam(value="invoiceNo") String invoiceNo){
			logger.info("invoiceNo::{}",invoiceNo);
			ModelAndView modelAndView = new ModelAndView();
			try {
	        modelAndView.addObject("invoiceNo", invoiceNo);
	        modelAndView.addObject("partyMaster", new PartyMaster());
	        int invoiceNoInt=0;
	        if(!HallMarkUtil.isEmpty(invoiceNo))
	        {
	        	invoiceNoInt=Integer.parseInt(invoiceNo);
	        }
	        BillEntryHeader billEntryH= billEntryService.fetchBillsHeader(invoiceNoInt);
	        
	        if(null==billEntryH) {
	        	modelAndView.setViewName("searchBillEntryFrCardPrint");
	        	modelAndView.addObject("message","Invalid bill no entered");
	        	return modelAndView;
			}
	        logger.info("billEntryH.getIsCancelled():"+billEntryH.getIsCancelled());
	        if(BillEntryConstant.Y.equals(billEntryH.getIsCancelled())){
	        	modelAndView.setViewName("searchBillEntryFrCardPrint");
	        	modelAndView.addObject("message","Bill no "+invoiceNo+" is already cancelled, can't modify");
	        	return modelAndView;
	        }
	        
	        logger.info("PartyName:"+billEntryH.getPartyName());
	        modelAndView.setViewName("editBillEntryFrCardPrint");
	        List<BillEntryDetail> billEntryDetailList=billEntryService.fetchBillDetail(invoiceNoInt);
	        List<BillEntryDetail> hallMarkList=new ArrayList<BillEntryDetail>();
	        List<BillEntryDetail> cardList=new ArrayList<BillEntryDetail>();
	        List<BillEntryDetail> tunchList=new ArrayList<BillEntryDetail>();
	        List<BillEntryDetail> lesserList=new ArrayList<BillEntryDetail>();

	        for(BillEntryDetail billEntryDetail:billEntryDetailList)
	        {
	        	 logger.info("BillType:"+billEntryDetail.getBillType());
	        		    if("card".equals(billEntryDetail.getBillType())) {
	        				cardList.add(billEntryDetail);
	        			}else {
	        				modelAndView.setViewName("searchBillEntryFrCardPrint");
	        	        	modelAndView.addObject("message","Bill no "+invoiceNo+" is not Type of Card, can't Process");
	        	        	return modelAndView;
	        			}
	        	
	        }
	        
	        logger.info("hallMarkList:"+hallMarkList.size());
	        logger.info("cardList:"+cardList.size());
	        logger.info("tunchList:"+tunchList.size());
	        logger.info("lesserList:"+lesserList.size());
	        billEntryH.setHallMarkList(hallMarkList);
	        billEntryH.setCardList(cardList);
	        billEntryH.setTunchList(tunchList);
	        billEntryH.setLesserList(lesserList);
	       
	        modelAndView.addObject("BillEntryH", billEntryH);
	        modelAndView.addObject("partyNameList",partyNameList());
	        modelAndView.addObject("itemNameList",itemMasterService.itemNameNameList());
	        fetchRate(modelAndView);
	        return modelAndView;
			}catch (Exception e) {
				modelAndView.setViewName("editBillEntryFrCardPrint");
	        	modelAndView.addObject("message","Invalid bill no entered");
	        	return modelAndView;
			}
		}
		
		@RequestMapping(value=("/saveBillFrPrint"), method=RequestMethod.POST)
		@ResponseBody
		public String saveBillFrPrint(@RequestParam("imagePath") MultipartFile imagePath, @ModelAttribute BillEntryHeader billEntryH, 
				BindingResult bindingResult, Model model, HttpServletRequest request) throws Exception {
			String result="";
			try {
				String contextPath = request.getContextPath();
				String fileName = StringUtils.cleanPath(imagePath.getOriginalFilename());
				String uploadDir = "user-photos/";
				if(fileName==null || fileName.trim().equalsIgnoreCase("")) {
					return "NO_CHANGES_FOUND";
				}
		        FileUploadUtil.saveFile(uploadDir, fileName, imagePath);
				//result=billEntryService.savebillEntry(billEntryH);
		        BillEntryHeader billEntryHNew= billEntryService.fetchBillsHeader(billEntryH.getInvoiceNo());
		        billEntryHNew.setImagePath(contextPath+"/"+uploadDir+""+fileName);
		        billEntryHNew.setIsPrinted(true);
		        billEntryHNew.setKarat(billEntryH.getKarat());
		        billEntryHeaderRepository.save(billEntryHNew);
		        String imgStr = contextPath+"/"+uploadDir+""+fileName;
		        
		        String str ="<div class='table-responsive'>"+
		        "	<table class='table table-striped table-hover' style='width:50%;font-size: 12px;'>" +
		        "		 <tr>" +
		        "			<td style=\"width: 50%;\">" +
		        "				<table>" +
		        "						<tr >" +
		        "							<td > Party Name : </td > <td >"+ billEntryH.getPartyName()+"</td>" +
		        "						</tr>" +
		        "						<tr >" +
		        "							<td > Date : </td > <td >"+ billEntryH.getBillDate()+"</td>" +
		        "						</tr>" +
		        "						<tr >" +
		        "							<td > Item : </td > <td >"+ billEntryH.getCardList().get(0).getItemName()+"</td>" +
		        "						</tr>" +
		        "						<tr >" +
		        "							<td > Net Weight : </td > <td >"+ billEntryH.getCardList().get(0).getNetWeight()+"</td>" +
		        "						</tr>" +
		        "						<tr >" +
		        "							<td > Karat : </td > <td >"+ billEntryH.getKarat()+"</td>" +
		        "						</tr>" +
		        "						<tr >" +
		        "							<td > Purity : </td > <td >"+ billEntryH.getCardList().get(0).getPurity()+"</td>" +
		        "						</tr>" +
		        "				</table>" +
		        "			</td>" +
		        "			<td style=\"width: 50%;\">" +
		        "				<table>" +
		        "					 <tr>" +
		        "						<td>" +
		        "							<img id=\"blah\" src=\""+imgStr+"\" alt=\"your image\" style=\"width: 100px;height: 100px;\">" +
		        "						</td>" +
		        "					 </tr>" +
		        "				</table>" +
		        "			</td>" +
		        "		 </tr>" +
		        "	 </table>" +
		        "</div>	 " ;
		        
		        String pathImage = cardImagePath+fileName;
		        String command =  cardPrinterName + "#" + billEntryH.getPartyName() + "#" + billEntryH.getBillDate() + "#" + billEntryH.getCardList().get(0).getItemName() + "#" + billEntryH.getCardList().get(0).getNetWeight() + "#" +billEntryH.getKarat() + "#" +  billEntryH.getCardList().get(0).getPurity() + "#" + pathImage + "#" +partyNameYaxis + "#" + dateYaxis + "#"  + itemYaxis + "#" + netWeightYaxis + "#" + karatYaxis+ "#" + purityYaxis;                                                                ;
		        String[] commandExec = {"-n" , command};
		        try {
		        	JavaPrint1.main(commandExec);
		        }catch (Throwable e) {
					e.printStackTrace();
					return "ERROR";
				}
				return str;
			}catch(Exception e)
			{
				e.printStackTrace();
				result="ERROR~";
				 return result;
			}
		   
		}
		
		//@RequestMapping(path = "/pdf")
		public ResponseEntity<?> getPDF(BillEntryHeader billEntryH,String fileName) throws IOException, ParseException {

		    /* Setup Source and target I/O streams */
			List<BillEntryDetail> billEntryDetailList=billEntryH.getHallMarkList();
		    double totalWeight=0;
		    double totalQty=0;
		    double totalAmt=0;
			String billDetails="";
			int i=1;
			for(BillEntryDetail billEntryDetail:billEntryDetailList) {
				
				billDetails+="<tr>"
			     +"<td style='font-size: 12px;'>"+i+"</td>"
			        +"<td style='word-wrap: break-word;min-width: 60px;max-width: 60px;font-size: 12px;'>"+billEntryDetail.getItemName()+"</td>"
			        +"<td style='font-size: 12px;'>"+billEntryDetail.getItemWeight()+"</td>"
			        +"<td style='font-size: 12px;'>"+billEntryDetail.getPurity()+"</td>"
			        +"<td style='font-size: 12px;'>"+billEntryDetail.getQuantity()+"</td>"
			        +"<td style='font-size: 12px;'>"+(null!=billEntryDetail.getRate() ? Math.round(billEntryDetail.getRate()) : 0)+"</td>"
			        +"<td style='font-size: 12px;'>"+(null!=billEntryDetail.getAmount() ? Math.round(billEntryDetail.getAmount()) :0)+"</td>"
			       +"</tr>";
				i++;
				totalWeight=totalWeight+ (null!=billEntryDetail.getItemWeight() ? billEntryDetail.getItemWeight():0);
				totalQty=totalQty+ (null!=billEntryDetail.getQuantity() ? Math.round(billEntryDetail.getQuantity()):0);
				totalAmt=totalAmt+ (null!=billEntryDetail.getAmount() ? Math.round(billEntryDetail.getAmount()) :0);
			}
			
		    ByteArrayOutputStream target = new ByteArrayOutputStream();

		    String print_document="<html><head>"
		    		+"<style>@media print {  @page "
		    		+"{"
		    		+"    size:  auto; "
		    		+"    margin: 0mm; "
		    		+" }"
		    		+"body{"
		    	+" width: 80mm;"
		    	+"font-family: Arial;"
		    	+"}" 
		    	+"}" 
		    	+"th{border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;}"
		    	+"}"
		    	+"</style>"
		    	+"</head>";
		    	print_document  = print_document+"<html><head><style>@media print { @page{size:  auto;margin:0px auto;}}</style></head><body class='media' style='font-family: Arial;line-height: 1.5;font-size: 12;width: 80mm;'><div class='container' id='myPrint' style='margin-left: 5px;margin-right: 10px;'><div class='row' style='flex-wrap: wrap;display: flex;'>"
		    					+"<div class='col' style='line-height: 1.5;position: relative;display: inline-block;'></div>"
		    					//+"<div class='col' style='line-height: 1.5;position: relative;width: 50%;padding-right: 15px;padding-left: 15px;display: inline-block;'><img src='project/images/invoice.png' max-width: 100%; height: auto; th:src='@{project/images/invoice.png}'></div>"
		    					+"<div class='col' style='line-height: 1.5;position: relative;width: 100%;padding-right: 13px;display: inline-block;text-align: right;'><h1 class='preview' data-content='CodePen' style='box-sizing: border-box;font-family: Arial, sans-serif;font-size: 1em;font-weight: bold;position: relative;z-index: 1;display: inline-block;-webkit-font-smoothing: antialiased;-moz-osx-font-smoothing: grayscale;color: black;width: 30%;height: 55%;margin-top: 5px;text-align: center;'>Estimate</h1></div>"
		    					+"</div>"

		    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex;'>"
		    			+"<div class='col' style='font-family: Arial;font-size: 12;width: 60%;line-height: 1.5;position: relative;display: inline-block;overflow-wrap: break-word;'>Party Name:"+billEntryH.getPartyName()+"</div>"
		    			+"<div class='col' style='font-family: Arial;font-size: 12;width: 40%;line-height: 1.5;position: relative;display: inline-block;'> Bill No.:"+billEntryH.getInvoiceNo()+"</div>"
		    			+"</div>"
		    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex;'>"
		    			+"<div class='col' style='font-family: Arial;font-size: 12;width: 60%;line-height: 1.5;position: relative;display: inline-block;'>Request No. "+billEntryH.getRequestNo()+"</div>"
		    			+"<div class='col' style='font-family: Arial;font-size: 12;line-height: 1.5;position: relative;width: 40%;display: inline-block;'>Date : "+HallMarkUtil.convertDateToString(billEntryH.getBillDate(),"dd-MM-yyyy")+"</div>"
		    			+"</div>"
		    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; '>"
		    			+"<div class='col' style='font-family: Arial;font-size: 12;width: 60%;line-height: 1.5;position: relative;display: inline-block;'>License No. "+billEntryH.getLicenseNo()+"</div>"
		    			+"<div class='col' style='font-family: Arial;font-size: 12;position: relative;width: 40%;display: inline-block;'>Bill Type : HUID</div>"
		    			+"</div>"
		    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -5px;'>"
		    			+"<div class='col' style='font-family: Arial;font-size: 12;line-height: 1.5;position: relative;width: 90%;padding-right: 15px;padding-left: 10px;display: inline-block;text-align: center;'>HUID Details<br></div>"
		    			+"<br></div>"
		    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"

		    			+"<div class='col' style='width: 100%;line-height: 1.5;float:right;position: relative;padding-right: 15px;padding-left: 15px;display: inline-block;'>"
		    			+"<table class='table' style='width: 95%;'>"
		    		    +"<thead>"
		    		      +"<tr>"
		    		      +"<th scope='col' style='font-size: 12;'>#</th>"
		    		        +"<th scope='col' style='font-size: 12;text-align: left;width: 20%;'>Items</th>"
		    		        +"<th scope='col' style='font-size: 12;text-align: left;'>Weight</th>"
		    		        +"<th scope='col' style='font-size: 12;text-align: left;'>Purity</th>"
		    		        +"<th scope='col' style='font-size: 12;text-align: left;'>Qty</th>"
		    		        +"<th scope='col' style='font-size: 12;text-align: left;'>Rate</th>"
		    		        +"<th scope='col' style='font-size: 12;text-align: left;'>Amt</th>"
		    		        +"</tr>"
		    		    +"</thead> "
		    		    +"<tbody>";
		    		    
		    print_document=  print_document+ billDetails +"</tbody>"
		    		    +"<tfoot><tr><td style='font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'></td><td style='font-family: Arial;font-size: 12px;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'>Total:</td>"
		    		    +"<td style='font-family: Arial;font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'>"+totalWeight+"</td>"
		    		    +"<td style='font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'></td>"
		    		    +"<td style='font-family: Arial;font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'>"+Math.round(totalQty)+"</td>"
		    		    +"<td style='font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'></td>"
		    		    +"<td style='font-family: Arial;font-size: 12;border-top: 1px solid black;border-bottom:1px solid black;border-collapse: collapse;'>"+Math.round(totalAmt)+"</td>"
		    		    +"</tr></tfoot>"
		    		    +"</table></div>"
		    				+"</div>"
		    			+"<div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
		    			+"<div class='col' style='float:right;position: relative;width: 75%;padding-right: 15px;padding-left: 15px;display: inline-block;'>"

		    			+"<table class='table2' style='width:95%;margin-left: 50px;margin-top: 5px;'>"
		    		    +"<tbody>"
		    			 	/*+"<tr style='font-size: 12;'>"
		    		     	+"<td style='font-size: 12;'>Total Qty:</td>"
		    		        +"<td style='font-size: 12;'>"+billEntryH.getTotalQty()+"</td>"
		    		        +"</tr>"*/
		    		        /*+"<tr style='font-size: 12;'>"
		    		        +"<td style='font-size: 12;'>Total Amt:</td>"
		    		        +"<td style='font-size: 12;'>"+billEntryH.getSubTotal()+"</td>"
		    		        +"</tr>"*/
		    		        +"<tr style='font-size: 12;'>"
		    		        +"<td style='font-family: Arial;font-size: 12;'>GST:</td>"
		    		        +"<td style='font-family: Arial;font-size: 12;'>"+(null!=billEntryH.getGstRate() ? Math.round(billEntryH.getGstRate()) : 0)+"</td>"
		    		        +"</tr>"
		    		        +"<tr style='font-size: 12;'>"
		    		        +"<td style='font-family: Arial;font-size: 12;'>Received Amt:</td>"
		    		        +"<td style='font-family: Arial;font-size: 12;'>"+(null!=billEntryH.getReceivedAmount() ? Math.round(billEntryH.getReceivedAmount()) : 0)+"</td>"
		    		        +"</tr>"
		    		        +"<tr style='font-size: 12;'>"
		    		        +"<td style='font-family: Arial;font-size: 12;'>Balance:</td>"
		    		        +"<td style='font-family: Arial;font-size: 12;'>"+(null!=billEntryH.getBalanceAmount() ? Math.round(billEntryH.getBalanceAmount()) : 0)+"</td>"
		    		        +"</tr>"
		    		        
		    		    +"</tbody></table>"
		    		    +"</div>"
		    			+"</div>"
		    			+"<div class='row' style='flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
		    			+"<div class='col' style='font-family: Arial;font-size: 12;position: relative;padding-right: 15px;padding-left: 15px;display: inline-block;'><br>RECEIVED RS. "+NumberToWords.convert(Math.round((null!=billEntryH.getReceivedAmount() ? billEntryH.getReceivedAmount() : 0)))+" ONLY"
		    			
		    			+"</div>"
		    			+"</div>"
		    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'></div>"
		    			+"<div class='row' style='line-height: 1.5;flex-wrap: wrap;display: flex; margin-right: -15px; margin-left: -15px;'>"
		    			+"<div class='col' style='font-family: Arial;font-size: 12;line-height: 1.5;text-align: end;float:right;position: relative;width: 90%;padding-right: 15px;padding-left: 15px;display: inline-block;'><br/><br/><span style='text-align: right;float:right;margin-right: 10px;'>Authorized Sign</span><br/>"
		    			
		    			+"</div>"
		    			+"</div>"
		    				+"</div></body>";
	        FileOutputStream fileOutputStream = new FileOutputStream(new File(fileName));

			    					    ConverterProperties converterProperties = new ConverterProperties();
			    					    /* Call convert method */
			    					    WriterProperties writerProperties = new WriterProperties();
			    			            //Add metadata
			    			            writerProperties.addXmpMetadata();
			    			            PdfWriter pdfWriter = new PdfWriter(target, writerProperties);
			    			            
			    			            PdfDocument pdfDoc = new PdfDocument(pdfWriter);
			    			            PageSize pageSize = PageSize.A4;
			    			            pdfDoc.setDefaultPageSize(pageSize);
			    			            pdfDoc.getCatalog().setLang(new PdfString("en-US"));
			    			            //Set the document to be tagged
			    			            pdfDoc.setTagged(); 
			    			            PdfViewerPreferences pdfViewerPreferences = new PdfViewerPreferences();
			    			            pdfViewerPreferences.setDisplayDocTitle(true);
			    			            pdfDoc.getCatalog().setViewerPreferences(pdfViewerPreferences);
			    			            FontProvider dfp = new DefaultFontProvider(true, true, false);

			    			            /* Temporary fix for display issue with blocks (in current html2pdf version (2.0.1) */
			    			            converterProperties.setFontProvider(dfp);
			    			            converterProperties.setTagWorkerFactory(new LabelBlockCssApplierFactory());
			    			            Document document =HtmlConverter.convertToDocument(print_document, pdfDoc, converterProperties);
			    			           // pdfDoc.close();
			    			            PdfWriter pdfWriterSave = new PdfWriter(fileOutputStream, writerProperties);
			    			           
			    			            PdfDocument pdfDocumentSave = new PdfDocument(pdfWriterSave);

			    			            //For setting the PAGE SIZE
			    			            //pdfDocumentSave.setDefaultPageSize(new PageSize(PageSize.A4));
			    			            pdfDocumentSave.setDefaultPageSize(new PageSize(new Rectangle(216, 792)));
			    			            pdfDocumentSave.getCatalog().setLang(new PdfString("en-US"));
			    			            //Set the document to be tagged
			    			            pdfDocumentSave.setTagged(); 
			    			            pdfDocumentSave.getCatalog().setViewerPreferences(pdfViewerPreferences);
			    			            
			    			            Document  documentHtml=     HtmlConverter.convertToDocument(print_document, pdfDocumentSave, converterProperties);
			    			            
			    			            documentHtml.setProperty(Property.SPLIT_CHARACTERS,new DefaultSplitCharacters(){
			    			                @Override
			    			                public boolean isSplitCharacter(GlyphLine text, int glyphPos) {
			    			                    return true;
			    			                }
			    			            });
			    			            documentHtml.close();
		    HtmlConverter.convertToPdf(print_document, target,converterProperties); 
		    byte[] bytes = target.toByteArray();
		    try {
		    	
		    /* extract output as bytes */

			/*
			 * Document document = new Document();
			 * 
			 * try { PdfWriter.getInstance(document, new FileOutputStream("D:\\huid.pdf"));
			 * } catch (DocumentException e) { // TODO Auto-generated catch block
			 * e.printStackTrace(); } document.open(); Rectangle one = new Rectangle(72,
			 * 216); document.setPageSize(one); document.setMargins(2, 2, 2, 2); HTMLWorker
			 * htmlWorker = new HTMLWorker(document); htmlWorker.parse(new
			 * StringReader(print_document));
			 * 
			 * document.close();
			 */
		    
		    /* Send the response as downloadable PDF */
}catch(Exception e) {
	e.printStackTrace();
}
		    return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=abc")
		            .contentType(MediaType.APPLICATION_PDF)
		            .body(bytes);

		}
		
		@PostMapping("/saveHtml")
		@ResponseBody
		public String saveHtml(@RequestParam String print_document) {
			logger.info("print_document:"+print_document);
			String result="";
			if(!HallMarkUtil.isEmpty(print_document)) {
				try {
				      FileWriter myWriter = new FileWriter("D:\\huid.html");
				      myWriter.write(print_document);
				      myWriter.close();
				      logger.info("Successfully wrote to the file.");
				    } catch (IOException e) {
				    	logger.info("An error occurred.");
				      e.printStackTrace();
				    }
			logger.info("result:"+result);
			}
		    return result;
		}
		
		/**
		 * Retrieve a PrinterJob instance set with the PrinterService using the
		 * printerName.
		 * 
		 * @return
		 * @throws Exception IllegalStateException if expected printer is not found.
		 */
		public void findPrinterJob(String printerName,String printFile) throws Exception {
			logger.info("inside  findPrinterJob >>>>>>>>>>>>>>>>>>>>>>>>>>>>" + printerName);
			try {
				PDDocument document = PDDocument.load(new File(printFile));

				PrintService myPrintService = findPrintService(printerName);

				PrinterJob job = PrinterJob.getPrinterJob();
				job.setPageable(new PDFPageable(document));
				
					job.setPrintService(myPrintService);
					job.print();
				} catch (PrinterException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}catch (Exception e) {
					e.printStackTrace();
				}
		}
		
		private static PrintService findPrintService(String printerName) {
			PrintService[] printServices = PrintServiceLookup.lookupPrintServices(null, null);
			for (PrintService printService : printServices) {
				if (printService.getName().trim().equals(printerName)) {
					return printService;
				}
			}
			return null;
		}
		
		
}
