package com.bytecode.hallmarks.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bytecode.hallmarks.model.BillEntryDetail;


@Repository
public interface BillEntryDetailRepository extends JpaRepository<BillEntryDetail, Integer>{
	@Transactional
	public void deleteByInvoiceNo(Integer invoiceNo);
	
	public List<BillEntryDetail> findAllByInvoiceNo(Integer invoiceNo);
}
