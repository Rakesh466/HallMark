package com.bytecode.hallmarks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HallmarksApplication {

	public static void main(String[] args) {
		SpringApplication.run(HallmarksApplication.class, args);
		System.out.println( "HallmarksApplication started>>>>>>>>>>>>>>>>" );
	}

}
