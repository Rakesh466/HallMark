package com.bytecode.hallmarks.controller;

import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bytecode.hallmarks.model.Role;
import com.bytecode.hallmarks.model.User;
import com.bytecode.hallmarks.service.BillEntryConstant;
import com.bytecode.hallmarks.service.UserService;



@Controller
public class LoginController {

    @Autowired
    private UserService userService;
    @Autowired
    HttpSession session;
    @GetMapping(value={"/login"})
    public ModelAndView login(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("login");
        return modelAndView;
    }
    @GetMapping(value={"/"})
    public ModelAndView loginHM(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("sessionExpiredPage");
        return modelAndView;
    }

    @GetMapping(value="/registration")
    public ModelAndView registration(){
        ModelAndView modelAndView = new ModelAndView();
        User user = new User();
        modelAndView.addObject("user", user);
        modelAndView.setViewName("registration");
        return modelAndView;
    }

    @PostMapping(value = "/registration")
    public ModelAndView createNewUser(@Valid User user, BindingResult bindingResult) {
        ModelAndView modelAndView = new ModelAndView();
        User userExists = userService.findUserByUserName(user.getUserName());
        if (userExists != null) {
            bindingResult
                    .rejectValue("userName", "error.user",
                            "There is already a user registered with the user name provided");
        }
        if (bindingResult.hasErrors()) {
            modelAndView.setViewName("registration");
        } else {
            userService.saveUser(user);
            modelAndView.addObject("successMessage", "User has been registered successfully");
            modelAndView.addObject("user", new User());
            modelAndView.setViewName("registration");

        }
        return modelAndView;
    }

    
    @GetMapping(value="/homePage")
    public ModelAndView homePage(HttpSession session){
    	 Authentication auth = SecurityContextHolder.getContext().getAuthentication();
    	ModelAndView modelAndView = new ModelAndView();
    	User user = userService.findUserByUserName(auth.getName());
        if(BillEntryConstant.Y.equals(user.getLoggedIn()))
        		{
        		modelAndView.addObject("message","User Already Logged in.");
        		modelAndView.addObject("logout","logout");
        		session.setAttribute("sessionUserId", user.getUserName());
        		modelAndView.setViewName("login");
        		return modelAndView;
        		}
        user.setLoggedIn(BillEntryConstant.Y);
        userService.updateUser(user);
        modelAndView.setViewName("redirect:home");
		return modelAndView;
    }
    @GetMapping(value="/home")
    public ModelAndView home(HttpSession session){
    	System.out.println("home........");
        ModelAndView modelAndView = new ModelAndView();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        
        User user = userService.findUserByUserName(auth.getName());
       
       Set<Role> roleSet= user.getRoles();
      // System.out.println(roleSet.stream().map(role->role.getRole()).collect(Collectors.toList()));
       
        modelAndView.addObject("roleList",roleSet.stream().map(role->role.getRole()).collect(Collectors.toList()));
        modelAndView.addObject("userName", "Welcome " + user.getName());
        modelAndView.addObject("userId", user.getUserName());
        session.setAttribute("sessionUserId", user.getUserName());
        session.setAttribute("sessionUserName", user.getName());
        session.setAttribute("roleList", roleSet.stream().map(role->role.getRole()).collect(Collectors.toList()));
        modelAndView.setViewName("index");
        return modelAndView;
    }
    
	/*
	 * @GetMapping(value="/home") public ModelAndView showHomePage(){ ModelAndView
	 * modelAndView = new ModelAndView(); modelAndView.setViewName("home"); return
	 * modelAndView; }
	 */
    
    @GetMapping(value="/userLogout")
    public ModelAndView logoutUser(HttpServletRequest request,HttpServletResponse response){
        ModelAndView modelAndView = new ModelAndView();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if(null!=session.getAttribute("sessionUserId")) {
        	  User userExists = userService.findUserByUserName((String)session.getAttribute("sessionUserId"));
              userExists.setLoggedIn(BillEntryConstant.N);
              userService.updateUser(userExists);
              
        }
      if(null!=auth) {
    	  new SecurityContextLogoutHandler().logout(request,response,auth);
      }
        User user = new User();
        modelAndView.addObject("user", user);
        modelAndView.setViewName("login");
        
        return modelAndView;
    }
    
    @GetMapping(value="/paidBill")
    public ModelAndView paidBillPage(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("paidBill");
        return modelAndView;
    }
    
    
    @GetMapping(value="/sessionExpiredlogin")
    public ModelAndView sessionExpiredlogin(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("sessionExpiredPage");
        return modelAndView;
    }
}
