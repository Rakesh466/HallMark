package com.bytecode.hallmarks.controller;

import java.sql.Date;
import java.time.Instant;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.bytecode.hallmarks.model.PartyMaster;
import com.bytecode.hallmarks.service.Paged;
import com.bytecode.hallmarks.service.PartyMasterService;
import com.bytecode.hallmarks.util.HallMarkUtil;

@Controller
public class PartyMasterController {

	Logger logger = LoggerFactory.getLogger(PartyMasterController.class);

	@Autowired
	private PartyMasterService partyMasterService;

	@GetMapping(value = "/loadPartyMaster")
	public ModelAndView loadPartyMaster() {
		List<PartyMaster> partyMasterList = partyMasterService.listAll();
		logger.info("partyMasterList size : ", partyMasterList.size());
		/*
		 * for (PartyMaster partyMaster : partyMasterList) {
		 * System.out.println(partyMaster.getLicenseType());
		 * 
		 * }
		 */
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("partyMasterList", partyMasterList);
		modelAndView.addObject("partyMaster", new PartyMaster());
		modelAndView.setViewName("partyMaster");
		return modelAndView;
	}
	
	@GetMapping(value = "/loadPartyMasterPage")
	public ModelAndView loadPartyMasterPage(@RequestParam(value = "pageNumber", required = false, defaultValue = "1") int pageNumber,
            @RequestParam(value = "size", required = false, defaultValue = "10") int size,@RequestParam(value ="keyword" , required = false) String keyword, Model model){
	
		Paged<PartyMaster> partyMasterList=null;
		ModelAndView modelAndView = new ModelAndView();
		if(!HallMarkUtil.isEmpty(keyword)) {
			logger.info("keyword:"+keyword);
			partyMasterList = partyMasterService.fetchAllPartyList(keyword,pageNumber,size);
			modelAndView.addObject("keyword", keyword);
		}else {
		 partyMasterList = partyMasterService.fetchPartyDtl(pageNumber, size);
		}
		
		modelAndView.addObject("partyMasterList", partyMasterList);
		modelAndView.addObject("partyMaster", new PartyMaster());
		modelAndView.setViewName("partyMaster");
		return modelAndView;
	}

	@GetMapping(value = "/getPartyMaster/{partyCode}")
	public String getPartyMaster(@PathVariable(name = "partyCode") int partyCode, Model model) {
		logger.info("partyCode : {}", partyCode);
		PartyMaster partyMaster = partyMasterService.get(partyCode);
		model.addAttribute("partyMaster", partyMaster);
		return "partyMaster";
	}

	@PostMapping("/savePartyMaster")
	public String saveEmployee(@ModelAttribute("partyMaster") PartyMaster partyMaster) {
		partyMasterService.save(partyMaster);
		return "redirect:/loadPartyMasterPage";
	}

	@PostMapping("/deleteParty/{partyCode}")
	public String deleteProduct(@PathVariable(name = "partyCode") int partyCode) {
		partyMasterService.delete(partyCode);
		return "redirect:/loadPartyMasterPage";
	}
	
	@PostMapping("/deleteMultiParty/")
    public String deleteMultiItem(HttpServletRequest req) {
    	String[] codes = req.getParameterValues("idChecked");
    	if(null != codes) {
	    	for(String code : codes) {
	    		partyMasterService.delete(Integer.parseInt(code));
	    	}
    	}
        return "redirect:/loadPartyMasterPage";       
    }
	
	 @RequestMapping("/searchParty")
	  public ModelAndView searchParty(Model model, @Param("keyword") String keyword,@RequestParam(value = "pageNumber", required = false, defaultValue = "1") int pageNumber,
	            @RequestParam(value = "size", required = false, defaultValue = "10") int size) {
	         
			ModelAndView modelAndView = new ModelAndView();
			Paged<PartyMaster> partyMasterList=null;
			
			if(!HallMarkUtil.isEmpty(keyword)) {
				logger.info("keyword:"+keyword);
				partyMasterList = partyMasterService.fetchAllPartyList(keyword,pageNumber,size);
				modelAndView.addObject("keyword", keyword);
			}else {
			 partyMasterList = partyMasterService.fetchPartyDtl(pageNumber, size);
			}
			modelAndView.addObject("partyMasterList", partyMasterList);
			modelAndView.addObject("partyMaster", new PartyMaster());
			modelAndView.addObject("keyword", keyword);
			modelAndView.setViewName("partyMaster");
			return modelAndView;
	    }
}
