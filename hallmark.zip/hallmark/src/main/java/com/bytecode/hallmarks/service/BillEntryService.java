package com.bytecode.hallmarks.service;

import java.sql.Date;
import java.util.List;

import com.bytecode.hallmarks.model.BillEntryDetail;
import com.bytecode.hallmarks.model.BillEntryH;
import com.bytecode.hallmarks.model.BillEntryHeader;

public interface BillEntryService {
public Integer getInvoiceNo();
public String savebillEntry(BillEntryHeader billEntryH) throws Exception;
public String previouseBillDtl(Integer partyName);
public List<BillEntryHeader> fetchPendingAmountBills();
public Paged<BillEntryHeader> getPage(int pageNumber, int size); 


public Paged<BillEntryHeader> searchBill(Date fromDate,Date toDate,Integer partyName,int pageNumber, int size);

public Paged<BillEntryHeader> searchBill(Date fromDate,Date toDate,int pageNumber, int size);

public Paged<BillEntryHeader> searchBillForCancel(Date fromDate,Date toDate,int pageNumber, int size);

public String updateBill(String invoiceNo,Double balanceAmount,Double receivedAmount) throws Exception;

public String canceleBill(Integer invoiceNo) throws Exception;

public BillEntryHeader fetchBillsHeader(Integer invoiceNo);

public List<BillEntryDetail> fetchBillDetail(Integer invoiceNo);

public Paged<BillReport> findAllDataByTransationDateBetween(Date fromDate, Date toDate,int pageNumber, int size);

public List<BillReport> findAllByDailyRegister(Date fromDate, Date toDate);

public List<BillReport> fetchSummary(Date fromDate, Date toDate);

public Paged<BillReport> partyWiseBalReport(Date fromDate, Date toDate,Integer partyCode,int pageNumber, int size);

public List<BillReport> partyWiseBalReportPrint(Date fromDate, Date toDate,Integer partyCode);

public List<BillReport> fetchpartyWiseBalSummary(Date fromDate, Date toDate,Integer partyCode);

public Paged<BillReport> custBalanceRegister(Date fromDate,Date toDate,int pageNumber, int size);

public List<BillReport> findAllcustBalanceRegister(Date fromDate, Date toDate);

public List<BillReport> fetchDailyTranSummary(Date fromDate, Date toDate);
}
