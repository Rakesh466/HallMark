package com.bytecode.hallmarks.service;

import java.sql.Date;

public interface BillReport {
	 Integer getInvoiceNo();
 	
	 Date getBillDate();
    
    String getPartyName();
   
     Integer getTotalQty();
    
     Float getTotalWeight();
    
     Double getSubTotal();
    
     Double getDiscount();
    
     Double getReceivedAmount();
    
     Double getBalanceAmount();
    
     String  getCategory();
    
     Date getTransationDate();
     
     String getMobileNo();
     String getStatus();
     Double getPendingBillAmt();
     Double getGstRate();
}
