package com.bytecode.hallmarks.service;

public class BillEntryConstant {
public final static String PARTYTYPE_LICENSED="LICENSED";
public final static String HUID="HUID";
public final static String CARD="CARD";
public final static String TUNCH="TUNCH";
public final static String LESSER="LESSER";
public final static String GST="GST";
public final static String Y="Y";
public final static String N="N";
public final static String EDITBILL="EDITBILL";
public final static String MUTILBILL="MUTILBILL";
public final static String ADMIN="ADMIN";
public final static String PAGE_SIZE_A4="A4";
public final static String PAGE_SIZE_3IN="3IN";
}
