package com.bytecode.hallmarks.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bytecode.hallmarks.model.PartyMaster;

public interface PartyMasterRepository extends JpaRepository<PartyMaster, Integer> {
	@Query("select partyName from PartyMaster where active=true ")
	public List<String> partyNameList();

	@Query("from PartyMaster where active=true ")
	public List<PartyMaster> partyMasterList();

	@Query("from PartyMaster where active=true and  partyCode=:partyCode")
	public List<PartyMaster> fetchLicenseDtl(@Param("partyCode") Integer partyCode);

	@Query(value = "select * from partymaster where active='1'",countQuery = "select count(1) from partymaster where active='1'", nativeQuery = true)
	public Page<PartyMaster> fetchPartyDtl(Pageable aInPageable);

	@Query(value = "select * from partymaster where active='1' and CONCAT(party_name, ' ') LIKE %?1%", nativeQuery = true)
	public Page<PartyMaster> fetchAllPartyList(String keyword,Pageable aInPageable);
}
