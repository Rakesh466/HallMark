package com.bytecode.hallmarks.model;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name = "BILL_ENTRY_HEADER")
public class BillEntryHeader {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "INVOICE_NO")
	private Integer invoiceNo;

	@Column(name = "REQUEST_NO")
	private String requestNo;

	@Column(name = "BILL_DATE")
	private Date billDate;

	@Column(name = "PARTY_NAME")
	private String partyName;

	@Column(name = "PARTY_CODE")
	private int partyCode;

	@Column(name = "LICENSE_NO")
	private String licenseNo;

	@Column(name = "LICENSE_TYPE")
	private String licenseType;

	@Column(name = "GST_NO")
	private String gstNo;

	@Column(name = "ISCANCELLED")
	private String IsCancelled;

	@Column(name = "TOTAL_QTY")
	private Integer totalQty;

	@Column(name = "TOTAL_WEIGHT")
	private Float totalWeight;

	@Column(name = "SUB_TOTAL")
	private Double subTotal;

	@Column(name = "DISCOUNT")
	private Double discount;

	@Column(name = "RECEIVED_AMT")
	private Double receivedAmount;

	@Column(name = "BALANCE_AMT")
	private Double balanceAmount;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "UPDATED_BY")
	private String updatedBy;

	@Column(name = "CREATED_DATE")
	private Timestamp createdDate;

	@Column(name = "UPDATED_DATE")
	private Timestamp updatedDate;

	@Column(name = "TRANSATION_DATE")
	private Timestamp transationDate;

	@Column(name = "PENDING_BILL_AMT")
	private Double pendingBillAmt;

	@Column(name = "GST_RATE")
	private Double gstRate;

	@Column(name = "PENDING_BILL_DATE")
	private String pendingBillDate;

	@Column(name = "PENDING_BILL_NO")
	private String pendingBillNo;

	@Column(name = " SAMPLE_WEIGHT")
	private String sampleWeight;

	@Column(name = "GRAND_TOTAL")
	private Double grandTotal;
	
	@Column(name = "KARAT")
	private String karat;
	
	@Column(name = "ISPRINTED")
	private Boolean isPrinted;
	
	@Column(name = "IMAGE_PATH")
	private String imagePath;

	@Transient
	private List<BillEntryDetail> hallMarkList;
	@Transient
	private List<BillEntryDetail> cardList;
	@Transient
	private List<BillEntryDetail> tunchList;
	@Transient
	private List<BillEntryDetail> lesserList;

	@Transient
	private Boolean hallmarkingChk;
	@Transient
	private Boolean cardChk;
	@Transient
	private Boolean tunchChk;
	@Transient
	private Boolean lesserChk;
	@Transient
	private String category;
	@Transient
	private String billTypeScreen;
	@Transient
	private String partyAddress;
	
	public Integer getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(Integer invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getPartyName() {
		return partyName;
	}

	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	public String getLicenseNo() {
		return licenseNo;
	}

	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}

	public String getLicenseType() {
		return licenseType;
	}

	public void setLicenseType(String licenseType) {
		this.licenseType = licenseType;
	}

	public String getIsCancelled() {
		return IsCancelled;
	}

	public void setIsCancelled(String isCancelled) {
		IsCancelled = isCancelled;
	}

	public Integer getTotalQty() {
		return totalQty;
	}

	public void setTotalQty(Integer totalQty) {
		this.totalQty = totalQty;
	}

	public Float getTotalWeight() {
		return totalWeight;
	}

	public void setTotalWeight(Float totalWeight) {
		this.totalWeight = totalWeight;
	}

	public Double getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(Double subTotal) {
		this.subTotal = subTotal;
	}

	public Double getDiscount() {
		return discount;
	}

	public void setDiscount(Double discount) {
		this.discount = discount;
	}

	public Double getReceivedAmount() {
		return receivedAmount;
	}

	public void setReceivedAmount(Double receivedAmount) {
		this.receivedAmount = receivedAmount;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public Timestamp getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getRequestNo() {
		return requestNo;
	}

	public void setRequestNo(String requestNo) {
		this.requestNo = requestNo;
	}

	public Date getBillDate() {
		return billDate;
	}

	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}

	public Timestamp getTransationDate() {
		return transationDate;
	}

	public void setTransationDate(Timestamp transationDate) {
		this.transationDate = transationDate;
	}

	public Double getBalanceAmount() {
		return balanceAmount;
	}

	public void setBalanceAmount(Double balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	public int getPartyCode() {
		return partyCode;
	}

	public void setPartyCode(int partyCode) {
		this.partyCode = partyCode;
	}

	public String getGstNo() {
		return gstNo;
	}

	public void setGstNo(String gstNo) {
		this.gstNo = gstNo;
	}

	public Double getPendingBillAmt() {
		return pendingBillAmt;
	}

	public void setPendingBillAmt(Double pendingBillAmt) {
		this.pendingBillAmt = pendingBillAmt;
	}

	public String getPendingBillDate() {
		return pendingBillDate;
	}

	public void setPendingBillDate(String pendingBillDate) {
		this.pendingBillDate = pendingBillDate;
	}

	public String getPendingBillNo() {
		return pendingBillNo;
	}

	public void setPendingBillNo(String pendingBillNo) {
		this.pendingBillNo = pendingBillNo;
	}

	public String getSampleWeight() {
		return sampleWeight;
	}

	public void setSampleWeight(String sampleWeight) {
		this.sampleWeight = sampleWeight;
	}

	public Double getGstRate() {
		return gstRate;
	}

	public void setGstRate(Double gstRate) {
		this.gstRate = gstRate;
	}

	public List<BillEntryDetail> getHallMarkList() {
		return hallMarkList;
	}

	public void setHallMarkList(List<BillEntryDetail> hallMarkList) {
		this.hallMarkList = hallMarkList;
	}

	public List<BillEntryDetail> getCardList() {
		return cardList;
	}

	public void setCardList(List<BillEntryDetail> cardList) {
		this.cardList = cardList;
	}

	public List<BillEntryDetail> getTunchList() {
		return tunchList;
	}

	public void setTunchList(List<BillEntryDetail> tunchList) {
		this.tunchList = tunchList;
	}

	public List<BillEntryDetail> getLesserList() {
		return lesserList;
	}

	public void setLesserList(List<BillEntryDetail> lesserList) {
		this.lesserList = lesserList;
	}

	public Boolean getHallmarkingChk() {
		return hallmarkingChk;
	}

	public void setHallmarkingChk(Boolean hallmarkingChk) {
		this.hallmarkingChk = hallmarkingChk;
	}

	public Boolean getCardChk() {
		return cardChk;
	}

	public void setCardChk(Boolean cardChk) {
		this.cardChk = cardChk;
	}

	public Boolean getTunchChk() {
		return tunchChk;
	}

	public void setTunchChk(Boolean tunchChk) {
		this.tunchChk = tunchChk;
	}

	public Boolean getLesserChk() {
		return lesserChk;
	}

	public void setLesserChk(Boolean lesserChk) {
		this.lesserChk = lesserChk;
	}

	public Double getGrandTotal() {
		return grandTotal;
	}

	public void setGrandTotal(Double grandTotal) {
		this.grandTotal = grandTotal;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getKarat() {
		return karat;
	}

	public void setKarat(String karat) {
		this.karat = karat;
	}

	public Boolean getIsPrinted() {
		return isPrinted;
	}

	public void setIsPrinted(Boolean isPrinted) {
		this.isPrinted = isPrinted;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public String getBillTypeScreen() {
		return billTypeScreen;
	}

	public void setBillTypeScreen(String billTypeScreen) {
		this.billTypeScreen = billTypeScreen;
	}

	public String getPartyAddress() {
		return partyAddress;
	}

	public void setPartyAddress(String partyAddress) {
		this.partyAddress = partyAddress;
	}

}
