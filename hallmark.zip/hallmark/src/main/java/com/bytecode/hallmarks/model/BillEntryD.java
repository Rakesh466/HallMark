package com.bytecode.hallmarks.model;

public class BillEntryD {
	private String billType;
    
    private String itemName;
    
    private Integer quantity;
    
    private Float itemWeight;
    
    private String purity;
    
    private Double rate;
    
    private Double amount;
    
    private String customerName;
    
    private Float grossWeight;
    
    private Float netWeight;
    
    private String extraMark;
    
    private String laserMark;

	public String getBillType() {
		return billType;
	}

	public void setBillType(String billType) {
		this.billType = billType;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Float getItemWeight() {
		return itemWeight;
	}

	public void setItemWeight(Float itemWeight) {
		this.itemWeight = itemWeight;
	}

	public String getPurity() {
		return purity;
	}

	public void setPurity(String purity) {
		this.purity = purity;
	}

	public Double getRate() {
		return rate;
	}

	public void setRate(Double rate) {
		this.rate = rate;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Float getGrossWeight() {
		return grossWeight;
	}

	public void setGrossWeight(Float grossWeight) {
		this.grossWeight = grossWeight;
	}

	public Float getNetWeight() {
		return netWeight;
	}

	public void setNetWeight(Float netWeight) {
		this.netWeight = netWeight;
	}

	public String getExtraMark() {
		return extraMark;
	}

	public void setExtraMark(String extraMark) {
		this.extraMark = extraMark;
	}

	public String getLaserMark() {
		return laserMark;
	}

	public void setLaserMark(String laserMark) {
		this.laserMark = laserMark;
	}
}
