package com.bytecode.hallmarks.service;

import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bytecode.hallmarks.model.ItemMaster;
import com.bytecode.hallmarks.model.PartyMaster;
import com.bytecode.hallmarks.repository.ItemMasterRepository;

@Service
@Transactional
public class ItemMasterService {

	@Autowired
	private ItemMasterRepository repo;

	public List<ItemMaster> listAll() {
		return repo.findAll();
	}

	public void save(ItemMaster itemMaster) {
		UserDetails userDetails =  (UserDetails)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if(itemMaster.getItemCode()==0) {
			itemMaster.setActive(true);
			itemMaster.setCreatedBy(userDetails.getUsername());
			itemMaster.setCreatedDate(Instant.now());
		}else {
			itemMaster.setActive(true);
			itemMaster.setModifiedBy(userDetails.getUsername());
			itemMaster.setModifiedDate(Instant.now());
		}
		repo.save(itemMaster);
	}

	public ItemMaster get(Integer id) {
		return repo.findById(id).get();
	}

	public void delete(Integer id) {
		repo.deleteById(id);
	}
	
	public List<String> itemNameNameList(){
		return repo.itemNameNameList();
	}
	
	public Paged<ItemMaster> fetchItemDtl(int pageNumber, int size) {
		PageRequest request=PageRequest.of(pageNumber - 1, size,Sort.by("item_code").descending());
        Page<ItemMaster> postPage = repo.fetchItemDtl(request);
        return new Paged<>(postPage, Paging.of(postPage.getTotalPages(), pageNumber, size));
	}
	
	
	public Paged<ItemMaster> fetchAllItemList(String keyword,int pageNumber, int size) {
		PageRequest request=PageRequest.of(pageNumber - 1, size,Sort.by("item_code").descending());
        Page<ItemMaster> postPage = repo.fetchAllItemList(keyword,request);
        return new Paged<>(postPage, Paging.of(postPage.getTotalPages(), pageNumber, size));
	}
}
