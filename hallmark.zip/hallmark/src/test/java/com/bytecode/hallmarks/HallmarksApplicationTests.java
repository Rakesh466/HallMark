package com.bytecode.hallmarks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HallmarksApplicationTests {

	@Test
	void contextLoads() {
	}

}
